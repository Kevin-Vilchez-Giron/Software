<?php 

if ($peticionAjax) {
	require_once "../core/configApp.php";
}else{
	require_once "./core/configApp.php";
}
class mainModel 
{
		protected function conect(){
		$enlace = new PDO(SGDB,USER,PASSWORD);
		return $enlace;
	}
	protected function nombredb(){
		$nombre = DB;
		return $nombre;
	}

		protected function listProduct($tipo){
    	$request=self::conect()->query("SELECT t1.idProduct ,t1.codProduct,t1.stock, t1.name from tproduct as t1  WHERE t1.status = 1");
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.='<option  value="0">- Buscar por Codigo / Nombre -</option>';
		foreach ($request as $index=>$row) {
			$html.='<option title="'.$row["name"].'" value="'.$row["idProduct"].'"> '.$row["codProduct"].' - '.$row["name"].' / Stock: '.$row["stock"].'</option>';
		}
		return $html;
	}

	protected function nombreS(){
		$nombreSERVER = SERVER;
		return $nombreSERVER;
	}
	protected function getList($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value=''>-Seleccionar-</option>";
		foreach ($request as $index=>$row) {
			$html.='<option value="'.$row[$idName].'"> '.$row['name'].'</option>';
		}

		return $html;
	}

	protected function getList3($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value='1'>-Sin Asignacion-</option>";
		foreach ($request as $index=>$row) {
			$html.='<option value="'.$row[$idName].'"> '.$row['name'].'</option>';
		}

		return $html;
	}
	protected function getListServicios($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value=''>-Seleccionar-</option>";
		foreach ($request as $index=>$row) {
			$html.='<option value="'.$row[$idName].'"> '.$row['nombre'].' / Precio:   '.$row['precio'].' s/</option>';
		}

		return $html;
	}
	protected function getList2($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value=''>-Seleccionar-</option>";
		foreach ($request as $index=>$row) {
			$html.='<option value="'.$row[$idName].'"> '.$row['nombres'].'</option>';
		}

		return $html;
	}
protected function getListPacientes($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value=''>-Seleccionar-</option>";
		foreach ($request as $index=>$row) {
			$sis = "AFILIADO AL SIS N - : ( ".$row["numeroSis"].")" ;
			if($row["numeroSis"] == ""  ){
					$sis = "DESAFILIADO";
			}
			$html.='<option value="'.$row[$idName].'"> '.$row['nombres'].'  '.$row['apellidoPaterno'].'  '.$row['apellidoMaterno'].' / DNI : '.$row['dni'].' / '.$sis.'</option>';
		}

		return $html;
	}
	protected function getListMedicos($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value=''>-Seleccionar-</option>";
		foreach ($request as $index=>$row) {
			$turno ="";
			if($row['turno']==1){
				$turno ="DE TURNO"." (DE ".$row['horaInicio']." A ".$row['horaFin'].")";
			}else{
				$turno ="NO DISPONIBLE";
			}
			$html.='<option value="'.$row[$idName].'"> '.$row['nombres'].' ( '.$row['nombreEspecialidad'].' ) / '.$turno.' </option>';
		}

		return $html;
	}

	protected function getListMedicosHorarios($query,$idName){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.="<option value=''>-Seleccionar-</option>";
		foreach ($request as $index=>$row) {
			$html.='<option value="'.$row[$idName].'"> '.$row['nombres'].' ( '.$row['nombreEspecialidad'].' )</option>';
		}

		return $html;
	}

protected function getListAutoMultiple($query,$idName,$name,$tipo,$json,$campojs){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";

		  $selectedSave="";
           if ($tipo=="save") {
		  $selectedSave="selected";
}
		foreach ($request as $index=>$row) {
		  $selected="";
           if ($tipo=="update") {
		  foreach ($json as $indexope=>$rowdt) {
  if ($row[$idName]==$rowdt[$campojs]) {
		  	  $selected="selected";
		  	    }
}
		  	      }
	$html.='<option '.$selected.' data-subtext="'.$row[$name].'"  value="'.$row[$idName].'"> '.$row[$name].'</option>';
		}

		return $html;
	}





	//init andres

	//fin andres

	protected function getListPersonalizado($query,$idName,$campo){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		foreach ($request as $index=>$row) {
			$html.='<option value="'.$row[$idName].'"> '.$row[$campo].'</option>';
		}
		return $html;
	}



	protected function listCategory(){

		$request=self::conect()->query("SELECT t1.idCategory , t1.name from tcategory as t1 ");
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		$html.='<option  value="0">-Todos-</option>';
		foreach ($request as $index=>$row) {
			$html.='<option title="'.$row["name"].'" value="'.$row["idCategory"].'"> '.$row["name"].'</option>';
		}
		return $html;
	}

	


	protected function execute_query($query){
		$request=self::conect()->prepare($query);
		$request->execute();
		return $request;
	} 


	///perfil
	protected function getListPers2($query,$idName,$name,$id,$tipo){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
		  $selectedSave="";
           if ($tipo=="save") {
		  $selectedSave="selected";

}
		$html.='<option '.$selectedSave.' value="">-Seleccionar-</option>';
		foreach ($request as $index=>$row) {
		  $selected="";
           if ($tipo=="update") {
		  if ($row[$idName]==$id) {
		  	  $selected="selected";
		  	    }           }


			$html.='<option '.$selected.' title="'.$row[$name].'"  value="'.$row[$idName].'"> '.$row[$name].'</option>';
		}

		return $html;
	}


	//nuevooption format autocomplete
	protected function getListAuto($query,$idName,$name,$id,$tipo){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
				$html.='<option data-subtext="seleccion" value="">-Seleccionar-</option>';

		  $selectedSave="";
           if ($tipo=="save") {
		  $selectedSave="selected";


}
		foreach ($request as $index=>$row) {
		  $selected="";
           if ($tipo=="update") {
		  if ($row[$idName]==$id) {
		  	  $selected="selected";
		  	    }           }


			$html.='<option '.$selected.' data-subtext="'.$row[$name].'"  value="'.$row[$idName].'"> '.$row[$name].'</option>';
		}

		return $html;
	}


protected function getListAuto2($query,$idName,$name,$id,$tipo){
		$request=self::conect()->query($query);
		$request = $request->fetchAll(PDO::FETCH_ASSOC);
		$html="";
				$html.='<option data-subtext="seleccion" value="1">-Sin Asignacion-</option>';

		  $selectedSave="";
           if ($tipo=="save") {
		  $selectedSave="selected";


}
		foreach ($request as $index=>$row) {
		  $selected="";
           if ($tipo=="update") {
		  if ($row[$idName]==$id) {
		  	  $selected="selected";
		  	    }           }


			$html.='<option '.$selected.' data-subtext="'.$row[$name].'"  value="'.$row[$idName].'"> '.$row[$name].'</option>';
		}

		return $html;
	}
	

	public static function encryption($string){
			$output=FALSE;
			$key=hash('sha256', SECRET_KEY);
			$iv=substr(hash('sha256', SECRET_IV), 0, 16);
			$output=openssl_encrypt($string, METHOD, $key, 0, $iv);
			$output=base64_encode($output);
			return $output;
		}
		public static function decryption($string){
			$key=hash('sha256', SECRET_KEY);
			$iv=substr(hash('sha256', SECRET_IV), 0, 16);
			$output=openssl_decrypt(base64_decode($string), METHOD, $key, 0, $iv);
			return $output;
		}
		protected function generar_codigo_aleatorio($letra,$lenght,$num){

			for($i=1;$i<=$lenght;$i++){
				$numero = rand(0,9);
				$letra.=$numero;
			}
			return $letra.$num;
		}
			protected function remove_sp_chr($str)
{
    $result = str_replace(array("#", "'", ";"), '', $str);
    return $result;
}
	

		protected function limpiar_cadena($string){
			$string =trim($string);
			$string = stripcslashes($string);
			$string = str_ireplace("<script>", "", $string);
			$string = str_ireplace("</script>", "", $string);
			$string = str_ireplace("<script src", "", $string);
			$string = str_ireplace("<script type=", "", $string);
			$string = str_ireplace("SELECT * FROM", "", $string);
			$string = str_ireplace("DELETE FROM", "", $string);
			$string = str_ireplace("INSERT INTO", "", $string);
           $string = str_ireplace("DROP TABLE", "", $string);
			$string = str_ireplace("DROP DATABASE", "", $string);
           $string = str_ireplace("TRUNCATE TABLE", "", $string);
           $string = str_ireplace("SHOW TABLES", "", $string);
			$string = str_ireplace("SHOW DATABASES", "", $string);
			$string = str_ireplace("<?php", "", $string);
			$string = str_ireplace("?>", "", $string);
			$string = str_ireplace("--", "", $string);
			$string = str_ireplace(">", "", $string);
			$string = str_ireplace("<", "", $string);
			$string = str_ireplace("[", "", $string);
			$string = str_ireplace("]", "", $string);
		    $string = str_ireplace("^", "", $string);
			$string = str_ireplace("==", "", $string);
			$string = str_ireplace(";", "", $string);
			$string = str_ireplace("::", "", $string);
						$string = str_ireplace('"', "", $string);

			return $string;
		}
	
		protected function mensajeRespuesta($data){
			if($data['alert']=="save"){
				$alert="
				<script>
				 new PNotify({
					title: 'Operacion Exitosa',
					text: 'Datos guardados correctamente.',
					type: 'success'
				});

				     	resetForm();

				</script>

				";
			}else if($data['alert']=="saveproduct"){
				$alert="
				<script>
				 swal(
				 '¡ Operacion Exitosa !',
				 'Los datos se registraron de manera exitosa',
				 'success'
				 );
				 $('.formAjax')[0].reset();
				resetForm2();
				</script>
				";
			}
			else if($data['alert']=="saveorder"){
				$alert="
				<script>
				
 new PNotify({
					title: 'Operacion Exitosa',
					text: 'Datos guardados correctamente.',
					type: 'success'
				});
				
				 $('.formAjax')[0].reset();
				resetFormOrders();
				</script>
				";
			}
			else if($data['alert']=="update"){
				$alert="
				<script>
				  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se actualizaron con exito.',
					type: 'success'
				});
	tabladata.ajax.reload(null, false);
    	resetForm();
				</script>
				";
			}
else if($data['alert']=="updatereport"){
				$url=$data['url']; $url2=$data['url2'];
				$alert="
				<script>
				  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se actualizaron con exito.',
					type: 'success'
				});
	tabladata.ajax.reload(null, false);
    	resetForm();
    	    	ventanaReport(`".$url."`);
    	    	ventanaReport(`".$url2."`);

				</script>
				";
			}
			else if($data['alert']=="savereportAt"){
				$url=$data['url']; 
				$alert="
				<script>
				 new PNotify({
					title: 'Operacion Exitosa',
					text: 'Datos guardados correctamente.',
					type: 'success'
				});

				     	resetForm();
    	    	ventanaReport(`".$url."`);

				</script>
				";
			}

			else if($data['alert']=="updatectz"){
				$url=$data['url'];
				$alert="
				<script>
				  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se genero la boleta con exito.',
					type: 'success'
				});
	tabladata.ajax.reload(null, false);
	    	    	ventanaReport(`".$url."`);

				</script>
				";
			}else if($data['alert']=="updatepersonalizado"){
			      $html='';
              if ($data['operacion']=="Password") {
              	$html='resetForm();';
              	
              }

				$alert="
			<script>
				  new PNotify({
					title: 'Operacion Exitosa',
					text: ' ".$data['campo']."',
					type: 'success'
				});
                 ".$html."
				</script>
				";
			}
			else if($data['alert']=="delete"){

					$alert="
				<script>
					  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se eliminaron de manera exitosa',
					type: 'success'
				});
				
				</script>
				";

			}else if($data['alert']=="updateCompany"){

					$alert="
				<script>
					  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se eliminaron de manera exitosa',
					type: 'success'
				});
				   
setTimeout(function(){ location.reload(); }, 5000);

				</script>
				";

			}else if($data['alert']=="updatereport"){
					$url=$data['report'];


				$alert="
				<script>
				  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se actualizaron con exito.',
					type: 'success'
				});
	tabladata.ajax.reload(null, false);
    	resetForm(); 				ventanaReport(`".$url."`);
    	$('.print').val(0);


				</script>
				";
			}
else if($data['alert']=="savereport"){
					$url=$data['report'];


				$alert="
					<script>
				 new PNotify({
					title: 'Operacion Exitosa',
					text: 'Datos guardados correctamente.',
					type: 'success'
				});

				     	resetForm();
				     	    	$('.print').val(0);
 			ventanaReport(`".$url."`);

				</script>
				";
			}


			else if($data['alert']=="duplicidad"){
						$alert="
				<script>
					  new PNotify({
					title: '¡ Algo Salio Mal !',
					text: 'El  ".$data['campo']."  ya existe en el sistema, por favor registre con otro dato',
					type: 'error'
				});
				
				</script>
				";

				
			}else if($data['alert']=="duplicidadpers"){
				$alert="
				<script>
							  new PNotify({
					title: '¡ Algo Salio Mal !',
					text: 'El  ".$data['campo']."  ya existe en el sistema, por favor registre con otro dato',
					type: 'success'
				});
				   $('#idGuardar').attr('disabled',false);
                                  $('#idGuardar').text('Guardar');
				</script>
				";
			}

			else if($data['alert']=="error"){
				$alert="
				<script>
				new PNotify({
			title: 'Algo Salio Mal',
			text: 'Ocurrio un Error en el sistema , vuelva a intentarlo.',
			type: 'error'
		});

				</script>
				";
			}
else if($data['alert']=="errorpersonalizado"){
				$alert="
				<script>
					new PNotify({
			title: 'Algo Salio Mal',
			text: '".$data['campo']."',
			type: 'error'
		});

				</script>
				";
			}
			else if($data['alert']=="error4"){
				$alert="
				<script>
				new PNotify({
			title: 'Algo Salio Mal',
			text: 'Ocurrio un Error en el sistema , vuelva a intentarlo.',
			type: 'error'
		});
				</script>
				";
			}
			else if($data['alert']=="contraseñaError"){
				$alert="
					<script>
				new PNotify({
			title: 'Algo Salio Mal',
			text: 'Contraseña Actual Invalidad , vuelva a intentarlo.',
			type: 'error'
		});

				</script>
				";
			}
			else if($data['alert']=="activate"){
				$alert="
				<script>
					  new PNotify({
					title: 'Operacion Exitosa',
					text: 'El elemento se a activado correctamente en el Sistema',
					type: 'success'
				});
				
				</script>
				";
			}else if($data['alert']=="saveFoto"){
				$alert="
				<script>
						 new PNotify({
					title: 'Operacion Exitosa',
					text: 'Datos guardados correctamente.',
					type: 'success'
				});
				 $('.formAjax')[0].reset();
				 $('#img')[0].src ='".SERVERURL."view/assets/images/nuevo.png';
				</script>
				";
			}else if($data['alert']=="updateFoto"){
				$alert="
				<script>
				  new PNotify({
					title: 'Operacion Exitosa',
					text: 'Los datos se actualizaron con exito.',
					type: 'success'
				});
               	resetForm();
				tabladata.ajax.reload(null, false);
				</script>
				";
			}
			return $alert;

		}

		
///registro actividades
protected function saveRegistroactivity($data){

    $sql= mainModel::conect()->prepare("INSERT INTO tregistroactivity( idPersonal , actividad) VALUES (:idPersonal , :actividad)");
				$sql->bindParam(":idPersonal",$data['idPersonal']);
				$sql->bindParam(":actividad",$data['actividad']);	
				$sql->execute();
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "0"; 
} 
else{ 
    return "success";
}
	
	}
///
		protected function activateDeleteSimple($table,$idElemento,$status,$nameId){
			$txtStatus='';
			if($status==1){
				$newStatus=0;
							$txtStatus="dar de Baja";

			}else{
				$newStatus=1;
			  $txtStatus="dar de Alta";

			}

			if($table == "tmovimientos"){
			
			$sql  =self::conect()->prepare("

				UPDATE tproduct set  stock = stock - (SELECT cantidad from tmovimientos WHERE idMovimiento = :nameId) WHERE idProduct = (SELECT idProduct from tmovimientos WHERE idMovimiento= :nameId);
				UPDATE $table set status = $newStatus where $nameId= :nameId ");

			}else{
			$sql  =self::conect()->prepare("UPDATE $table set status = $newStatus where $nameId= :nameId");	
			}
			
			$sql->bindParam(":nameId",$idElemento);

			$sql->execute();

			return $sql;
			//return $table."--".$idElemento;
		}

	protected function deleteSimple($table,$idElemento,$nameId){
		$newStatus=0;
			$sql  =self::conect()->prepare("UPDATE $table set status = $newStatus where $nameId= :nameId");
			$sql->bindParam(":nameId",$idElemento);
			$sql->execute();
			return $sql;
	//return $table."--".$idElemento;
		}



//main model	

public function deleteImgController($carpeta,$name){
		$urlimg = $name;
		unlink("../assets/".$carpeta."/".$name);
		return "1";
	}
	public function uploadFile($cargaI,$carpeta,$name){
		$imgPrincipal ="imgdefauld.jpg";
			if($cargaI != 0){
				$ruta_carpeta = "../assets/".$carpeta."/";
				$nombre_archivo = $name.date("dHis") .".". pathinfo($_FILES["image"]["name"],PATHINFO_EXTENSION);
				$ruta_guardar_archivo = $ruta_carpeta . $nombre_archivo;
				if(move_uploaded_file($_FILES["image"]["tmp_name"],$ruta_guardar_archivo)){
						$imgPrincipal= $nombre_archivo;
				}
			}
				return $imgPrincipal;
	}
		public function uploadFilePrincipal($cargaI,$carpeta,$name){
		$imgPrincipal ="imgdefauld.jpg";
			if($cargaI != 0){
				$ruta_carpeta = "../assets/".$carpeta."/";
				$nombre_archivo = $name.date("dHis") .".". pathinfo($_FILES["file"]["name"],PATHINFO_EXTENSION);
				$ruta_guardar_archivo = $ruta_carpeta . $nombre_archivo;
				if(move_uploaded_file($_FILES["file"]["tmp_name"],$ruta_guardar_archivo)){
						$imgPrincipal= $nombre_archivo;
				}
			
			}
		return $imgPrincipal;
	}
	
   public function uploadMultifile($name,$ruta){
   	$paths= array();
//purcharseorders
if (empty($_FILES['files']['name'][0])) {

	    $paths[] ="imgdefauld.jpg";

    return $paths; 
}
    $countfiles = count($_FILES['files']['name']);


    for($i=0;$i<$countfiles;$i++){
  $ruta_carpeta = "../assets/".$ruta."/";
        $nombre_archivo = $name.$i.date("dHis") .".". pathinfo($_FILES['files']['name'][$i],PATHINFO_EXTENSION);
        $ruta_guardar_archivo = $ruta_carpeta . $nombre_archivo;
  
  if(move_uploaded_file($_FILES['files']['tmp_name'][$i],$ruta_guardar_archivo)){
            $paths[]= $nombre_archivo;
        }else {
    $paths[] ="imgdefauld.jpg";
    }
}
      return $paths;
   }





//funcion mastra Dinamic Post FILES
   public function uploadDinamicFiles($name,$ruta,$concat){
   	$paths= array();

if (empty($_FILES['input0'])) {

	    $paths[] ="imgdefauld.jpg";

    return $paths; 
}


  for($i=0; $i <$concat; $i++){
$ficheros = $_FILES['input'.$i];
  $ruta_carpeta = "../assets/".$ruta."/";
        $nombre_archivo = $name.$i.date("dHis") .".". pathinfo($_FILES["input".$i]["name"],PATHINFO_EXTENSION);
        $ruta_guardar_archivo = $ruta_carpeta . $nombre_archivo;
        if(move_uploaded_file($_FILES["input".$i]["tmp_name"],$ruta_guardar_archivo)){
            $paths[]= $nombre_archivo;
        }else {
    $paths[] ="imgdefauld.jpg";
    }
}
      return $paths;
   }

	public  function paginate($page, $tpages, $adjacents,$lista,$ajax,$type) {
	$prevlabel = "&lsaquo; Anterior";
	$nextlabel = "Siguiente &rsaquo;";
	$out="";
	 $out.='<nav class="text-center paginado">
        <ul class="pagination pagination-sm">';
	// previous label

	if($page==1) {
		$out.= '<li class="page-item disabled "><a  class="page-link" href="javascript:void(0)"><<</a></li>';
	} else if($page==2) {
		$out.= '<li class="page-item active "><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.(1).',`'.$type.'`,`'.SERVERURL.'`);"><<</a></li>';
	}else {
		$out.= '<li class="page-item active "><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.($page-1).',`'.$type.'`,`'.SERVERURL.'`);"><<</a></li>';

	}
	
	// first label
	if($page>($adjacents+1)) {
		$out.= '<li class="page-item" ><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.(1).',`'.$type.'`,`'.SERVERURL.'`);" >'.(1).'</a></li>';
	}
	// interval
	if($page>($adjacents+2)) {

		$out.= '<li class="page-item" ><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.($page-($adjacents+1)).',`'.$type.'`,`'.SERVERURL.'`);" >'."...".'</a></li>';
	}

	// pages

	$pmin = ($page>$adjacents) ? ($page-$adjacents) : 1;
	$pmax = ($page<($tpages-$adjacents)) ? ($page+$adjacents) : $tpages;
	for($i=$pmin; $i<=$pmax; $i++) {
		if($i==$page) {
			$out.= '<li class="page-item active"><a class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.$i.',`'.$type.'`,`'.SERVERURL.'`);" >'.$i.'</a></li>';
		}else if($i==1) {
			$out.='<li class="page-item" ><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.$i.',`'.$type.'`,`'.SERVERURL.'`);" >'.$i.'</a></li>'; 
		}else {
			$out.='<li class="page-item" ><a  class="page-link" onclick="onReloadList( `'.$ajax.'`,'.$i.',`'.$type.'`,`'.SERVERURL.'`);" >'.$i.'</a></li>';  
		}
	}

	// interval

	if($page<($tpages-$adjacents-1)) {
		$out.='<li class="page-item" ><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.($tpages-1).',`'.$type.'`,`'.SERVERURL.'`);" >'."...".'</a></li>';
	}

	// last

	if($page<($tpages-$adjacents)) {
		$out.= 	'<li class="page-item" ><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.($tpages).',`'.$type.'`,`'.SERVERURL.'`);" > '.$tpages.'</a></li>';  
	}

	// next

	if($page<$tpages) {
		$out.= '<li class="page-item "><a  class="page-link" onclick="'.$lista.'( `'.$ajax.'`,'.($page+1).',`'.$type.'`,`'.SERVERURL.'`);"> >>  </a></li>';

	}else {
		$out.='<li class="page-item disabled"><a  class="page-link">>></a></li>'; 
	}

	$out .= '</ul></nav><div class="loading text-center"></div>';

	
	return $out;
}

public  function paginate2($page, $tpages, $adjacents,$lista,$ajax,$type) {
	$prevlabel = "&lsaquo; Anterior";
	$nextlabel = "Siguiente &rsaquo;";
	$out="";
	 $out.='
        <ul class="pagination paginado">';
	// previous label

	if($page==1) {
		$out.= '<li  class="prev disabled"><a   href="javascript:void(0)"> <i class="fa fa-chevron-left"></i>		  </a></li>';
	} else if($page==2) {
		$out.= '<li class="active "><a  onclick="'.$lista.'( `'.$ajax.'`,'.(1).',`'.$type.'`,`'.SERVERURL.'`);">
 <i class="fa fa-chevron-left"></i>	</a></li>';
	}else {
		$out.= '<li class="active"><a  onclick="'.$lista.'( `'.$ajax.'`,'.($page-1).',`'.$type.'`,`'.SERVERURL.'`);">  <i class="fa fa-chevron-left"></i>
		</a></li>';

	}
	
	// first label
	if($page>($adjacents+1)) {
		$out.= '<li  ><a  onclick="'.$lista.'( `'.$ajax.'`,'.(1).',`'.$type.'`,`'.SERVERURL.'`);" >'.(1).'</a></li>';
	}
	// interval
	if($page>($adjacents+2)) {

		$out.= '<li  ><a   onclick="'.$lista.'( `'.$ajax.'`,'.($page-($adjacents+1)).',`'.$type.'`,`'.SERVERURL.'`);" >'."...".'</a></li>';
	}

	// pages

	$pmin = ($page>$adjacents) ? ($page-$adjacents) : 1;
	$pmax = ($page<($tpages-$adjacents)) ? ($page+$adjacents) : $tpages;
	for($i=$pmin; $i<=$pmax; $i++) {
		if($i==$page) {
			$out.= '<li class="active"><a onclick="'.$lista.'( `'.$ajax.'`,'.$i.',`'.$type.'`,`'.SERVERURL.'`);" >'.$i.'</a></li>';
		}else if($i==1) {
			$out.='<li ><a onclick="'.$lista.'( `'.$ajax.'`,'.$i.',`'.$type.'`,`'.SERVERURL.'`);" >'.$i.'</a></li>'; 
		}else {
	  $out.='<li ><a onclick="onReloadList( `'.$ajax.'`,'.$i.',`'.$type.'`,`'.SERVERURL.'`);" >'.$i.'</a></li>';  
		}
	}

	// interval

	if($page<($tpages-$adjacents-1)) {
		$out.='<li  ><a  onclick="'.$lista.'( `'.$ajax.'`,'.($tpages-1).',`'.$type.'`,`'.SERVERURL.'`);" >'."...".'</a></li>';
	}

	// last

	if($page<($tpages-$adjacents)) {
		$out.= 	'<li ><a onclick="'.$lista.'( `'.$ajax.'`,'.($tpages).',`'.$type.'`,`'.SERVERURL.'`);" > '.$tpages.'</a></li>';  
	}

	// next

	if($page<$tpages) {
		$out.= '<li><a   onclick="'.$lista.'( `'.$ajax.'`,'.($page+1).',`'.$type.'`,`'.SERVERURL.'`);"> 											<i class="fa fa-chevron-right"></i> </a></li>';

	}else {
		$out.='<li class="next"><a ><i class="fa fa-chevron-right"></i></a></li>'; 
	}

	$out .= '</ul><div class="loading text-center"></div>';

	
	return $out;
}




	
	


}