<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class PacienteModel extends mainModel
{
//nombreUsuario,clave
  protected function savePacienteModel($data){

    
     
   $sql= mainModel::conect()->prepare(" INSERT INTO paciente(dni, apellidoPaterno,apellidoMaterno,nombres,fechaNacimiento,direccion,numeroSis,sexo,intervencionesQuirurgicas,alergias,email,ocupacion,responsable,numCelular,idTipoSangre) VALUES (:dni, :apellidoPaterno,:apellidoMaterno,:nombres,:fechaNacimiento,:direccion,:numeroSis,:sexo,:intervencionesQuirurgicas,:alergias,:email,:ocupacion,:responsable,:numCelular,:idTipoSangre);

   ");
        
        $sql->bindParam(":dni",$data['dni']);
        $sql->bindParam(":apellidoPaterno",$data['apellidoPaterno']);
        $sql->bindParam(":apellidoMaterno",$data['apellidoMaterno']);
        $sql->bindParam(":nombres",$data['nombres']);
        $sql->bindParam(":fechaNacimiento",$data['fechaNacimiento']);
        $sql->bindParam(":direccion",$data['direccion']);
        $sql->bindParam(":numeroSis",$data['numeroSis']);
        $sql->bindParam(":sexo",$data['sexo']);
        $sql->bindParam(":intervencionesQuirurgicas",$data['intervencionesQuirurgicas']);
        $sql->bindParam(":alergias",$data['alergias']);
        $sql->bindParam(":email",$data['email']);
        $sql->bindParam(":ocupacion",$data['ocupacion']);
        $sql->bindParam(":responsable",$data['responsable']);
        $sql->bindParam(":numCelular",$data['numCelular']);
        $sql->bindParam(":idTipoSangre",$data['idTipoSangre']);
        $sql->execute();        
$count = $sql->rowCount(); 
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}
  }

 
protected function updatePacienteModel($data){


     // `dni`, `apellidoPaterno`, `apellidoMaterno`, `nombres`, `fechaNacimiento`, `direccion`, `numeroSis`, `sexo`, `intervencionesQuirurgicas`, `alergias`, `email`, `ocupacion`, `responsable`, `numCelular
     
    $sql= mainModel::conect()->prepare("UPDATE paciente SET
   dni= :dni, apellidoPaterno=:apellidoPaterno,apellidoMaterno= :apellidoMaterno,nombres= :nombres,fechaNacimiento = :fechaNacimiento,direccion = :direccion,numeroSis = :numeroSis,sexo = :sexo,intervencionesQuirurgicas = :intervencionesQuirurgicas,alergias = :alergias,email = :email,ocupacion = :ocupacion,responsable = :responsable,numCelular = :numCelular,idTipoSangre=:idTipoSangre WHERE   idPaciente = :idPaciente" );
 $sql->bindParam(":idPaciente",$data['idPaciente']);
      $sql->bindParam(":dni",$data['dni']);
        $sql->bindParam(":apellidoPaterno",$data['apellidoPaterno']);
        $sql->bindParam(":apellidoMaterno",$data['apellidoMaterno']);
        $sql->bindParam(":nombres",$data['nombres']);
        $sql->bindParam(":fechaNacimiento",$data['fechaNacimiento']);
        $sql->bindParam(":direccion",$data['direccion']);
        $sql->bindParam(":numeroSis",$data['numeroSis']);
        $sql->bindParam(":sexo",$data['sexo']);
        $sql->bindParam(":intervencionesQuirurgicas",$data['intervencionesQuirurgicas']);
        $sql->bindParam(":alergias",$data['alergias']);
        $sql->bindParam(":email",$data['email']);
        $sql->bindParam(":ocupacion",$data['ocupacion']);
        $sql->bindParam(":responsable",$data['responsable']);
        $sql->bindParam(":numCelular",$data['numCelular']);
        $sql->bindParam(":idTipoSangre",$data['idTipoSangre']);
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosPacienteModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idPaciente){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idPaciente"=>$idPaciente
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idPaciente,image) VALUES ( :idPaciente,:image)");
               $sql->bindParam(":idPaciente",$data['idPaciente']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}