<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class PagosModel extends mainModel
{

  protected function savePagosModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO especialidad(nombre) VALUES ( :nombre)");
        $sql->bindParam(":nombre",$data['nombre']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updatePagosModel($data){
    $sql= mainModel::conect()->prepare("UPDATE especialidad SET
   nombre= :nombre WHERE   idEspecialidad = :idEspecialidad" );

       $sql->bindParam(":idEspecialidad",$data['idEspecialidad']);
        $sql->bindParam(":nombre",$data['nombre']);
      
     
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosPagosModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idPagos){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idPagos"=>$idPagos
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idPagos,image) VALUES ( :idPagos,:image)");
               $sql->bindParam(":idPagos",$data['idPagos']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}