<?php 

if ($peticionAjax) {
	require_once "../model/mainModel.php";
}else{
	require_once "./model/mainModel.php";
}

class PerfilModel extends mainModel
{

protected function updatePerfilModel($data){
	$sql =  mainModel::conect()->prepare("UPDATE tprofesional 
	set name = :name, lastName=:lastName , email =:email,dni = :dni,idCargo = :idCargo  where idProfesional = :idProfesional");
		$sql->bindParam(":name",$data['name']);
		$sql->bindParam(":lastName",$data['lastName']);
		$sql->bindParam(":email",$data['email']);
		$sql->bindParam(":idProfesional",$data['idProfesional']);
		$sql->bindParam(":dni",$data['dni']);	
		$sql->bindParam(":idCargo",$data['idCargo']);	
		$sql->execute();
$count = $sql->rowCount(); 
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}

	}

protected function updateContraseñaPerfilModel($data){
		$sql =  mainModel::conect()->prepare("UPDATE tprofesional 
	set password = :password where idProfesional = :idProfesional");
		$sql->bindParam(":password",$data['password']);
		$sql->bindParam(":idProfesional",$data['idProfesional']);	
		$sql->execute();
$count = $sql->rowCount(); 
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}

	}

}