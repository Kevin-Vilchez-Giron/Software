<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class TriajeModel extends mainModel
{

  protected function saveTriajeModel($data){
   
   $sql= mainModel::conect()->prepare("INSERT INTO triaje(idAtencion, precionArterial, temperatura,frecuenciaRespiratoria,frecuenciaCardiaca,saturacion,peso,talla) VALUES (:idAtencion, :precionArterial, :temperatura,:frecuenciaRespiratoria,:frecuenciaCardiaca,:saturacion,:peso,:talla) ;
   UPDATE atencion SET status = 2 where idAtencion = :idAtencion ");
        
        $sql->bindParam(":idAtencion",$data['idAtencion']);
        $sql->bindParam(":precionArterial",$data['precionArterial']);
        $sql->bindParam(":temperatura",$data['temperatura']);
        $sql->bindParam(":frecuenciaRespiratoria",$data['frecuenciaRespiratoria']);
         $sql->bindParam(":frecuenciaCardiaca",$data['frecuenciaCardiaca']);
          $sql->bindParam(":saturacion",$data['saturacion']);
           $sql->bindParam(":peso",$data['peso']);
            $sql->bindParam(":talla",$data['talla']);

        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateTriajeModel($data){
    $sql= mainModel::conect()->prepare("UPDATE atencion SET
   idPaciente= :idPaciente, precio=:precio,idServicio= :idServicio,idProfesional=:idProfesional, idUsuario = :idUsuario WHERE   idTriaje = :idTriaje" );

$sql->bindParam(":idTriaje",$data['idTriaje']);
      $sql->bindParam(":idPaciente",$data['idPaciente']);
        $sql->bindParam(":precio",$data['precio']);
        $sql->bindParam(":idServicio",$data['idServicio']);
        $sql->bindParam(":idProfesional",$data['idProfesional']);
         $sql->bindParam(":idUsuario",$data['idUsuario']);
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosTriajeModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idTriaje){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idTriaje"=>$idTriaje
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idTriaje,image) VALUES ( :idTriaje,:image)");
               $sql->bindParam(":idTriaje",$data['idTriaje']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}