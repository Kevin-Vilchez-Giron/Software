<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class ProductModel extends mainModel
{

  protected function saveProductModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO tproduct( name, description, medida, material, stock, precio, codigo, idCategory,imgPrincipal,oferta) VALUES ( :name, :description, :medida, :material, :stock, :precio, :codigo, :idCategory,:imgPrincipal,:oferta)");
        
        $sql->bindParam(":name",$data['name']);
      
        $sql->bindParam(":description",$data['description']);
        $sql->bindParam(":medida",$data['medida']);
        $sql->bindParam(":material",$data['material']);
        $sql->bindParam(":stock",$data['stock']);
        $sql->bindParam(":precio",$data['precio']);
        $sql->bindParam(":codigo",$data['codigo']);
        $sql->bindParam(":idCategory",$data['idCategory']);
       $sql->bindParam(":imgPrincipal",$data['imgPrincipal']);
        $sql->bindParam(":oferta",$data['oferta']);

        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateProductModel($data){
    $sql= mainModel::conect()->prepare("UPDATE tproduct SET
   name= :name, description=:description,medida= :medida,material= :material,stock= :stock, precio=:precio,  idCategory=:idCategory ,oferta=:oferta , imgPrincipal=:imgPrincipal WHERE   idProduct = :idProduct" );

       $sql->bindParam(":idProduct",$data['idProduct']);
       $sql->bindParam(":name",$data['name']);
        $sql->bindParam(":description",$data['description']);
        $sql->bindParam(":medida",$data['medida']);
        $sql->bindParam(":material",$data['material']);
        $sql->bindParam(":stock",$data['stock']);
        $sql->bindParam(":precio",$data['precio']);
        $sql->bindParam(":idCategory",$data['idCategory']);
                $sql->bindParam(":oferta",$data['oferta']);
       $sql->bindParam(":imgPrincipal",$data['imgPrincipal']);

    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosProductModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idProduct){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idProduct"=>$idProduct
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idProduct,image) VALUES ( :idProduct,:image)");
               $sql->bindParam(":idProduct",$data['idProduct']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}