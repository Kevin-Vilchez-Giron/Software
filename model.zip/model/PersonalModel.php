<?php 

if ($peticionAjax) {
	require_once "../model/mainModel.php";
}else{
	require_once "./model/mainModel.php";
}

class PersonalModel extends mainModel
{

	protected function savePersonalModel($data){

	$sql= mainModel::conect()->prepare("INSERT INTO tadmin(name,lastname,email,password,idRol,status) VALUES (:name,:lastname,:email,:password,:idRol,:status)");
		$sql->bindParam(":name",$data['name']);
				$sql->bindParam(":lastname",$data['lastname']);
				$sql->bindParam(":email",$data['email']);
				$sql->bindParam(":password",$data['password']);
				$sql->bindParam(":idRol",$data['idRol']);
		$sql->bindParam(":status",$data['status']);
		$sql->execute();
		return $sql;
	}
	protected function updatePersonalModel($data){
	$sql= mainModel::conect()->prepare("UPDATE tadmin SET name = :name,lastname = :lastname,email=:email,password=:password,idRol=:idRol  WHERE idadmin = :idadmin" );
				$sql->bindParam(":idadmin",$data['idadmin']);
				$sql->bindParam(":name",$data['name']);
				$sql->bindParam(":lastname",$data['lastname']);
				$sql->bindParam(":email",$data['email']);
				$sql->bindParam(":password",$data['password']);
				$sql->bindParam(":idRol",$data['idRol']);
		$sql->execute();
		return $sql;
	}
}