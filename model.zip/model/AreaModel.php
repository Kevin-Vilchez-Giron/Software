<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class AreaModel extends mainModel
{

  protected function saveAreaModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO tarea(name,descripcion) VALUES ( :name,:descripcion)");
        $sql->bindParam(":name",$data['name']);
        $sql->bindParam(":descripcion",$data['descripcion']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateAreaModel($data){
    $sql= mainModel::conect()->prepare("UPDATE tarea SET
   name= :name , descripcion = :descripcion WHERE   idArea = :idArea" );

       $sql->bindParam(":idArea",$data['idArea']);
        $sql->bindParam(":name",$data['name']);

        $sql->bindParam(":descripcion",$data['descripcion']);
      
     
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosAreaModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("tarea",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idArea){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idArea"=>$idArea
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idArea,image) VALUES ( :idArea,:image)");
               $sql->bindParam(":idArea",$data['idArea']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}