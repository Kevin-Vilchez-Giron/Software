<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class AtencionmedicaModel extends mainModel
{

  protected function saveAtencionmedicaModel($data){
   
   $sql= mainModel::conect()->prepare("INSERT INTO resultado(idAtencion, motivo, tiempoEnfermedad,antecedentesFamiliares,examenFisico,proximaCita,estado,plan,riesgos,tratamiento) VALUES (:idAtencion, :motivo, :tiempoEnfermedad,:antecedentesFamiliares,:examenFisico,:proximaCita,:estado,:plan,:riesgos,:tratamiento) ;
   UPDATE atencion SET status = 3 where idAtencion = :idAtencion ");
        
        $sql->bindParam(":idAtencion",$data['idAtencion']);
        $sql->bindParam(":motivo",$data['motivo']);
        $sql->bindParam(":tiempoEnfermedad",$data['tiempoEnfermedad']);
        $sql->bindParam(":antecedentesFamiliares",$data['antecedentesFamiliares']);
         $sql->bindParam(":examenFisico",$data['examenFisico']);
           $sql->bindParam(":proximaCita",$data['proximaCita']);
                    $sql->bindParam(":tratamiento",$data['tratamiento']);

            $sql->bindParam(":estado",$data['estado']);
            $sql->bindParam(":plan",$data['plan']);
            $sql->bindParam(":riesgos",$data['riesgos']);

        $sql->execute();        
$count = $sql->rowCount(); 

    
if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateAtencionmedicaModel($data){
    $sql= mainModel::conect()->prepare("UPDATE atencion SET
   idPaciente= :idPaciente, precio=:precio,idServicio= :idServicio,idProfesional=:idProfesional, idUsuario = :idUsuario WHERE   idAtencionmedica = :idAtencionmedica" );

$sql->bindParam(":idAtencionmedica",$data['idAtencionmedica']);
      $sql->bindParam(":idPaciente",$data['idPaciente']);
        $sql->bindParam(":precio",$data['precio']);
        $sql->bindParam(":idServicio",$data['idServicio']);
        $sql->bindParam(":idProfesional",$data['idProfesional']);
         $sql->bindParam(":idUsuario",$data['idUsuario']);
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
protected function savedetallediagnosticoModel($datadiagnostico,$idResultado){
        $count ='0';
$operacion='update';

       foreach ($datadiagnostico->tableData as $arr2) {
                    $operacion=$arr2->operation;
    if ($operacion=="save") {

            $data=[
      "idResultado"=>$idResultado,
                "idDiagnostico"=>$arr2->idDiagnostico,
          "tipo"=>$arr2->tipo
       ];   

    $sql= mainModel::conect()->prepare("INSERT INTO detallediagnostico( idResultado, idDiagnostico,tipo) VALUES (:idResultado, :idDiagnostico, :tipo)");
                $sql->bindParam(":idResultado",$data['idResultado']);
                $sql->bindParam(":idDiagnostico",$data['idDiagnostico']);
                $sql->bindParam(":tipo",$data['tipo']);
                $sql->execute();
        
$count = $sql->rowCount(); 
}
}
   if ($operacion=="save") {
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}   
 }if ($operacion=="update") {
    return "success";
 }
}     
protected function savedetalleRecetaModel($datareceta,$idAtencion){
        $count ='0';
$operacion='update';

       foreach ($datareceta->tableDatareceta as $arr2) {
                    $operacion=$arr2->operation;
    if ($operacion=="save") {

            $data=[
             "idAtencion"=>$idAtencion,
                "medicamento"=>$arr2->medicamento,
          "presentacion"=>$arr2->presentacion,
          "dosis"=>$arr2->dosis,
          "duracion"=>$arr2->duracion,
          "cantidad"=>$arr2->cantidad
       ];   
    $sql= mainModel::conect()->prepare("INSERT INTO treceta( idAtencion, medicamento,presentacion,dosis,duracion,cantidad) VALUES (:idAtencion, :medicamento, :presentacion,:dosis,:duracion,:cantidad)");
                $sql->bindParam(":idAtencion",$data['idAtencion']);
                $sql->bindParam(":medicamento",$data['medicamento']);
                $sql->bindParam(":presentacion",$data['presentacion']);
                $sql->bindParam(":dosis",$data['dosis']);
                $sql->bindParam(":duracion",$data['duracion']);
                $sql->bindParam(":cantidad",$data['cantidad']);
                $sql->execute();
$count = $sql->rowCount(); 
}
}
   if ($operacion=="save") {
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}   
 }if ($operacion=="update") {
    return "success";
 }
}     




}