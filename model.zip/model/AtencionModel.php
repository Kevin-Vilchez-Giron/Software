<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class AtencionModel extends mainModel
{

  protected function saveAtencionModel($data){

   $sql= mainModel::conect()->prepare("INSERT INTO atencion(idPaciente, precio, idServicio,idProfesional,idUsuario,nticket) VALUES ( :idPaciente, :precio, :idServicio,:idProfesional,:idUsuario,:nticket)");
        
        $sql->bindParam(":idPaciente",$data['idPaciente']);
        $sql->bindParam(":precio",$data['precio']);
        $sql->bindParam(":idServicio",$data['idServicio']);
        $sql->bindParam(":idProfesional",$data['idProfesional']);
         $sql->bindParam(":idUsuario",$data['idUsuario']);
                 $sql->bindParam(":nticket",$data['nticket']);

        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

protected function saveReciboModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO boleta(idAtencion , especialidad, servicio,precio,paciente) VALUES ( :idAtencion , :especialidad, :servicio,:precio,:paciente)");
        
        $sql->bindParam(":idAtencion",$data['idAtencion']);
        $sql->bindParam(":especialidad",$data['especialidad']);
        $sql->bindParam(":servicio",$data['servicio']);
        $sql->bindParam(":precio",$data['precio']);
         $sql->bindParam(":paciente",$data['paciente']);
        $sql->execute();        
$count = $sql->rowCount(); 
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}
  }

 
protected function updateAtencionModel($data){
    $sql= mainModel::conect()->prepare("UPDATE atencion SET
   idPaciente= :idPaciente, precio=:precio,idServicio= :idServicio,idProfesional=:idProfesional, idUsuario = :idUsuario WHERE   idAtencion = :idAtencion" );

$sql->bindParam(":idAtencion",$data['idAtencion']);
      $sql->bindParam(":idPaciente",$data['idPaciente']);
        $sql->bindParam(":precio",$data['precio']);
        $sql->bindParam(":idServicio",$data['idServicio']);
        $sql->bindParam(":idProfesional",$data['idProfesional']);
         $sql->bindParam(":idUsuario",$data['idUsuario']);
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosAtencionModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idAtencion){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idAtencion"=>$idAtencion
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idAtencion,image) VALUES ( :idAtencion,:image)");
               $sql->bindParam(":idAtencion",$data['idAtencion']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}