<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class CategoryModel extends mainModel
{

  protected function saveCategoryModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO tcategoria(name) VALUES ( :name)");
        $sql->bindParam(":name",$data['name']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateCategoryModel($data){
    $sql= mainModel::conect()->prepare("UPDATE tcategoria SET
   name= :name  WHERE   idCategoria = :idCategoria" );

       $sql->bindParam(":idCategoria",$data['idCategoria']);
        $sql->bindParam(":name",$data['name']);

      
     
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosCategoryModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("tcategoria",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idCategoria){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idCategoria"=>$idCategoria
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idCategoria,image) VALUES ( :idCategoria,:image)");
               $sql->bindParam(":idCategoria",$data['idCategoria']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}