<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class   DiagnosticoModel extends mainModel
{

  protected function saveDiagnosticoModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO diagnosticoscie10(clave,descripcion,idCategoria) VALUES (:clave,:descripcion,:idCategoria)");
        $sql->bindParam(":clave",$data['clave']);
        $sql->bindParam(":descripcion",$data['descripcion']);
        $sql->bindParam(":idCategoria",$data['idCategoria']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateDiagnosticoModel($data){
    $sql= mainModel::conect()->prepare("UPDATE especialidad SET
   nombre= :nombre WHERE   idEspecialidad = :idEspecialidad" );

       $sql->bindParam(":idEspecialidad",$data['idEspecialidad']);
        $sql->bindParam(":nombre",$data['nombre']);
      
     
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  







}