<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class HorarioModel extends mainModel
{
//deleteHorarioModel
  protected function deleteHorarioModel($idHorario){
   $sql= mainModel::conect()->prepare("DELETE FROM detallehorario where idHorario = :idHorario");
        $sql->bindParam(":idHorario",$idHorario);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }
  protected function saveHorarioModel($data){
   $sql= mainModel::conect()->prepare("INSERT INTO horario(idProfesional,idUsuario) VALUES ( :idProfesional,:idUsuario)");
        $sql->bindParam(":idProfesional",$data['idProfesional']);
        $sql->bindParam(":idUsuario",$data['idUsuario']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }
   protected function saveDetalleHorarioModel($data){
    $cantidadPacientes=26;
   $sql= mainModel::conect()->prepare("INSERT INTO detallehorario(idHorario,horaInicio,horaFin,dia,cantidadPacientes,idServicio) VALUES ( (SELECT idHorario from horario where idProfesional = :idProfesional),:horaInicio,:horaFin,:dia,:cantidadPacientes,:idServicio)");
        $sql->bindParam(":idProfesional",$data['idProfesional']);
        $sql->bindParam(":horaInicio",$data['horaInicio']);
        $sql->bindParam(":horaFin",$data['horaFin']);
        $sql->bindParam(":dia",$data['dia']);
        $sql->bindParam(":cantidadPacientes",$cantidadPacientes);
        $sql->bindParam(":idServicio",$data['idServicio']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

  


   protected function save2DetalleHorarioModel($data){
    $cantidadPacientes=26;
   $sql= mainModel::conect()->prepare("INSERT INTO detallehorario(idHorario,horaInicio,horaFin,dia,cantidadPacientes,idServicio) VALUES ( :idHorario,:horaInicio,:horaFin,:dia,:cantidadPacientes,:idServicio)");
        $sql->bindParam(":idHorario",$data['idHorario']);
        $sql->bindParam(":horaInicio",$data['horaInicio']);
        $sql->bindParam(":horaFin",$data['horaFin']);
        $sql->bindParam(":dia",$data['dia']);
        $sql->bindParam(":cantidadPacientes",$cantidadPacientes);
         $sql->bindParam(":idServicio",$data['idServicio']);
        $sql->execute();        
$count = $sql->rowCount(); 

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}
  }

 
protected function updateDetalleHorarioModel($data){
  
    $sql= mainModel::conect()->prepare("UPDATE detallehorario SET
   dia= :dia,horaInicio= :horaInicio,horaFin= :horaFin,idServicio= :idServicio WHERE   idHorario = :idHorario" );

       $sql->bindParam(":dia",$data['dia']);
        $sql->bindParam(":horaInicio",$data['horaInicio']);
        $sql->bindParam(":horaFin",$data['horaFin']);
        $sql->bindParam(":idHorario",$data['idHorario']);
        $sql->bindParam(":idServicio",$data['idServicio']);

     
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosHorarioModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idHorario){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idHorario"=>$idHorario
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idHorario,image) VALUES ( :idHorario,:image)");
               $sql->bindParam(":idHorario",$data['idHorario']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}