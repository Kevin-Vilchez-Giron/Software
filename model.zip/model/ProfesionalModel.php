<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class ProfesionalModel extends mainModel
{
  protected function saveProfesionalModel($data){
  
   $sql= mainModel::conect()->prepare(" 
    INSERT INTO tprofesional(name, lastName, dni,email,password,idCargo) VALUES (:name, :lastName, :dni, :email, :password, :idCargo)");
        
        $sql->bindParam(":name",$data['name']);
        $sql->bindParam(":lastName",$data['lastName']);
        $sql->bindParam(":dni",$data['dni']);
        $sql->bindParam(":email",$data['email']);
        $sql->bindParam(":password",$data['password']);
        $sql->bindParam(":idCargo",$data['idCargo']);
        $sql->execute();        
$count = $sql->rowCount(); 
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}
  }

 
protected function updateProfesionalModel($data){
   
    $sql= mainModel::conect()->prepare("UPDATE tprofesional SET
   name= :name, lastName= :lastName, dni= :dni, email= :email, password = :password ,idCargo = :idCargo  WHERE   idProfesional = :idProfesional
   " );
 $sql->bindParam(":idProfesional",$data['idProfesional']);
     $sql->bindParam(":name",$data['name']);
        $sql->bindParam(":lastName",$data['lastName']);
        $sql->bindParam(":dni",$data['dni']);
        $sql->bindParam(":email",$data['email']);
        $sql->bindParam(":password",$data['password']);
        $sql->bindParam(":idCargo",$data['idCargo']);
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosProfesionalModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idProfesional){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idProfesional"=>$idProfesional
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idProfesional,image) VALUES ( :idProfesional,:image)");
               $sql->bindParam(":idProfesional",$data['idProfesional']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}