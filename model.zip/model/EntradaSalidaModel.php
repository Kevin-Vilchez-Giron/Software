<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class ProductModel extends mainModel
{



  protected function saveProductModel($data){
  
   $sql= mainModel::conect()->prepare(" 
    INSERT INTO tproduct(name, stock, idMedida,idCategoria,precio) VALUES (:name, :stock, :idMedida, :idCategoria,:precio)");
        
        $sql->bindParam(":name",$data['name']);
        $sql->bindParam(":stock",$data['stock']);
        $sql->bindParam(":idMedida",$data['idMedida']);
        $sql->bindParam(":idCategoria",$data['idCategoria']);
        $sql->bindParam(":precio",$data['precio']);

        $sql->execute();        
$count = $sql->rowCount(); 
if($count =='0'){ 
    return "error"; 
} 
else{ 
    return "success";
}
  }

 
protected function updateProductModel($data){
   
    $sql= mainModel::conect()->prepare("UPDATE tproduct SET
   name= :name, cantidad= :stock, idMedida= :idMedida, idCategoria= :idCategoria, precio = :precio   WHERE   idProduct = :idProduct
   " );
 $sql->bindParam(":idProduct",$data['idProduct']);
      $sql->bindParam(":name",$data['name']);
        $sql->bindParam(":stock",$data['stock']);
        $sql->bindParam(":idMedida",$data['idMedida']);
        $sql->bindParam(":idCategoria",$data['idCategoria']);
        $sql->bindParam(":precio",$data['precio']);
     
    $sql->execute();
        
$count = $sql->rowCount();
    return "success";

  }
  



  protected function deleteAdjuntosProductModel($tempArray){

    foreach ($tempArray as $key => $value) {

  $idAdjuntosClient=$value['idremove'];

    $query = mainModel::conect()->prepare("DELETE FROM timageadj WHERE  idimageadj  = :idimageadj ");
    $query->bindParam(":idimageadj",$idAdjuntosClient);
    $query->execute();
$count = $query->rowCount(); 

if($count>0){ 
    $name=$value['name'];
      $delete=mainModel::deleteImgController("product",$name);
  }
  }

    return "success";
  }




  protected function saveAdjuntosClientModel($adjuntos,$idProduct){
        $count ='0';
$indexadj=0;
$longitud = count($adjuntos);
for($i=0; $i<$longitud; $i++)
      {
    
         $data=[
          "image"=>$adjuntos[$i],
          "idProduct"=>$idProduct
          ];  


    $sql= mainModel::conect()->prepare("INSERT INTO timageadj(idProduct,image) VALUES ( :idProduct,:image)");
               $sql->bindParam(":idProduct",$data['idProduct']);

        $sql->bindParam(":image",$data['image']);
        $sql->execute();      
$count = $sql->rowCount(); 
     //  $arr = $sql->errorInfo();
//print_r($arr);
        
}

if($count =='0'){ 
    return "error"; 
} 
else{ 
  
    return "success";
}

}

}