<?php


$peticionAjax=true;

require_once "../core/config.php";


if(isset($_POST['save']) || isset($_POST['datatable']) || isset($_GET['btnActivaEliminar']) || isset($_GET['btnListProduct']) ||
 isset($_POST['update'])  ||
 isset($_GET['formupdate']) ||
 isset($_GET['validateActiverDelete']) ){
	
	
require_once "../controller/MovimientosController.php";
 $inst = new MovimientosController();

if (isset($_GET['btnListProduct'])) {
echo $inst->listProductSearch2();
}

if (isset($_POST['datatable'])) {
echo $inst->listMovimientosController($_REQUEST,$_POST['status']);
}

	if(isset($_GET['btnActivaEliminar'])){
echo $inst->activaDeleteMovimientosController($_GET['id'],$_GET['status']);
	}

 if(isset($_POST['save'])){
echo $inst->saveMovimientosController();	
	}
	 if(isset($_POST['update'])){
echo $inst->updateMovimientosController();	
	}

		if(isset($_GET['formupdate'])){
echo $inst->fomUpdate();
	}
	if(isset($_GET['validateActiverDelete'])){
echo $inst->valideractivatedelete($_GET['id'],$_GET['status']);
	}


}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/"</script>';
}


