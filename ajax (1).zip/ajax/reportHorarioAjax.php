<?php
$peticionAjax=true;                                   
require_once "../core/config.php";

if(isset($_GET['report'])){

require_once "../controller/HorarioController.php";
 $inst = new HorarioController();
if(isset($_GET['report'])){
// Require composer autoload

$datatemp=$inst->reporthorario($_GET['report']);
require_once '../vendor/autoload.php';
// Create an instance of the class:
$mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8','format' => 'A4']);
$fecha=date("d/m/Y H:i:s");

$html='

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
	<meta name="google" value="notranslate">

  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<title> Horario </title>
<link href="'.SERVERURL.'/view/css/boot5.css?v5" rel="stylesheet" >
	</head>
  <body >
     <div class="container">
      <div class="col-4 row2">
         <img src="'.SERVERURL.'/assets/logo.png" alt="OKLER Themes" />
       	</div> 	
        <div class="col-4 row2"> 
       <h5>HORARIO </h5>
        </div>
       </div>  
              '.$datatemp.'

  </body>
</html>';

// Write some HTML code:

$mpdf->WriteHTML($html);
// Output a PDF file directly to the browser
$mpdf->Output('Horario '.$fecha.'.pdf', 'I');
	}


	
}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'/"</script>';
}


