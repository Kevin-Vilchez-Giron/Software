<?php


$peticionAjax=true;

require_once "../core/config.php";


if(isset($_POST['save']) || isset($_POST['datatable']) || isset($_GET['btnActivaEliminar']) ||
 isset($_POST['update'])  ||
 isset($_GET['formupdate']) ||
 isset($_GET['validateActiverDelete']) ){
	
	
require_once "../controller/PagosController.php";
 $inst = new PagosController();

if (isset($_POST['datatable'])) {
echo $inst->listPagosController($_REQUEST,$_POST['status']);
}

	if(isset($_GET['btnActivaEliminar'])){
echo $inst->activaDeletePagosController($_GET['id'],$_GET['status']);
	}

 if(isset($_POST['save'])){
echo $inst->savePagosController();	
	}
	 if(isset($_POST['update'])){
echo $inst->updatePagosController();	
	}

		if(isset($_GET['formupdate'])){
echo $inst->fomUpdate();
	}
	if(isset($_GET['validateActiverDelete'])){
echo $inst->valideractivatedelete($_GET['id'],$_GET['status']);
	}


}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/"</script>';
}


