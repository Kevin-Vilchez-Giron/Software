<?php


$peticionAjax=true;

require_once "../core/config.php";


if(isset($_POST['save']) || isset($_POST['datatable']) || isset($_GET['btnActivaEliminar']) ||
 isset($_POST['update'])  ||
 isset($_GET['formupdate']) ||
 isset($_GET['validateActiverDelete']) || isset($_GET['btnpago'])){
	
	
require_once "../controller/AtencionController.php";
 $inst = new AtencionController();

if (isset($_POST['datatable'])) {
echo $inst->listAtencionController($_REQUEST,$_POST['status']);
}

	if(isset($_GET['btnActivaEliminar'])){
echo $inst->activaDeleteAtencionController($_GET['id'],$_GET['status']);
	}

 if(isset($_POST['save'])){
echo $inst->saveAtencionController();	
	}
	 if(isset($_POST['update'])){
echo $inst->updateAtencionController();	
	}

		if(isset($_GET['formupdate'])){
echo $inst->fomUpdate();
	}
	if(isset($_GET['validateActiverDelete'])){
echo $inst->valideractivatedelete($_GET['id'],$_GET['status']);
	}
	if(isset($_GET['btnpago'])){
echo $inst->saverecivo();
	}

}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/"</script>';
}


