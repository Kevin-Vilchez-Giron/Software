<?php


$peticionAjax=true;

require_once "../core/config.php";


if(isset($_POST['save']) || isset($_POST['datatable']) || isset($_GET['btnActivaEliminar']) ||
 isset($_POST['update'])  ||
 isset($_GET['formupdate']) ||
 isset($_GET['validateActiverDelete']) ){
	
	
require_once "../controller/DiagnosticoController.php";
 $inst = new DiagnosticoController();

if (isset($_POST['datatable'])) {
echo $inst->listDiagnosticoController($_REQUEST,$_POST['status']);
}

	if(isset($_GET['btnActivaEliminar'])){
echo $inst->activaDeleteDiagnosticoController($_GET['id'],$_GET['status']);
	}

 if(isset($_POST['save'])){
echo $inst->saveDiagnosticoController();	
	}
	 if(isset($_POST['update'])){
echo $inst->updateDiagnosticoController();	
	}

		if(isset($_GET['formupdate'])){
echo $inst->fomUpdate();
	}
	if(isset($_GET['validateActiverDelete'])){
echo $inst->valideractivatedelete($_GET['id'],$_GET['status']);
	}


}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/"</script>';
}


