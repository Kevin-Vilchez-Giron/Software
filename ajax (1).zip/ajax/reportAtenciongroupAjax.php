<?php
$peticionAjax=true;                                   
require_once "../core/config.php";

if(isset($_GET['report'])){

  
require_once "../controller/AtencionController.php";
 $inst = new AtencionController();
if(isset($_GET['report'])){
// Require composer autoload

$cuerpo=$inst->reportAtencionGroup();



require_once '../vendor/autoload.php';
// Create an instance of the class:
$mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => 'A4']);
$fecha=date("d/m/Y");

$html='

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
				<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<title>ATENCION </title>
<link href="'.SERVERURL.'/view/css/boot5.css?v5" rel="stylesheet" >

	</head>
  <body >
 
  <div class="col-6 row2">
         <img src="'.SERVERURL.'/assets/logo.png" alt="OKLER Themes" />
       	</div> 	
        <div class="col-6 row2"> 
       <h5>REPORTE DE ATENCION</h5>
        </div>
 
 <table id="customers">
<thead>
<tr>
                      <th>#</th>
                     <th style="width=:22%;">Paciente</th>
                      <th style="width=:16%;" >Servicio</th>
                      <th style="width=:3%;">Precio</th>
                      <th style="width=:22%;">Profesional </th>
 <th style="width=:10%;">Estado</th>
                       <th>Fecha</th>

                    </tr>
   </thead>
 <tbody> 
'.$cuerpo.'
                
                  </tbody>
                    
                  
                </table>
  

  </body>
</html>';

// Write some HTML code:

$mpdf->WriteHTML($html);
// Output a PDF file directly to the browser
$mpdf->Output('Documento'.$fecha.'.pdf', 'I');


       }


	
}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'/"</script>';
}


