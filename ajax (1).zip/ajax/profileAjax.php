<?php


$peticionAjax=true;

require_once "../core/config.php";

if(isset($_POST['save']) ||isset($_POST['update'])  ){
	
require_once "../controller/PerfilController.php";
 $inst = new PerfilController();
   session_start();

	 if(isset($_POST['save'])){
echo $inst->updatePerfilController();	
	}

	 if(isset($_POST['update'])){
echo $inst->updatePasswordPerfilController();	
	}


}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/"</script>';
}

