<?php


$peticionAjax=true;

require_once "../core/config.php";

if( isset($_GET['btnActivaEliminar']) || isset($_GET['btnActualizar'])  ){

require_once "../controller/NavController.php";
 $inst = new NavController();


	if(isset($_GET['btnActivaEliminar'])){
echo $inst->activaDeleteNotifyController($_GET['id'],$_GET['status']);
	}

	if(isset($_GET['btnActualizar'])){
require_once "../controller/HomeController.php";
 $inst2 = new HomeController();
echo $inst2->pintarServiciosController();
	}

	
	
}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'login/"</script>';
}


