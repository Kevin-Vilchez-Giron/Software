<?php
$peticionAjax=true;                                   
require_once "../core/config.php";

if(isset($_GET['report'])){

       if(isset($_GET['type']) && $_GET['type']== "pdf"){

       

  
require_once "../controller/MovimientosController.php";
 $inst = new MovimientosController();
if(isset($_GET['report'])){
// Require composer autoload

$cuerpo=$inst->reportMovimientos();
require_once '../vendor/autoload.php';
// Create an instance of the class:
$mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => 'A4']);
$fecha=date("d/m/Y");

$html='

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
				<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<title>Entradas y Salidas </title>
<link href="'.SERVERURL.'/view/css/boot5.css?v5" rel="stylesheet" >

	</head>
  <body >
 
  <div class="col-12 row2">
         <img src="https://usistema.americansoftperu.pe/assets/cabecera.jpeg" alt="OKLER Themes" width="700" height="80"/>
       	</div> 	
       
 
 <table id="customers">
<thead>
<tr>
                      <th>#</th>
                     <th style="width=:22%;">Producto</th>
                      <th style="width=:16%;" >Tipo</th>
                      <th style="width=:16%;">Cantidad</th>
                      <th style="width=:22%;">Area</th>
                    </tr>
   </thead>
 <tbody> 
'.$cuerpo.'
                
                  </tbody>
                </table>
  

  </body>
</html>';

// Write some HTML code:

$mpdf->WriteHTML($html);
// Output a PDF file directly to the browser


$mpdf->Output('Documento'.$fecha.'.pdf', 'I');


     


	  }
       }else{

header("Pragma: public");
header("Expires: 0");
$filename = "entradasalidas.xls";
header("Content-type: application/x-msdownload");
header("Content-Disposition: attachment; filename=$filename");
header("Pragma: no-cache");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
require_once "../controller/MovimientosController.php";
 $inst = new MovimientosController();
$cuerpo=$inst->reportMovimientos();

$html='
 <table id="customers">
<thead>
<tr>
                      <th>#</th>
                     <th style="width=:22%;">Producto</th>
                      <th style="width=:16%;" >Tipo</th>
                      <th style="width=:16%;">Cantidad</th>
                      <th style="width=:22%;">Area</th>
                    </tr>
   </thead>
 <tbody> 
'.$cuerpo.'
                
                  </tbody>
                </table>
  ';
echo $html;

       }
}else{
	session_start();
	session_destroy();
	echo '<script> window.location.href="'.SERVERURL.'/"</script>';
}


