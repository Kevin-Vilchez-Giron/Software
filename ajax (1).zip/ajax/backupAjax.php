<?php
$peticionAjax=true;
require_once "../core/config.php";

if(isset($_GET['process']) || isset($_GET['destroy'])){

	require_once "../controller/BackupController.php";
	$inst = new BackupController();
	    session_start();

	if (isset($_GET['process'])) {
    $inst->saveBackupController();
	}
	if (isset($_GET['destroy'])) {
   echo $inst->destroyfichero();
	}



}else{
	echo '<script> window.location.href="'.SERVERURL.'"</script>';
}

