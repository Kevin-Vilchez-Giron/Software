<?php 
if ($peticionAjax==true) {
	require_once "../model/mainModel.php";
}else{
	require_once "./model/mainModel.php";
}

class LoginController extends mainModel
{
	
	public function signInController(){
 	
  	    $email= mainModel::limpiar_cadena($_POST['email']);
		$password= mainModel::limpiar_cadena($_POST['password']);
		$rememberme="";
		if (isset($_POST['rememberme'])) {
		$rememberme=mainModel::limpiar_cadena($_POST['rememberme']);
		}
  $consulta =mainModel::execute_query("SELECT * FROM tprofesional  
   WHERE email='$email'AND password='$password'");
	
		if($consulta->rowCount()>=1){
			$req = $consulta->fetch(PDO::FETCH_ASSOC);
     $dato=$req['idProfesional'];
     $idPersonal=mainModel::encryption($dato);
      $fullname=$req["nombreUsuario"];
$idProfesional=$req['idProfesional'];
 $consultacargo =mainModel::execute_query("SELECT t1.idCargo,t2.name as namerol,t1.name as nombreProfesional,t1.lastName  FROM tprofesional as t1 INNER JOIN tcargo as t2 ON t1.idCargo  = t2.idCargo WHERE t1.idProfesional ='$idProfesional' ");
			$reqCargo = $consultacargo->fetch(PDO::FETCH_ASSOC);

			
  	    $idCargo=$reqCargo['idCargo'];
  	    $cargo=$reqCargo['namerol'];

        $primername=explode(" ",$fullname);

        $password=mainModel::encryption($password);
	session_start();

       $_SESSION['idAdminClinica']=$idPersonal;
//       $_SESSION['AdminClinica']=$primername[0];
       $_SESSION['AdminClinica']=$reqCargo['nombreProfesional']." ".$reqCargo['lastName'];

       $_SESSION['idcargoAdminClinica']=$idCargo;
       $_SESSION['cargoClinica']=$cargo;
       $_SESSION['token_clinica']=md5(uniqid(mt_rand(),true));
if ($rememberme=="chk_rec") {
   setcookie("email_Clinica",$email,strtotime( '+360 days' ),"/",false, false);
setcookie("pass_Clinica",$password,strtotime( '+360 days' ),"/",false, false);
}
if ($rememberme=="") {
	if (isset($_COOKIE['email_Clinica'])) {
		 setcookie('email_Clinica', null, -1, '/');
 unset($_COOKIE["email_Clinica"]);
  setcookie('pass_Clinica', null, -1, '/');
 unset($_COOKIE["pass_Clinica"]);
	}

}
      header("location: ".SERVERURL."home/");
		}
			else{
       header("location: ".SERVERURL."login?error");
		}

		      header("location: ".SERVERURL."home/");

	}



public function sessionDistroy(){
	session_start();
	session_destroy();
	      header("location: ".SERVERURL."login/");

	//echo '<script> window.location.href="'.SERVERURL.'login/"</script>';

}	

}