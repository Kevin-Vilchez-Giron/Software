
<?php 

if ($peticionAjax) {
  require_once "../model/mainModel.php";
}else{
  require_once "./model/mainModel.php";
}

class HomeController extends mainModel
{

public function getDataGrafic(){
  $cnn = mainModel::conect();
  $dataEntrada = $cnn->query("SELECT MONTH(dateRegister) as Mes , SUM(cantidad) as totalMes from tmovimientos where typeMovimiento ='Entrada' GROUP BY Mes");
    $dataObj = $dataEntrada->fetchAll(PDO::FETCH_ASSOC);
$obj= [];
$reco=1;

foreach ($dataObj as $key => $value) {

for ($i=$reco; $i<=12; $i++) {
 // echo "(".$value["Mes"].") es igual a ".$i;
if($value["Mes"] == $i){
  array_push($obj, $value["totalMes"] );
  $reco = $i+1;

  break;
}else{
   array_push($obj, 0 );
}
     }
     }
   
return json_encode($obj);

}

public function getDataGraficSalida(){
  $cnn = mainModel::conect();
  $dataEntrada = $cnn->query("SELECT MONTH(dateRegister) as Mes , SUM(cantidad) as totalMes from tmovimientos where typeMovimiento ='Salida' GROUP BY Mes");
    $dataObj = $dataEntrada->fetchAll(PDO::FETCH_ASSOC);
$obj= [];
$reco=1;

foreach ($dataObj as $key => $value) {

for ($i=$reco; $i<=12; $i++) {
 // echo "(".$value["Mes"].") es igual a ".$i;
if($value["Mes"] == $i){
  array_push($obj, $value["totalMes"] );
  $reco = $i+1;

  break;
}else{
   array_push($obj, 0 );
}
     }
     }
   
return json_encode($obj);

}

  public function totalEntradasSalidas($tipo){
    $cnn = mainModel::conect();
    if($tipo=="Entrada"){
  $dataEntrada = $cnn->query("SELECT SUM(cantidad) as numeroEntradas,(SELECT SUM(stock) as numProduct from tproduct ) as numProductos  from tmovimientos where typeMovimiento = '".$tipo."'");
    $dataObj = $dataEntrada->fetch(PDO::FETCH_ASSOC);

    $entradasMovimientos = (int) $dataObj["numeroEntradas"];
    $numProductos =  (int) $dataObj["numProductos"];

    $total = $entradasMovimientos + $numProductos;
return $total;
    }else if($tipo=="Salida"){
 $dataEntrada = $cnn->query("SELECT SUM(cantidad) as numeroEntradas  from tmovimientos where typeMovimiento = '".$tipo."'");
    $dataObj = $dataEntrada->fetch(PDO::FETCH_ASSOC);
$entradasMovimientos = (int) $dataObj["numeroEntradas"];
   

    $total = $entradasMovimientos ;

return $total;
    }else{
 $dataEntrada = $cnn->query("SELECT SUM(cantidad) as numeroEntradas,(SELECT SUM(stock) as numProduct from tproduct ) as numProductos  from tmovimientos where typeMovimiento = 'Salida'");
    $dataObj = $dataEntrada->fetch(PDO::FETCH_ASSOC);
$entradasMovimientos = (int) $dataObj["numeroEntradas"];
    $numProductos =  (int) $dataObj["numProductos"];
//echo $entradasMovimientos."---".$numProductos;
    if($entradasMovimientos != 0 && $numProductos){
       $total = $entradasMovimientos + $numProductos;
    $total2= $total / $numProductos;
return round($total2, 2);
}else{
  return 0;
}
   
  
    }
  
  }

   public function pintarServiciosController(){

    $cnn = mainModel::conect();

  $data = $cnn->query("SELECT * from servicio where status = 1");
    $dataObject = $data->fetchAll(PDO::FETCH_ASSOC);
    $template="";

foreach ($dataObject as $index => $item) {
   $data2 = $cnn->query("
    SELECT t1.nticket ,t2.nombres,t2.apellidoPaterno,t2.apellidoMaterno,t3.nombre as nombreServicio ,t1.status FROM atencion as t1 INNER JOIN paciente as t2 on t1.idPaciente = t2.idPaciente INNER JOIN servicio as t3 on t1.idServicio = t3.idServicio WHERE (t1.status = 1 OR t1.status = 2) and t1.idServicio =  ".$item["idServicio"]." and (CAST(t1.fecha AS DATE ) = CURDATE() )  ORDER BY t1.nticket ASC Limit 25");
    $dataObject2 = $data2->fetchAll(PDO::FETCH_ASSOC);
    $template2="";

foreach ($dataObject2 as $index2 => $item2) {
   $estado="";
  switch ($item2['status']) {
    case 0:
        $estado = '<span class="badge bg-danger">Cancelado</span>';
        break;
   
    case 1:
        $estado = '<span class="badge bg-primary">Registrado</span>';
        break;
    case 2:
       $estado = '<span class="badge bg-warning text-dark">Triaje</span>';
        break;
    case 3:
          $estado = '<span class="badge bg-info text-dark">Atendido</span>';
        break;
    
    default:
        // code...
        break;
}
$parpadeo="";
if($index2==0){
$parpadeo="parpadea text";
}

  $template2.='  <tr class="'.$parpadeo.'"> 
                    <td>'.$item2["nticket"].'</td>
                    <td>'.$item2["nombres"]." ".$item2["apellidoPaterno"]." ".$item2["apellidoMaterno"].'</td>
                    <td>'.$item2["nombreServicio"].'</td>
                    <td>'.$estado.'</td>
                </tr>';

 

}

 $template.='<div class="col-md-6 col-lg-6 col-xl-4">
                <section class="panel panel-featured-left panel-featured-primary">
                  <div class="panel-body">
                    <div class="widget-summary">
                      
                      <div class="widget-summary-col">
                          <h4 class="title">'.$item["nombre"].' / FECHA : '. date('d/m/Y').' </h4>
                        <table class="table table-striped">
                          <thead>
                            <tr>
                              <td>Turno #</td>
                              <td>Persona</td>
                              <td>Especialidad</td>
                              <td>Estado</td>
                             
                            </tr>
                          </thead>
                          <tbody>
                           '.$template2.'
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </section>
              </div>';
}

   
    return $template;
}
  
}