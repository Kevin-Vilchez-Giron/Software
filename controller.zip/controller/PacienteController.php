 <?php 
if ($peticionAjax) {
  require_once "../model/PacienteModel.php";
}else{
  require_once "./model/PacienteModel.php";
}

class PacienteController extends PacienteModel{



  public function listPacienteController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idPaciente',
    1 =>  'apellidoPaterno',
    2=> 'nombres',
    3 =>  'sexo',
    4 =>  'edad',
    5 =>  'dni',
    6 =>  'dateRegister',
);  
$index=0;
if ($request['order'][0]['column']!=7) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==7) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,(SELECT TIMESTAMPDIFF (YEAR, t1.fechaNacimiento, CURDATE())) as edad   FROM paciente as t1  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.nombres Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.apellidoPaterno Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.apellidoMaterno Like '%".$request['search']['value']."%' ";
    $sql.= "OR t1.dni Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;

while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
$se="M";
if($row['sexo']==2){
    $se="F";
}

       $encryp=mainModel::encryption($row['idPaciente']);
     $row['idPaciente']=$encryp;
    $subdata[]=$contador; 
    $subdata[]=$row['apellidoPaterno']." ".$row['apellidoMaterno'];
     $subdata[]=$row['nombres'];
     $subdata[]=$se; 
     $subdata[]=$row['edad']; 
        $subdata[]=$row['dni'];
        $subdata[]=$row['dateRegister']; 
 
   // $subdata[]="   <a href='".$linkfile."' target='_BLANK' class='btn btn-info mr-xs btn-xs ' >         
    //   <i class='text-light fa  fa-download fa-lg'></i> ".$row['document']." </a>"; 
   // $subdata[]=$row['groupdefault']; 
   // $test=SERVERURL."ajax/criterionrepotAjax.php?report=".$row['idPaciente'];  <a href='".$test."' target='_BLANK' class='btn btn-warning mr-xs btn-xs ' >   <i class='text-light fa  fa-file-pdf-o fa-lg'></i></a>

    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'pacienteAjax'."`,`".SERVERURL."`,`".'idPaciente'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'pacienteAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idPaciente=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeletePacienteController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("paciente",$idElemento,$status,"idPaciente")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idPaciente  =mainModel::limpiar_cadena($_GET['idPaciente']);
      $idPaciente   =mainModel::decryption($idPaciente);
  $consulta =mainModel::execute_query("SELECT t1.*,(SELECT TIMESTAMPDIFF (YEAR, t1.fechaNacimiento, CURDATE())) as edad  FROM paciente as t1  WHERE t1.idPaciente=$idPaciente");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
    $sexo =$req['sexo'];
    $idTipoSangre =$req['idTipoSangre'];
    $tmpSex = '<option selected value="">Seleccionar</option>
    <option  value="1">Masculino</option>
                            <option value="2">Femenino</option>';
if($sexo ==1){
    $tmpSex = '<option  value="">Seleccionar</option>
    <option selected value="1">Masculino</option>
                            <option value="2">Femenino</option>';
                        }else if($sexo ==2){
     $tmpSex = '<option  value="">Seleccionar</option>
     <option  value="1">Masculino</option>
                            <option selected value="2">Femenino</option>';                       
                        }

 
$saveUpdate='update';
$cuerpo=' <div class="row">

  
<div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Nombres </label>
                      <input type="text" name="nombres" maxlength="60" class="form-control nombres"  value="'.$req['nombres'].'"   >
                      </div>
             </div> 
              <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Apellido Paterno </label>
                      <input type="text" name="apellidoPaterno" maxlength="30" class="form-control apellidoPaterno"   value="'.$req['apellidoPaterno'].'"  >
                      </div>
             </div> 
              <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Apellido Materno </label>
                      <input type="text" name="apellidoMaterno" maxlength="30" class="form-control apellidoMaterno"   value="'.$req['apellidoMaterno'].'"   >
                      </div>
             </div> 

             <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Fecha Nacimiento </label>
                      <input type="date" name="fechaNacimiento"  class="form-control fechaNacimiento" value="'.$req['fechaNacimiento'].'"     >
                      </div>
             </div> 
              <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">direccion </label>
                      <input type="text" name="direccion" maxlength="200" class="form-control direccion" value="'.$req['direccion'].'"     >
                      </div>
             </div> 

      <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Numero SIS</label>
 <input type="number" name="numeroSis" class="form-control numeroSis" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['numeroSis'].'"  >
                      </div>
          </div>
          <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Celular</label>
 <input type="number" name="numCelular" class="form-control numCelular" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['numCelular'].'">
                      </div>
          </div>


 <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Email</label>
<input type="text" name="email" maxlength="50" class="form-control email"   value="'.$req['email'].'"   >
                      </div>
          </div>
           <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Ocupacion</label>
<input type="text" name="ocupacion" maxlength="50" class="form-control ocupacion" value="'.$req['ocupacion'].'"     >
                      </div>
          </div>

             <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Responsable</label>
<input type="text" name="responsable" maxlength="50" class="form-control responsable"    value="'.$req['responsable'].'"   >
                      </div>
          </div>

 <div class="col-sm-2 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Sexo <span class="required">*</span></label>
                        <select class="form-control mb-md sexo " name="sexo" required="">
                            '.$tmpSex.'
                          </select>
                      </div>
                    </div>



 <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Dni</label>
 <input type="number" name="dni" class="form-control dni" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)"  value="'.$req['dni'].'" >
                      </div>
          </div>
          <div class="col-sm-2 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Tipo de Sangre <span class="required">*</span></label>
                        <select class="form-control mb-md idTipoSangre " name="idTipoSangre" required="">
                              '.mainModel::getListAuto("SELECT * FROM tiposangre","idTipoSangre","nombre",$idTipoSangre,"update").'
                          </select>
                      </div>
                    </div>

                    <div class="col-sm-5 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Intervenciones Quirurgicas </label>
                      <input type="text" name="intervencionesQuirurgicas" maxlength="200" class="form-control intervencionesQuirurgicas"    value="'.$req['intervencionesQuirurgicas'].'" >
                      </div>
             </div> 
                  <div class="col-sm-5 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Alergias </label>
                      <input type="text" name="alergias" maxlength="200" class="form-control alergias"  value="'.$req['alergias'].'"    >
                      </div>
             </div> 
              <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Edad</label>
<input type="text" name="email" maxlength="50" class="form-control email"   value="'.$req['edad'].' años"   >
                      </div>
          </div>


                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Paciente";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


    <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Nombres </label>
                      <input type="text" name="nombres" maxlength="60" class="form-control nombres"     >
                      </div>
             </div> 
              <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Apellido Paterno </label>
                      <input type="text" name="apellidoPaterno" maxlength="30" class="form-control apellidoPaterno"     >
                      </div>
             </div> 
              <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Apellido Materno </label>
                      <input type="text" name="apellidoMaterno" maxlength="30" class="form-control apellidoMaterno"     >
                      </div>
             </div> 

             <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Fecha Nacimiento </label>
                      <input type="date" name="fechaNacimiento"  class="form-control fechaNacimiento"     >
                      </div>
             </div> 
              <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">direccion </label>
                      <input type="text" name="direccion" maxlength="200" class="form-control direccion"     >
                      </div>
             </div> 

      <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Numero SIS</label>
 <input type="number" name="numeroSis" class="form-control numeroSis" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>
          <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Celular</label>
 <input type="number" name="numCelular" class="form-control numCelular" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>


 <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Email</label>
<input type="text" name="email" maxlength="50" class="form-control email"     >
                      </div>
          </div>
           <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Ocupacion</label>
<input type="text" name="ocupacion" maxlength="50" class="form-control ocupacion"     >
                      </div>
          </div>

             <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Responsable</label>
<input type="text" name="responsable" maxlength="50" class="form-control responsable"     >
                      </div>
          </div>

 <div class="col-sm-2 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Sexo <span class="required">*</span></label>
                        <select class="form-control mb-md sexo " name="sexo" required="">
                            <option value="1">Masculino</option>
                            <option value="2">Femenino</option>
                          </select>
                      </div>
                    </div>



 <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Dni</label>
 <input type="number" name="dni" class="form-control dni" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>

          
                    <div class="col-sm-5 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Intervenciones Quirurgicas </label>
                      <input type="text" name="intervencionesQuirurgicas" maxlength="200" class="form-control intervencionesQuirurgicas"     >
                      </div>
             </div> 
                  <div class="col-sm-5 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Alergias </label>
                      <input type="text" name="alergias" maxlength="200" class="form-control alergias"     >
                      </div>
             </div> 
              <div class="col-sm-2 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Tipo de Sangre <span class="required">*</span></label>
                        <select class="form-control mb-md idTipoSangre " name="idTipoSangre" required="">
                              '.mainModel::getList("SELECT * FROM tiposangre","idTipoSangre").'
                          </select>
                      </div>
                    </div>


</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idPaciente"  name="idPaciente" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function savePacienteController(){
    
$dni=mainModel::limpiar_cadena($_POST['dni']);
$apellidoPaterno=mainModel::limpiar_cadena($_POST['apellidoPaterno']);
$apellidoMaterno=mainModel::limpiar_cadena($_POST['apellidoMaterno']);
$nombres=mainModel::limpiar_cadena($_POST['nombres']);
$fechaNacimiento=mainModel::limpiar_cadena($_POST['fechaNacimiento']);
$direccion=mainModel::limpiar_cadena($_POST['direccion']);
$numeroSis=mainModel::limpiar_cadena($_POST['numeroSis']);
$sexo=mainModel::limpiar_cadena($_POST['sexo']);
$intervencionesQuirurgicas=mainModel::limpiar_cadena($_POST['intervencionesQuirurgicas']);
$alergias=mainModel::limpiar_cadena($_POST['alergias']);
$email=mainModel::limpiar_cadena($_POST['email']);
$ocupacion=mainModel::limpiar_cadena($_POST['ocupacion']);
$responsable=mainModel::limpiar_cadena($_POST['responsable']);
$numCelular=mainModel::limpiar_cadena($_POST['numCelular']);
$idTipoSangre=mainModel::limpiar_cadena($_POST['idTipoSangre']);

 $fNacimiento=$fechaNacimiento;
    $fNacimiento = str_replace('/', '-', $fNacimiento);
    $inicio = strtotime($fNacimiento); //Convierte el string a formato de fecha en php
    $fechaNacimiento = date('Y-m-d',$inicio);



      $consultanumeroSis = mainModel::execute_query("SELECT * FROM paciente WHERE numeroSis='$numeroSis'  ");
  $vnombre=$consultanumeroSis->rowCount();

  $consultaDni = mainModel::execute_query("SELECT * FROM paciente WHERE dni='$dni'  ");
  $vdni=$consultaDni->rowCount();
if($vnombre>=1 || $vdni>=1 ){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe un  paciente con este Numero de SIS o DNI"];
}
if ($vnombre<1) {
 
 $data=[ "dni"=>$dni,
         "apellidoPaterno"=>$apellidoPaterno,
         "apellidoMaterno"=>$apellidoMaterno,
         "nombres"=>$nombres,
         "fechaNacimiento"=>$fechaNacimiento,
         "direccion"=>$direccion,
         "numeroSis"=>$numeroSis,
         "sexo"=>$sexo,
         "intervencionesQuirurgicas"=>$intervencionesQuirurgicas,
         "alergias"=>$alergias,
         "email"=>$email,
         "ocupacion"=>$ocupacion,
         "responsable"=>$responsable,
         "numCelular"=>$numCelular,
         "idTipoSangre"=>$idTipoSangre
      ];
if (PacienteModel::savePacienteModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updatePacienteController(){
    $idPaciente =mainModel::limpiar_cadena($_POST['idPaciente']);
      $idPaciente  =mainModel::decryption($idPaciente);
$dni=mainModel::limpiar_cadena($_POST['dni']);
$apellidoPaterno=mainModel::limpiar_cadena($_POST['apellidoPaterno']);
$apellidoMaterno=mainModel::limpiar_cadena($_POST['apellidoMaterno']);
$nombres=mainModel::limpiar_cadena($_POST['nombres']);
$fechaNacimiento=mainModel::limpiar_cadena($_POST['fechaNacimiento']);
$direccion=mainModel::limpiar_cadena($_POST['direccion']);
$numeroSis=mainModel::limpiar_cadena($_POST['numeroSis']);
$sexo=mainModel::limpiar_cadena($_POST['sexo']);
$intervencionesQuirurgicas=mainModel::limpiar_cadena($_POST['intervencionesQuirurgicas']);
$alergias=mainModel::limpiar_cadena($_POST['alergias']);
$email=mainModel::limpiar_cadena($_POST['email']);
$ocupacion=mainModel::limpiar_cadena($_POST['ocupacion']);
$responsable=mainModel::limpiar_cadena($_POST['responsable']);
$numCelular=mainModel::limpiar_cadena($_POST['numCelular']);
$idTipoSangre=mainModel::limpiar_cadena($_POST['idTipoSangre']);

 $fNacimiento=$fechaNacimiento;
    $fNacimiento = str_replace('/', '-', $fNacimiento);
    $inicio = strtotime($fNacimiento); //Convierte el string a formato de fecha en php
    $fechaNacimiento = date('Y-m-d',$inicio);

      $consultaName = mainModel::execute_query("SELECT * FROM paciente WHERE dni='$dni' and idPaciente!=$idPaciente ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El dni ya esta registrado anteriormente"];
}
if ($vnombre<1) {

  $data=[
        "idPaciente"=>$idPaciente,
          "dni"=>$dni,
         "apellidoPaterno"=>$apellidoPaterno,
         "apellidoMaterno"=>$apellidoMaterno,
         "nombres"=>$nombres,
         "fechaNacimiento"=>$fechaNacimiento,
         "direccion"=>$direccion,
         "numeroSis"=>$numeroSis,
         "sexo"=>$sexo,
         "intervencionesQuirurgicas"=>$intervencionesQuirurgicas,
         "alergias"=>$alergias,
         "email"=>$email,
         "ocupacion"=>$ocupacion,
         "responsable"=>$responsable,
         "numCelular"=>$numCelular,
         "idTipoSangre"=>$idTipoSangre
      ];

      
if (PacienteModel::updatePacienteModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 