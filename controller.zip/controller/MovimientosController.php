<?php if ($peticionAjax) {
  require_once "../model/MovimientosModel.php";
}else{
  require_once "./model/MovimientosModel.php";
}

class MovimientosController extends MovimientosModel{


public function reportMovimientos(){
$extra=" ";
$table="";
$txtst="";

    $consultareport = mainModel::execute_query("SELECT t1.*,t2.name as nameProduct, t3.name as nameArea  from tmovimientos as t1 INNER JOIN  tproduct as t2 on t1.idProduct= t2.idProduct INNER JOIN tarea as t3 on t1.idArea = t3.idArea ORDER BY t1.idMovimiento ASC");
   $reqcash = $consultareport->fetchAll(PDO::FETCH_ASSOC);
    $datos='';
    foreach ($reqcash as $key => $row) {
      $ac=$key+1;
$table.=" <tr>
        <td> ".$ac."
        </td>
                     <td>
               ".$row['nameProduct']. " 
                     </td>
                     <td>
                      ".$row['typeMovimiento']."
                     </td>
                      <td>
                      ".$row['cantidad']."
                     </td>
                       <td>
                      ".$row['nameArea']." 
                     </td>
</tr>
 ";

}
return $table;
}


public function listespecialidadReport(){
                  $html=mainModel::getList("SELECT * FROM especialidad","idEspecialidad");
return $html;
}


  public function listMovimientosController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'dateRegister',
   1 =>  'codProduct',
    2 =>  'nameProduct',
    3=> 'typeMovimiento',
    4=> 'nameArea',
    5=>  'cantidad'
);  
$index=0;
if ($request['order'][0]['column']!=5) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==5) {
$index=0;
}
//inicioalgoritmo

 $sqlfechas="";

 
    if($_POST['fecha1']!=""){
      $fech1=mainModel::limpiar_cadena($_POST['fecha1']);
    $fech1 = str_replace('/', '-', $fech1);

      $f1 = strtotime($fech1); //Convierte el string a formato de fecha en php
      $fecha1 = date('Y-m-d',$f1);
      $sqlfechas='and CAST(t1.dateRegister AS DATE ) >= "'.$fecha1.'"';          
    }
    
    if($_POST['fecha2']!=""){
      $fech2=mainModel::limpiar_cadena($_POST['fecha2']);
          $fech2 = str_replace('/', '-', $fech2);

      $f2 = strtotime($fech2); //Convierte el string a formato de fecha en php
      $fecha2 = date('Y-m-d',$f2);
      $sqlfechas='and CAST(t1.dateRegister AS DATE ) <= "'.$fecha2.'"';    
    }
    
    if ($_POST['fecha1']!="" && $_POST['fecha2']) {
      $fech1=mainModel::limpiar_cadena($_POST['fecha1']);
         $fech1 = str_replace('/', '-', $fech1);

      $f1 = strtotime($fech1); //Convierte el string a formato de fecha en php
      $fecha1 = date('Y-m-d',$f1);
      $fech2=mainModel::limpiar_cadena($_POST['fecha2']);
                $fech2 = str_replace('/', '-', $fech2);
      $f2 = strtotime($fech2); //Convierte el string a formato de fecha en php
      $fecha2 = date('Y-m-d',$f2);   
      $sqlfechas='and CAST(t1.dateRegister AS DATE ) BETWEEN "'.$fecha1.'" and "'.$fecha2.'"   ';    
    }

    if ($_POST['labbusq']!="" && $_POST['labbusq']!="0" ) {
  $client=mainModel::limpiar_cadena($_POST['labbusq']);
  $sqlfechas.=' and t1.idProduct='.$client;
}





//fin algoritmo
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.name as nameArea, t3.name as nameProduct, t3.codProduct  FROM tmovimientos as t1 INNER JOIN tarea as t2 on t1.idArea = t2.idArea INNER JOIN tproduct as t3 on t1.idProduct = t3.idProduct INNER JOIN tprofesional t4 on t1.idProfesional = t4.idProfesional    WHERE t1.status=$status  $sqlfechas";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t3.name Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.name Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.typeMovimiento Like '%".$request['search']['value']."%' )";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

    $color="verde";
   $tipo = "Entrada";
   if($tipo == $row["typeMovimiento"]) {
        $color="verde";
   } else{
    $color="rojo";
   }           
   $encryp = mainModel::encryption($row['idMovimiento']);
    $subdata[]=date("d/m/Y",strtotime($row['dateRegister'])); 
    $subdata[]=$row['codProduct'];
    $subdata[]=$row['nameProduct'];


    $subdata[]='<span class="badge '.$color.'">'.$row["typeMovimiento"].'</span>';
    $subdata[]=$row['nameArea'];
     $subdata[]=$row['cantidad'];
   /**
    * <a onclick='rellEdit(`".$encryp."`,`".'movimientosAjax'."`,`".SERVERURL."`,`".'idMovimiento'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
    * **/
    $subdata[]="
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'movimientosAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> Eliminar <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }

public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idProduct=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}

    public function activaDeleteMovimientosController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("tmovimientos",$idElemento,$status,"idMovimiento")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idMovimiento  =mainModel::limpiar_cadena($_GET['idMovimiento']);
      $idMovimiento   =mainModel::decryption($idMovimiento);
  $consulta =mainModel::execute_query("SELECT t1.* from tmovimientos as t1  WHERE t1.idMovimiento=$idMovimiento");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);


       $idArea =$req['idArea'];
       $idProduct =$req['idProduct'];


$saveUpdate='update';
$cuerpo=' <div class="row">
<div class="col-sm-12 mb-xs">
 <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                      <input type="hidden" name="tipo" maxlength="50" class="form-control tipo" value="Entrada"    >
                        <label class="control-label">Tipo de Movimiento <span class="required">*</span></label>
                        <select class="form-control mb-md typeMovimiento " name="typeMovimiento" required="">
                           <option value="Entrada">Entrada</option>
                           <option value="Salida">Salida (Asignaciona una area)</option>
                          </select>
                      </div>
                    </div>

    <div class="col-sm-8 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Product </label>
                        <select class="form-control mb-md idProduct " name="idProduct" required="">
                           '.mainModel::getListAuto("SELECT * FROM tproduct","idProduct","name",$idProduct,"update").'
                          </select>
                      </div>
             </div> 
              </div> 


<div class="col-sm-12 mb-xs"> 
    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Cantidad </label>
                      <input type="text" name="cantidad" maxlength="50" class="form-control cantidad"   value="'.$req['cantidad'].'"  >
                      </div>
             </div> 
             
             

             <div class="col-sm-8 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Area <span class="required">*</span></label>
                        <select class="form-control mb-md idArea " name="idArea" required="" disabled>
                           '.mainModel::getListAuto("SELECT * FROM tarea","idArea","name",$idArea,"update").'
                          </select>
                      </div>
                    </div>
                     </div>
            

                </div>';

return $cuerpo;
}

public function listProductSearch2(){
   $data = mainModel::execute_query("SELECT t1.idProduct ,t1.codProduct,t1.stock, t1.name from tproduct as t1  WHERE t1.status = 1");
    $request = $data->fetchAll(PDO::FETCH_ASSOC);
      return json_encode($request);
}


public function listProductSearch(){
   $data = mainModel::listProduct(1);
      return $data;
}

public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
$datoslist="";
$titulo="Registro de Usuario";
$txtb='Guardar';

$html2= self::listProductSearch();
$cuerpo=' <div class="row caja'.$saveUpdate.'">

<div class="col-sm-12 mb-xs">
 <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                      <input type="hidden" name="tipo" maxlength="50" class="form-control tipo" value="Entrada"    >
                        <label class="control-label">Tipo de Movimiento <span class="required">*</span></label>
                        <select class="form-control mb-md typeMovimiento " name="typeMovimiento" required="">
                           <option value="Entrada">Entrada</option>
                           <option value="Salida">Salida (Asignaciona una area)</option>
                          </select>
                      </div>
                    </div>

<div class="col-sm-8 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Producto  </label>
                <select id="idProduct" name="idProduct" class="form-control idProduct with-ajaxclient" data-live-search="true" data-size="5"    tabindex="-1" title="" >
                            '.$html2.'
                          </select>
                      </div>
                    </div>
                    </div>

                    <div class="col-sm-12 mb-xs">
<div class="col-sm-8 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Area a Asignar <span class="required">*</span></label>
                        <select class="form-control mb-md idArea " name="idArea" required="" disabled>
                        '.mainModel::getList("SELECT * FROM tarea","idArea").'
                          </select>
                      </div>
                    </div>

               <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Cantidad </label>
                      <input type="number" name="cantidad" maxlength="50" class="form-control cantidad"     >
                      </div>
             </div> 

               </div>

               

</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idProduct"  name="idProduct" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveMovimientosController(){
      session_start();

      $tipo=mainModel::limpiar_cadena($_POST['tipo']);
$idProduct=mainModel::limpiar_cadena($_POST['idProduct']);
$cantidad=mainModel::limpiar_cadena($_POST['cantidad']);
$idArea=1;
if($tipo=="Salida"){
    $idArea=mainModel::limpiar_cadena($_POST['idArea']);
}

$typeMovimiento=mainModel::limpiar_cadena($_POST['typeMovimiento']);

$idProfesional  = mainModel::decryption($_SESSION['idAdminClinica']);

$queryStock = mainModel::execute_query("SELECT stock FROM tproduct where idProduct =  ".$idProduct);
 $stockq =   $queryStock->fetch(PDO::FETCH_ASSOC);
 $stock = (int) $stockq["stock"];

$cantidad = (int) $cantidad;

 $nuevaCantidad =  $stock - $cantidad;

 $cantidadEntrada =  $stock + $cantidad;

if($stock <= $cantidad && $tipo == "Salida"){
       $msg=["alert"=>"duplicidad","campo"=>"La cantidad seleccionada supera el limite que tenemos en stock , actualmente contamos con : ".$stock." de stock en el producto seleccionado "];
   }else{
 $data=[ "idProduct"=>$idProduct,
         "cantidad"=>$cantidad,
         "idArea"=>$idArea,
         "typeMovimiento"=>$typeMovimiento,
         "nuevaCantidad"=> $nuevaCantidad,
         "idProfesional"=>$idProfesional,
         "tipo"=>$tipo,
         "cantidadEntrada"=>$cantidadEntrada
      ];
if (MovimientosModel::saveMovimientosModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}
}

 return mainModel::mensajeRespuesta($msg);
 }

    public function updateMovimientosController(){

    $labbusq =mainModel::decryption($_POST['labbusq']);
$name=mainModel::limpiar_cadena($_POST['name']);
$cantidad=mainModel::limpiar_cadena($_POST['cantidad']);
$idMedida=mainModel::limpiar_cadena($_POST['idMedida']);
$idCategoria=mainModel::limpiar_cadena($_POST['idCategoria']);
$precio=mainModel::limpiar_cadena($_POST['precio']);
/**
 $queryArea = mainModel::execute_query("SELECT abreviatura FROM tcategoria where idCategoria =  ".$idCategoria);
 $nameAreaQ =   $queryArea->fetch(PDO::FETCH_ASSOC);
 $nameArea = $nameAreaQ["abreviatura"];**/




  $data=[
        "idProduct"=>$idProduct,
        "name"=>$name,
         "cantidad"=>$cantidad,
         "idMedida"=>$idMedida,
         "idCategoria"=>$idCategoria,
         "precio"=>$precio
      ];

      
if (MovimientosModel::updateMovimientosModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}


   
      return mainModel::mensajeRespuesta($msg);
    }

}

 