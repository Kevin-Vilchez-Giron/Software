<?php if ($peticionAjax) {
  require_once "../model/ProfesionalModel.php";
}else{
  require_once "./model/ProfesionalModel.php";
}

class ProfesionalController extends ProfesionalModel{

public function listespecialidadReport(){
                  $html=mainModel::getList("SELECT * FROM especialidad","idEspecialidad");
return $html;
}
public function reportProfessionGroup(){
        $extra=" ";
$table="";
$txtst="";
if(isset($_GET['specialidad'])){
if($_GET['specialidad']!="" && $_GET['specialidad']!=NULL){
    $specialidad=mainModel::limpiar_cadena($_GET['specialidad']);
    $txtst=" and t1.idEspecialidad=$specialidad ";
}

}

    $consultareport = mainModel::execute_query("SELECT t1.*,t2.name as nameCargo FROM tprofesional as t1 INNER JOIN tcargo as t2 ON t1.idCargo =t2.idCargo  WHERE t1.status=1 ".$txtst." ORDER BY t1.idProfesional    ASC");
   $reqcash = $consultareport->fetchAll(PDO::FETCH_ASSOC);
    $datos='';
    foreach ($reqcash as $key => $row) {
      $ac=$key+1;
$table.=" <tr>
        <td> ".$ac."
        </td>
                     <td>
               ".$row['lastName']. " ".$row['dni']."
                     </td>
                     <td>
                      ".$row['name']."
                     </td>
                      <td>
                      ".$row['nombreCargo']."
                     </td>
                       <td>
                      ".$row['dni']." 
                     </td>
</tr>
 ";

}
return $table;
}

  public function listProfesionalController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idProfesional',
    1 =>  'name',
    2=> 'lastName',
     3=> 'cargo',
    4 =>  'dni',
    5=> 'email'
);  
$index=0;
if ($request['order'][0]['column']!=5) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==5) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.name as nameCargo FROM tprofesional as t1 INNER JOIN tcargo as t2 ON t1.idCargo =t2.idCargo   WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.name Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.lastName Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.dni Like '%".$request['search']['value']."%' ";
    $sql.= "OR t2.nameCargo Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idProfesional']);
     $row['idProfesional']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['name']; 
    $subdata[]=$row['lastName'];
    $subdata[]=$row['nameCargo'];
    $subdata[]=$row['email'];
        $subdata[]=$row['dni']; 
 
   // $subdata[]="   <a href='".$linkfile."' target='_BLANK' class='btn btn-info mr-xs btn-xs ' >         
    //   <i class='text-light fa  fa-download fa-lg'></i> ".$row['document']." </a>"; 
   // $subdata[]=$row['groupdefault']; 
   // $test=SERVERURL."ajax/criterionrepotAjax.php?report=".$row['idProfesional'];  <a href='".$test."' target='_BLANK' class='btn btn-warning mr-xs btn-xs ' >   <i class='text-light fa  fa-file-pdf-o fa-lg'></i></a>

    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'profesionalAjax'."`,`".SERVERURL."`,`".'idProfesional'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'profesionalAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }

public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idProfesional=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}

    public function activaDeleteProfesionalController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("profesional",$idElemento,$status,"idProfesional")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idProfesional  =mainModel::limpiar_cadena($_GET['idProfesional']);
      $idProfesional   =mainModel::decryption($idProfesional);
  $consulta =mainModel::execute_query("SELECT t1.* ,t2.name as nameCargo FROM tprofesional as t1 INNER JOIN tcargo as t2 ON t1.idCargo =t2.idCargo  WHERE t1.idProfesional=$idProfesional");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);

     $idCargo =$req['idCargo'];

 
$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Profesional </label>
                      <input type="text" name="name" maxlength="60" class="form-control name" value="'.$req['name'].'"    >
                      </div>
             </div> 

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">A.Paterno </label>
                      <input type="text" name="lastName" maxlength="50" class="form-control lastName"   value="'.$req['lastName'].'"  >
                      </div>
             </div> 
             
             

              <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Documento Identidad</label>
 <input type="number" name="dni" class="form-control dni" min="1" max="99999999999" data-maxlength="11" oninput="this.value=this.value.slice(0,this.dataset.maxlength)"   value="'.$req['dni'].'">
                      </div>
          </div>
 



 
                    <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Cargo <span class="required">*</span></label>
                        <select class="form-control mb-md idCargo " name="idCargo" required="">
                            '.mainModel::getListAuto("SELECT * FROM tcargo","idCargo","name",$idCargo,"update").'
                     
                          </select>
                      </div>
                    </div>


                     <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Email </label>
                      <input type="text" name="email" maxlength="50" class="form-control email" value="'.$req['email'].'" >
                      </div>
             </div> 
             <div class="col-sm-4 mb-xs"> 
             <div class="form-group">
                      <label class="control-label">Clave </label>
                      <input type="text" name="password" maxlength="50" class="form-control password" value="'.$req['password'].'" >
                       <input type="hidden" name="idProfesional" maxlength="50" class="form-control idProfesional" value="'.$req['idProfesional'].'" >
                      </div>
             </div> 

                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
$datoslist="";
$titulo="Registro de Usuario";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">
    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Nombres </label>
                      <input type="text" name="name" maxlength="60"   class="form-control name"     >
                      </div>
             </div>
               <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Apellidos </label>
                      <input type="text" name="lastName" maxlength="50" class="form-control lastName"     >
                      </div>
             </div> 
               <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">EMAIL </label>
                      <input type="text" name="email" maxlength="50" class="form-control email" >
                      </div>
             </div> 
              <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">PASSWORD </label>
                      <input type="text" name="password" maxlength="50" class="form-control password" >
                      </div>
             </div> 
              <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Documento Identidad</label>
 <input type="number" name="dni" class="form-control dni" min="1" max="99999999999" data-maxlength="11" oninput="this.value=this.value.slice(0,this.dataset.maxlength)"   >
                      </div>
          </div>
      

                     <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Cargo <span class="required">*</span></label>
                        <select class="form-control mb-md idCargo " name="idCargo" required="">
                            '.mainModel::getList("SELECT * FROM tcargo","idCargo").'
                          </select>
                      </div>
                    </div>

               

</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idProfesional"  name="idProfesional" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveProfesionalController(){
      
$name=mainModel::limpiar_cadena($_POST['name']);
$lastName=mainModel::limpiar_cadena($_POST['lastName']);
$dni=mainModel::limpiar_cadena($_POST['dni']);
//nombreUsuario,clave
$email=mainModel::limpiar_cadena($_POST['email']);
$password=mainModel::limpiar_cadena($_POST['password']);
$idCargo=mainModel::limpiar_cadena($_POST['idCargo']);
//documentoIdentidad



  $consultaLoguin = mainModel::execute_query("SELECT * FROM tprofesional WHERE email='$email'  ");
  $vloguin=$consultaLoguin->rowCount();

  $consultaDni = mainModel::execute_query("SELECT * FROM tprofesional WHERE dni='$dni'  ");
  $vdni=$consultaDni->rowCount();
if( $vdni>=1  ){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe un  paciente con este documento de Identidad "];
}
if( $vloguin>=1  ){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe un  paciente con este Loguin "];
}
if ($vdni<1 || $vloguin <= 1 ) {

 $data=[ "name"=>$name,
         "lastName"=>$lastName,
         "dni"=>$dni,
         "email"=>$email,
         "password"=>$password,
         "idCargo"=>$idCargo
      ];
if (ProfesionalModel::saveProfesionalModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}

 return mainModel::mensajeRespuesta($msg);
 }

    public function updateProfesionalController(){

    $idProfesional =mainModel::limpiar_cadena($_POST['idProfesional']);
     $name=mainModel::limpiar_cadena($_POST['name']);
$lastName=mainModel::limpiar_cadena($_POST['lastName']);
$dni=mainModel::limpiar_cadena($_POST['dni']);
$email=mainModel::limpiar_cadena($_POST['email']);
$password=mainModel::limpiar_cadena($_POST['password']);
$idCargo=mainModel::limpiar_cadena($_POST['idCargo']);

$consultaName = mainModel::execute_query("SELECT * FROM tprofesional WHERE email='$email' and idProfesional!=$idProfesional ");
  $vnombre=$consultaName->rowCount();

 $consultaDni = mainModel::execute_query("SELECT * FROM tprofesional WHERE dni='$dni'  and idProfesional!=$idProfesional");
  $vdni=$consultaDni->rowCount();


if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El nombre del usuario ya esta registrado anteriormente"];
}

if($vdni>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El dni ya esta registrado anteriormente"];
}
if ($vnombre<1 || $vdni<1 ) {

  $data=[
        "idProfesional"=>$idProfesional,
         "name"=>$name,
         "lastName"=>$lastName,
         "dni"=>$dni,
         "email"=>$email,
         "password"=>$password,
         "idCargo"=>$idCargo
      ];

      
if (ProfesionalModel::updateProfesionalModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}


   }
      return mainModel::mensajeRespuesta($msg);
    }

}

 