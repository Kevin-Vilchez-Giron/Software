 <?php 
if ($peticionAjax) {
  require_once "../model/TriajeModel.php";
}else{
  require_once "./model/TriajeModel.php";
}

class TriajeController extends TriajeModel{



  public function listTriajeController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idAtencion',
    1 =>  't3.nombres',
    2=>'registrador',
    3=> 't2.nombre',
    4 =>  'precio',
    5 =>'t4.nombres',
    6 =>  'status'
);  
$index=0;
if ($request['order'][0]['column']!=6) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==6) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.nombre as nombreServicio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional,t6.nombres as registrador FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional INNER JOIN usuario as t5 ON t1.idUsuario =t5.idUsuario  INNER JOIN profesional as t6 ON t5.idProfesional =t6.idProfesional WHERE t1.status=1 ";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t3.apellidoPaterno Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.nombres Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.dni Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
$estado = "";
switch ($row['status']) {
    case 0:
        $estado = '<span class="badge bg-danger">Cancelado</span>';
        break;
   
    case 1:
        $estado = '<span class="badge bg-primary">Registrado</span>';
        break;
    case 2:
       $estado = '<span class="badge bg-warning text-dark">Triaje</span>';
        break;
    case 3:
       $estado = '<span class="badge bg-info text-dark">Atendido</span>';
        break;
    
    default:
        // code...
        break;
}
       $encryp=mainModel::encryption($row['idAtencion']);
     $row['idAtencion']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']; 
    $subdata[]=$row['registrador'];
    $subdata[]=$row['nombreServicio'];
        $subdata[]=$row['precio']; 
        $subdata[]=$row['nombreProfesional'].' '.$row['apellidoPaternoProfesional']; 
         $subdata[]= $estado; 

    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'triajeAjax'."`,`".SERVERURL."`,`".'idAtencion'."`)' class='btn btn-primary btn-xs  mr-xs'>
                 <i class='fa fa-pencil' aria-hidden='true'></i>
                </a>

                
";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idAtencion=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteTriajeController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("especialidad",$idElemento,$status,"idAtencion")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idAtencion  =mainModel::limpiar_cadena($_GET['idAtencion']);
      $idAtencion   =mainModel::decryption($idAtencion);
  $consulta =mainModel::execute_query("SELECT t1.* ,t2.* , t3.nombres as nombreProfesional,t3.apellidoPaterno as apellidoPaternoP,t3.apellidoMaterno as apellidoMaternoP ,t4.nombre as nombreServicio FROM atencion as t1 INNER JOIN paciente as t2 on t1.idPaciente = t2.idPaciente INNER JOIN profesional as t3 on t1.idProfesional = t3.idProfesional  INNER JOIN servicio as t4 on t1.idServicio = t4.idServicio   WHERE t1.idAtencion=$idAtencion");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
   
 
$saveUpdate='update';
$cuerpo=' <div class="row">
  <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Paciente </label>
                      <input type="text" name="nombres" maxlength="60" class="form-control nombres"  value="'.$req['nombres'].' '.$req['apellidoPaterno'].' '.$req['apellidoMaterno'].'"  disabled  >
                      </div>
             </div> 
            <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">DNI</label>
 <input type="number" name="dni" class="form-control dni" min="1" max="99999999" data-maxlength="8" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['dni'].'" disabled >
                      </div>
          </div>

                     <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Servicio </label>
                      <input type="text" name="nombreServicio" maxlength="60" class="form-control nombreServicio"  value="'.$req['nombreServicio'].'"   disabled >
                      </div>
             </div> 

    <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Especialista </label>
                      <input type="text" name="nombreProfesional" maxlength="60" class="form-control nombreProfesional"  value="'.$req['nombreProfesional'].' '.$req['apellidoPaternoP'].' '.$req['apellidoMaternoP'].'  " disabled >
                      </div>
             </div> 

<div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Precion Arterial(mmHg) </label>
                      <input type="text" name="precionArterial" maxlength="40" class="form-control precionArterial"    >
                      </div>
             </div>

             <div class="col-sm-1 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Temperatura</label>
                      <input type="text" name="temperatura" maxlength="40" class="form-control temperatura"    >
                      </div>
             </div> 
             <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">F. Respiratoria(x Minuto) </label>
                      <input type="text" name="frecuenciaRespiratoria" maxlength="40" class="form-control frecuenciaRespiratoria"    >
                      </div>
             </div> 

              <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">F. Cardiaca(x Minuto)</label>
                      <input type="text" name="frecuenciaCardiaca" maxlength="40" class="form-control frecuenciaCardiaca"  >
                      </div>
             </div> 

             <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Saturacion(O)</label>
                      <input type="text" name="saturacion" maxlength="40" class="form-control saturacion"  >
                      </div>
             </div> 

             <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Peso(kg)</label>
                      <input type="text" name="peso" maxlength="40" class="form-control peso"  >
                      </div>
             </div> 
             <div class="col-sm-1 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Talla</label>
                      <input type="text" name="talla" maxlength="40" class="form-control talla"  >
                      </div>
             </div> 


                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Triaje";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">

 <div class="col-sm-5 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Paciente <span class="required">*</span></label>
                        <select class="form-control mb-md idPaciente " data-live-search="true" name="idPaciente" required="">
                            '.mainModel::getListPacientes("SELECT * FROM paciente","idPaciente").'
                     
                          </select>
                      </div>
                    </div>
 <div class="col-sm-5 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicio " name="idServicio" data-live-search="true" required="">
                            '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
                    </div>

     <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Precio</label>
 <input type="number" name="precio" class="form-control precio" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>

     



                     <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Especialista / Profesional <span class="required">*</span></label>
                        <select class="form-control mb-md idProfesional " data-live-search="true" name="idProfesional" required="">
                            '.mainModel::getListMedicos("SELECT t1.*,t2.nombre as nombreEspecialidad FROM profesional as t1 INNER JOIN especialidad as t2 on t1.idEspecialidad = t2.idEspecialidad where idCargo = 2","idProfesional").'
                     
                          </select>
                      </div>
                    </div>


</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idAtencion"  name="idAtencion" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveTriajeController(){
     
      
$idAtencion=mainModel::limpiar_cadena($_POST['idAtencion']);
 $idAtencion=mainModel::decryption($idAtencion);
$precionArterial=mainModel::limpiar_cadena($_POST['precionArterial']);
$temperatura=mainModel::limpiar_cadena($_POST['temperatura']);
$frecuenciaRespiratoria=mainModel::limpiar_cadena($_POST['frecuenciaRespiratoria']);
$frecuenciaCardiaca=mainModel::limpiar_cadena($_POST['frecuenciaCardiaca']);
$saturacion=mainModel::limpiar_cadena($_POST['saturacion']);
$peso=mainModel::limpiar_cadena($_POST['peso']);
$talla=mainModel::limpiar_cadena($_POST['talla']);
//$idUsuario=mainModel::limpiar_cadena($_POST['idUsuario']);


//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "idAtencion"=>$idAtencion,
         "precionArterial"=>$precionArterial,
         "temperatura"=>$temperatura,
         "frecuenciaRespiratoria"=>$frecuenciaRespiratoria,
         "frecuenciaCardiaca"=>$frecuenciaCardiaca,
         "saturacion"=>$saturacion,
         "peso"=>$peso,
         "talla"=>$talla
      ];
if (TriajeModel::saveTriajeModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}


 return mainModel::mensajeRespuesta($msg);
 }

    public function updateTriajeController(){
   $idAtencion=mainModel::limpiar_cadena($_POST['idAtencion']);
 $idAtencion=mainModel::decryption($idAtencion);
$precionArterial=mainModel::limpiar_cadena($_POST['precionArterial']);
$temperatura=mainModel::limpiar_cadena($_POST['temperatura']);
$frecuenciaRespiratoria=mainModel::limpiar_cadena($_POST['frecuenciaRespiratoria']);
$frecuenciaCardiaca=mainModel::limpiar_cadena($_POST['frecuenciaCardiaca']);
$saturacion=mainModel::limpiar_cadena($_POST['saturacion']);
$peso=mainModel::limpiar_cadena($_POST['peso']);
$talla=mainModel::limpiar_cadena($_POST['talla']);
//$idUsuario=mainModel::limpiar_cadena($_POST['idUsuario']);


//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "idAtencion"=>$idAtencion,
         "precionArterial"=>$precionArterial,
         "temperatura"=>$temperatura,
         "frecuenciaRespiratoria"=>$frecuenciaRespiratoria,
         "frecuenciaCardiaca"=>$frecuenciaCardiaca,
         "saturacion"=>$saturacion,
         "peso"=>$peso,
         "talla"=>$talla
      ];
if (TriajeModel::saveTriajeModel($data)!="error") {
   $msg=["alert"=>"update"];

}else{
 $msg=["alert"=>"error"];
}

      return mainModel::mensajeRespuesta($msg);
    }

}

 