 <?php 
if ($peticionAjax) {
  require_once "../model/AreaModel.php";
}else{
  require_once "./model/AreaModel.php";
}

class AreaController extends AreaModel{



  public function listAreaController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idArea',
    1 =>  'name'
);  
$index=0;
if ($request['order'][0]['column']!=4) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.* FROM tarea as t1  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.name Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.descripcion Like '%".$request['search']['value']."%' )";
        //$sql.= "OR t2.name Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.name Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idArea']);
     $row['idArea']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['name']; 
  


    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'areaAjax'."`,`".SERVERURL."`,`".'idArea'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'areaAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idArea=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteAreaController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("tarea",$idElemento,$status,"idArea")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idArea  =mainModel::limpiar_cadena($_GET['idArea']);
      $idArea   =mainModel::decryption($idArea);
  $consulta =mainModel::execute_query("SELECT t1.*   FROM tarea as t1  WHERE t1.idArea=$idArea");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
  

 
$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Área </label>
                      <input type="text" name="name" maxlength="250" class="form-control name" value="'.$req['name'].'"    >
                      </div>
             </div> 

             <div class="col-sm-6 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Descripcion </label>
                      <input type="text" name="descripcion" maxlength="250" class="form-control name" value="'.$req['descripcion'].'"    >
                      </div>
             </div> 

    

 
                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Area";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Área </label>
                      <input type="text" name="name" maxlength="250" class="form-control name"     >
                      </div>
             </div> 

    <div class="col-sm-6 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Descripcion </label>
                      <input type="text" name="descripcion" maxlength="250" class="form-control descripcion" value=""    >
                      </div>
             </div> 




</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >

    <input type="hidden" class="idArea"  name="idArea" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveAreaController(){
      
$name=mainModel::limpiar_cadena($_POST['name']);
$descripcion=mainModel::limpiar_cadena($_POST['descripcion']);




      $consultaName = mainModel::execute_query("SELECT * FROM tarea WHERE name='$name'   ");
  $vname=$consultaName->rowCount();
if($vname>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe una area con este name"];
}
if ($vname<1) {
//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ 
    "name"=>$name,
 "descripcion"=>$descripcion
      ];
if (AreaModel::saveAreaModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updateAreaController(){
    $idArea =mainModel::limpiar_cadena($_POST['idArea']);
      $idArea  =mainModel::decryption($idArea);
$name=mainModel::limpiar_cadena($_POST['name']);
$descripcion=mainModel::limpiar_cadena($_POST['descripcion']);


      $consultaName = mainModel::execute_query("SELECT * FROM tarea WHERE name='$name' and idArea!=$idArea ");
  $vname=$consultaName->rowCount();
if($vname>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El name de la tarea ya esta registrada anteriormente"];
}
if ($vname<1) {

  $data=[
        "idArea"=>$idArea,
          "name"=>$name,
          "descripcion" =>$descripcion
      ];

      
if (AreaModel::updateAreaModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 