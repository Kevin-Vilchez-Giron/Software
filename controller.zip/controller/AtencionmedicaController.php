<?php if ($peticionAjax) {
  require_once "../model/AtencionmedicaModel.php";
}else{
  require_once "./model/AtencionmedicaModel.php";
}

class AtencionmedicaController extends AtencionmedicaModel{



  public function listAtencionmedicaController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idAtencion',
    1 =>  't3.nombres',
    2=>'registrador',
    3=> 't2.nombre',
    4 =>  'precio',
    5 =>'t4.nombres',
    6 =>  'status'
);  
$index=0;
if ($request['order'][0]['column']!=6) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==6) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.nombre as nombreServicio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional,t6.nombres as registrador FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional INNER JOIN usuario as t5 ON t1.idUsuario =t5.idUsuario  INNER JOIN profesional as t6 ON t5.idProfesional =t6.idProfesional WHERE t1.status=$status ";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t3.apellidoPaterno Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.nombres Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.dni Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
$estado = "";
switch ($row['status']) {
    case 0:
        $estado = '<span class="badge bg-danger">Cancelado</span>';
        break;
   
    case 1:
        $estado = '<span class="badge bg-primary">Registrado</span>';
        break;
    case 2:
       $estado = '<span class="badge bg-warning text-dark">Triaje</span>';
        break;
    case 3:
       $estado = '<span class="badge bg-info text-dark">Atendido</span>';
        break;
    
    default:
        // code...
        break;
}
$idAtenciondesc=$row['idAtencion'];
       $encryp=mainModel::encryption($row['idAtencion']);
     $row['idAtencion']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']; 
    $subdata[]=$row['registrador'];
    $subdata[]=$row['nombreServicio'];
        $subdata[]=$row['precio']; 
        $subdata[]=$row['nombreProfesional'].' '.$row['apellidoPaternoProfesional']; 
         $subdata[]= $estado; 
if($status==2){
   $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'atencionmedicaAjax'."`,`".SERVERURL."`,`".'idAtencion'."`)' class='btn btn-primary btn-xs  mr-xs'>
                 <i class='fa fa-pencil' aria-hidden='true'></i>
                </a>";       
}
if($status==3){
 $consulta =mainModel::execute_query("SELECT idResultado   FROM resultado WHERE
   idAtencion='$idAtenciondesc'");
      $req = $consulta->fetch(PDO::FETCH_ASSOC);
$idResultado=$req['idResultado'];
$encryph=mainModel::encryption($idResultado);
 $urlh=SERVERURL."ajax/reporthistoryAjax.php?report=".$encryph;
$urlb=SERVERURL."ajax/reportRecetaAjax.php?report=".$encryph;

$htmlhistory="<a onclick='ventanaReport(`".$urlh."`)' class='btn btn-info btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i>Historia
                </a> <a onclick='ventanaReport(`".$urlb."`)' class='btn btn-warning btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i>Boleta
                </a>";

   $subdata[]=$htmlhistory;       
}


   
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }



  public function listAtencionmedica2Controller($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idAtencion',
    1 =>  't3.nombres',
    2=>'registrador',
    3=> 't2.nombre',
    4 =>  'precio',
    5 =>'t4.nombres',
    6 =>  'status'
);  
$index=0;
if ($request['order'][0]['column']!=6) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==6) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.nombre as nombreServicio, t2.precio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional,t6.nombres as registrador FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional INNER JOIN usuario as t5 ON t1.idUsuario =t5.idUsuario  INNER JOIN profesional as t6 ON t5.idProfesional =t6.idProfesional WHERE t1.status=3 ";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t3.apellidoPaterno Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.nombres Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.dni Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
$estado = "";
switch ($row['status']) {
    case 0:
        $estado = '<span class="badge bg-danger">Cancelado</span>';
        break;
   
    case 1:
        $estado = '<span class="badge bg-primary">Registrado</span>';
        break;
    case 2:
       $estado = '<span class="badge bg-warning text-dark">Triaje</span>';
        break;
    case 3:
       $estado = '<span class="badge bg-info text-dark">Atendido</span>';
        break;
    
    default:
        // code...
        break;
}
$idAtenciondesc=$row['idAtencion'];
       $encryp=mainModel::encryption($row['idAtencion']);
     $row['idAtencion']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']; 
    $subdata[]=$row['registrador'];
    $subdata[]=$row['nombreServicio'];
        $subdata[]=$row['precio']; 
        $subdata[]=$row['nombreProfesional'].' '.$row['apellidoPaternoProfesional']; 
         $subdata[]= $estado; 
if($row['status']==2){
   $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'atencionmedicaAjax'."`,`".SERVERURL."`,`".'idAtencion'."`)' class='btn btn-primary btn-xs  mr-xs'>
                 <i class='fa fa-pencil' aria-hidden='true'></i>
                </a>";       
}
if($row['status']==3){
 $consulta =mainModel::execute_query("SELECT idResultado   FROM resultado WHERE
   idAtencion='$idAtenciondesc'");
      $req = $consulta->fetch(PDO::FETCH_ASSOC);
$idResultado=$req['idResultado'];
$encryph=mainModel::encryption($idResultado);
 $urlh=SERVERURL."ajax/reporthistoryAjax.php?report=".$encryph;
$urlb=SERVERURL."ajax/reportRecetaAjax.php?report=".$encryph;

$htmlhistory="<a onclick='ventanaReport(`".$urlh."`)' class='btn btn-info btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i>Historia
                </a> <a onclick='ventanaReport(`".$urlb."`)' class='btn btn-warning btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i>Receta
                </a>";

   $subdata[]=$htmlhistory;       
}


   
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }








public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idAtencion=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteAtencionmedicaController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("especialidad",$idElemento,$status,"idAtencion")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }
public function templateEnfermedad(){
    $idCategoria=mainModel::limpiar_cadena($_GET['idCategoria']);

$consulta =mainModel::execute_query("SELECT * FROM diagnosticoscie10 WHERE idCategoria=".$idCategoria);
    $request = $consulta->fetchAll(PDO::FETCH_ASSOC);
     $temp='';
foreach($request as $indexcd=>$rowdetalle){
$extra=" <tr id='trdiagupdate".$rowdetalle['id']."' >  <td> 
<input type='hidden'  name='operation' value='save'>  
 <input type='hidden' id='encrydiagno".$rowdetalle['id']."'  name='idupdate' value='".$rowdetalle['id']."'>
<button type='button'  class='btn btn-danger  btn-xs '    
  onclick='onDeleteDiagnostico(".$rowdetalle['id'].");'><i class='fa  fa-trash-o fa-lg colorwhite'></i></button>
  </td>
 <td>
  <select  class='form-control input-lg tipo'  data-width='100%''   name='infoupdate'   required>  
<option selected value='P'>P</option><option value='D'>D</option><option value='R'>R</option>
   </select>
  </td> 
 <td> 
".$rowdetalle['descripcion']."
  </td>
</tr> ";

$arra=["tmp"=>$extra];
    $temp.='<li>  <a  href="javascript:void(0)" class="btn btn-primary  btn-xs " onclick="onAddEnfermedad(`'.$extra.'`,'.$rowdetalle['id'].')"><i class="fa fa-plus fa-lg colorwhite"></i></a>'.$rowdetalle['descripcion'].'</li>';
}

return $temp;

}
public function reportreceta($idResultado){
  $idResultado=mainModel::decryption($idResultado);
    $consultaresultado =mainModel::execute_query("SELECT * FROM resultado   WHERE idResultado=$idResultado");
  $reqresultado = $consultaresultado->fetch(PDO::FETCH_ASSOC);
    $idAtencion=$reqresultado['idAtencion'];
    $consulta =mainModel::execute_query("SELECT t1.* ,t2.* , t3.nombres as nombreProfesional,t3.apellidoPaterno as apellidoPaternoP,t3.apellidoMaterno as apellidoMaternoP ,t4.nombre as nombreServicio,t5.* FROM atencion as t1 INNER JOIN paciente as t2 on t1.idPaciente = t2.idPaciente INNER JOIN profesional as t3 on t1.idProfesional = t3.idProfesional  INNER JOIN servicio as t4 on t1.idServicio = t4.idServicio INNER JOIN triaje as t5 on t5.idAtencion = t1.idAtencion   WHERE t1.idAtencion=$idAtencion");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);

 $consultadcr2 =mainModel::execute_query("SELECT * FROM treceta WHERE idAtencion =$idAtencion");
  $reqdcr2 = $consultadcr2->fetchAll(PDO::FETCH_ASSOC);
$extra2html='';
   foreach ($reqdcr2 as $index=>$row) {
   
$extra2html.='   <tr>
                <td  translate="yes">'.$row['medicamento'].'</td>
                <td  translate="yes">'.$row['presentacion'].'</td>
                <td  translate="yes">'.$row['dosis'].'</td>
                <td  translate="yes">'.$row['duracion'].'</td>
                <td  translate="yes">'.$row['cantidad'].' </td>
            </tr>';     
}

$html='<div class="col-md-12"> <table id="customers">
            <tr>
                <td  translate="yes"><h5>NOMBRES</h5> '.$req['nombres'].' '.$req['apellidoPaterno'].' '.$req['apellidoMaterno'].'</td>
            </tr>
<tr>
                <td translate="yes"> <h5>TRATAMIENTO</h5> '.$reqresultado['tratamiento'].'</td>
                
</tr>
          
               
        </table> </div>
        <div class="col-md-12">
  <h5>Detalle Receta</h5>
         <table id="customers">
  <thead>
                          <tr>
                             <th>MEDICAMENTO</th>
                             <th>PRESENTACION</th>
                             <th>DOSIS</th>
                             <th>DURACION</th>
                             <th>CANTIDAD</th>

                          </tr>
                        </thead>
                        <tbody>
         '.$extra2html.'
                                  </tbody>

        </table>


         </div>
';
return $html;
}



public function report($idResultado){
  $idResultado=mainModel::decryption($idResultado);
    $consultaresultado =mainModel::execute_query("SELECT * FROM resultado   WHERE idResultado=$idResultado");
  $reqresultado = $consultaresultado->fetch(PDO::FETCH_ASSOC);
$txtd="";
if($reqresultado['proximaCita']!=NULL){$txtd=$reqresultado['proximaCita'];}
$idAtencion=$reqresultado['idAtencion'];
    $consulta =mainModel::execute_query("SELECT t1.* ,t2.* ,(SELECT TIMESTAMPDIFF (YEAR, t2.fechaNacimiento, CURDATE())) as edad, t3.nombres as nombreProfesional,t3.apellidoPaterno as apellidoPaternoP,t3.apellidoMaterno as apellidoMaternoP ,t4.nombre as nombreServicio,t5.* FROM atencion as t1 INNER JOIN paciente as t2 on t1.idPaciente = t2.idPaciente INNER JOIN profesional as t3 on t1.idProfesional = t3.idProfesional  INNER JOIN servicio as t4 on t1.idServicio = t4.idServicio INNER JOIN triaje as t5 on t5.idAtencion = t1.idAtencion   WHERE t1.idAtencion=$idAtencion");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
 $consultadcr =mainModel::execute_query("SELECT t1.* ,t2.descripcion FROM detallediagnostico as t1 INNER JOIN diagnosticoscie10 as t2 on t1.idDiagnostico  = t2.id   WHERE t1.idResultado =$idResultado");
  $reqdcr = $consultadcr->fetchAll(PDO::FETCH_ASSOC);
$extra1html='';

      foreach ($reqdcr as $index=>$row) {
        $txttipo=""; if($row['tipo']=="P"){$txttipo="P:PRESUNTIVO";}  if($row['tipo']=="D"){$txttipo="D:DEFINITIVO";} if($row['tipo']=="R"){$txttipo="R:REPETIDO";}
$extra1html.='   <tr>

                <td  translate="yes">'.$txttipo.'</td>

                <td  translate="yes">'.$row['descripcion'].' </td>
                  
            </tr>';
}




$html=' <div class="col-12">
 <table id="customers">
            <tr>
                 <th  translate="yes" style="width:25%;">Paciente:</th>
                <td  translate="yes">'.$req['nombres'].' '.$req['apellidoPaterno'].' '.$req['apellidoMaterno'].'</td>
                   <th  translate="yes" style="width:25%;">DNI:</th>
                <td translate="yes">  '.$req['dni'].'</td>
                  
            </tr>
<tr>
    <th  translate="yes" style="width:25%;">Servicio:</th>
                <td translate="yes">  '.$req['nombreServicio'].'</td>
                    <th  translate="yes" style="width:25%;">Especialista:</th>
                <td translate="yes">  '.$req['nombreProfesional'].' '.$req['apellidoPaternoP'].' '.$req['apellidoMaternoP'].'</td>
</tr>
            <tr>
                <th  translate="yes" style="width:25%;">Precion Arterial(mmHg)</th>
                <td translate="yes">'.$req['precionArterial'].'</td>
                 <th  translate="yes" style="width:25%;">Temperatura</th>
                <td  translate="yes" >'.$req['temperatura'].'</td>
   
            </tr>
            <tr>
<th  translate="yes" style="width:25%;">F. Respiratoria(x Minuto)</th>
                <td  translate="yes" >'.$req['frecuenciaRespiratoria'].'</td>
                  <th  translate="yes" style="width:25%;"> F. Cardiaca(x Minuto)</th>
                <td  translate="yes" >'.$req['frecuenciaCardiaca'].'</td>
              
</tr>
            <tr>
                  <th  translate="yes" style="width:25%;">Saturacion(O)</th>
                <td  translate="yes" >'.$req['saturacion'].'</td>
                 <th translate="yes" style="width:25%;">Peso(kg)</th>
                <td  translate="yes">'.$req['peso'].'</td>
              
            </tr>
            <tr>      <th translate="yes" style="width:25%;">Talla</th>
                <td  translate="yes">'.$req['talla'].'</td>
                 <th translate="yes" style="width:25%;">Edad</th>
                <td  translate="yes">'.$req['edad'].' años</td>
</tr>           
        </table>
   </div>
 <div class="col-12">
 <table id="customers">
            <tr>
                 <th  translate="yes" style="width:25%;">Motivo de Consulta:</th>
                <td  translate="yes">'.$reqresultado['motivo'].' </td>
                  
            </tr>
            <tr>
                <th  translate="yes" style="width:25%;">Estado de Paciente</th>
                <td translate="yes">'.$reqresultado['estado'].'</td>
                 
            </tr>
<tr><th  translate="yes" style="width:25%;">TE</th>
                <td  translate="yes" >'.$reqresultado['tiempoEnfermedad'].'</td>

            <tr>
           
                 <th translate="yes" style="width:25%;">Antecedentes</th>
                <td  translate="yes">'.$reqresultado['antecedentesFamiliares'].'</td>
             
            </tr>
            <tr>
           
                 <th translate="yes" style="width:25%;">Alergias</th>
                <td  translate="yes">'.$req['alergias'].'</td>
             
            </tr>
            <tr>
           
                 <th translate="yes" style="width:25%;">Interverciones Quirurgicas</th>
                <td  translate="yes">'.$req['intervencionesQuirurgicas'].'</td>
             
            </tr>
              <tr>
                 <th translate="yes" style="width:25%;">Examen Fisico</th>
                <td  translate="yes">'.$reqresultado['examenFisico'].'</td>
            </tr>
           
        </table>
   </div>
 <div class="col-12">
 <h5>Diagnotico</h5>
 <table id="customers">
  <thead>
                          <tr>
                             <th>TIPO</th>
                             <th>ENFERMEDAD</th>
                            
                          </tr>
                        </thead>
                        <tbody>
         '.$extra1html.'
                                  </tbody>

        </table>

         <table id="customers">
            <tr>
                 <th  translate="yes" style="width:25%;">Plan:</th>
                <td  translate="yes">'.$reqresultado['plan'].' </td>
                                   <th  translate="yes" style="width:25%;">Riesgos:</th>
                <td  translate="yes">'.$reqresultado['riesgos'].' </td>
                                 
            </tr>
           <tr>
 <th  translate="yes" style="width:25%;">Proxima Cita:</th>
                <td  translate="yes">'.$txtd.' </td>
            </tr>
           
        </table>
   </div>

 <div class="col-12">
 <h5>Tratamiento</h5>
 <p> '.$reqresultado['tratamiento'].'</p>
      
           
           
   </div> ';

return $html;

}




public function fomUpdate(){
      $idAtencion  =mainModel::limpiar_cadena($_GET['idAtencion']);
      $idAtencion   =mainModel::decryption($idAtencion);
  $consulta =mainModel::execute_query("SELECT t1.* ,t2.* ,(SELECT TIMESTAMPDIFF (YEAR, t2.fechaNacimiento, CURDATE())) as edad, t3.nombres as nombreProfesional,t3.apellidoPaterno as apellidoPaternoP,t3.apellidoMaterno as apellidoMaternoP ,t4.nombre as nombreServicio,t5.* FROM atencion as t1 INNER JOIN paciente as t2 on t1.idPaciente = t2.idPaciente INNER JOIN profesional as t3 on t1.idProfesional = t3.idProfesional  INNER JOIN servicio as t4 on t1.idServicio = t4.idServicio INNER JOIN triaje as t5 on t5.idAtencion = t1.idAtencion   WHERE t1.idAtencion=$idAtencion");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
   $fechalimit=date("d/m/Y");

 
$saveUpdate='update';
$cuerpo=' <div class="row">
  <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Paciente </label>
                        <input type="hidden" class="jsdetallediag"  name="jsdetallediag" >       
    <input type="hidden" class="jsdetallereceta"  name="jsdetallereceta" >       

                      <input type="text" name="nombres" maxlength="60" class="form-control nombres"  value="'.$req['nombres'].' '.$req['apellidoPaterno'].' '.$req['apellidoMaterno'].'"  disabled  >
                      </div>
             </div> 
            <div class="col-sm-3 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">DNI</label>
 <input type="number" name="dni" class="form-control dni" min="1" max="99999999" data-maxlength="8" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['dni'].'" disabled >
                      </div>
          </div>

                     <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Servicio </label>
                      <input type="text" name="nombreServicio" maxlength="60" class="form-control nombreServicio"  value="'.$req['nombreServicio'].'"   disabled >
                      </div>
             </div> 

    <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Especialista </label>
                      <input type="text" name="nombreProfesional" maxlength="60" class="form-control nombreProfesional"  value="'.$req['nombreProfesional'].' '.$req['apellidoPaternoP'].' '.$req['apellidoMaternoP'].'  " disabled >
                      </div>
             </div>
             <div class="col-sm-1 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Edad </label>
                      <input type="text" name="edad" maxlength="40" class="form-control edad"    value="'.$req['edad'].'"   disabled  >
                      </div>
             </div> 

<div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Precion Arterial(mmHg) </label>
                      <input type="text" name="precionArterial" maxlength="40" class="form-control precionArterial"    value="'.$req['precionArterial'].'"   disabled  >
                      </div>
             </div>

             <div class="col-sm-1 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Temperatura</label>
                      <input type="text" name="temperatura" maxlength="40" class="form-control temperatura"  value="'.$req['temperatura'].'"   disabled  >
                      </div>
             </div> 
             <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">F. Respiratoria(x Minuto) </label>
                      <input type="text" name="frecuenciaRespiratoria" maxlength="40" class="form-control frecuenciaRespiratoria"  value="'.$req['frecuenciaRespiratoria'].'"   disabled   >
                      </div>
             </div> 

              <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">F. Cardiaca(x Minuto)</label>
                      <input type="text" name="frecuenciaCardiaca" maxlength="40" class="form-control frecuenciaCardiaca"  value="'.$req['frecuenciaCardiaca'].'"   disabled  >
                      </div>
             </div> 

             <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Saturacion(O)</label>
                      <input type="text" name="saturacion" maxlength="40" class="form-control saturacion" value="'.$req['saturacion'].'"   disabled >
                      </div>
             </div> 

             <div class="col-sm-1 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Peso(kg)</label>
                      <input type="text" name="peso" maxlength="40" class="form-control peso" value="'.$req['peso'].'"   disabled >
                      </div>
             </div> 
             <div class="col-sm-1 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Talla</label>
                      <input type="text" name="talla" maxlength="40" class="form-control talla" value="'.$req['talla'].'"   disabled   >
                      </div>
             </div> 
                </div>

<div class="row">
  <div class="col-sm-7 mb-xs">
                          <div class="form-group">
      <label class="control-label">Motivo de Consulta <span class="required">*</span></label>
                           <textarea name="motivo" rows="2" class="form-control motivo"   maxlength="300"  required=""></textarea>
                          </div>
                        </div> 

 <div class="col-sm-3 mb-xs">
                          <div class="form-group">
             <label class="control-label">Estado de Paciente<span class="required">*</span></label>
     <input type="text" name="estado" maxlength="40" class="form-control estado"  required >                 
                          </div>
                        </div> 

  <div class="col-sm-2 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">TE <span class="required">*</span></label>
                      <input type="text" name="tiempoEnfermedad" maxlength="40" class="form-control tiempoEnfermedad"  required >
                      </div>
             </div>
  <div class="col-sm-12 mb-xs">
                          <div class="form-group">
        <label class="control-label">Antecedentes <span class="required">*</span> </label>
 <textarea name="antecedentesFamiliares" rows="2" class="form-control antecedentesFamiliares"   maxlength="300" required> </textarea>
                          </div>
                        </div> 
</div>
<div class="row"> 
 <div class="col-sm-5 mb-xs">
                          <div class="form-group">
             <label class="control-label">Alergias</label>
 <input type="text" maxlength="250" class="form-control " value="'.$req['alergias'].'" readonly >                 
                          </div>
                        </div> 
  <div class="col-sm-5 mb-xs">
                          <div class="form-group">
      <label class="control-label">Interverciones Quirurgicas</label>
 <textarea rows="2" class="form-control intervencionesQuirurgicas"   maxlength="300"  readonly >'.$req['intervencionesQuirurgicas'].'</textarea>
                          </div>
                        </div> 

</div> 
<div class="row">
  <div class="col-sm-12 mb-xs">
                          <div class="form-group">
        <label class="control-label">Examen Fisico </label>
 <textarea name="examenFisico" rows="2" class="form-control examenFisico"   maxlength="300"> </textarea>
                          </div>
                        </div> 
</div>  
<div class="row">
  <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Buscar Diagnotico <span class="required">*</span></label>
                        <select class="form-control mb-md busqdiagonistico " name="busqdiagonistico" data-live-search="true" required=""  data-size="5" data-width="100%" onchange="getDiagnostico(`'.SERVERURL.'`);">
 '.mainModel::getListAuto("SELECT * FROM categoriascie10","id","descripcion",'',"save").'     
                          </select>
                      </div>
                    </div>
 <div class="col-sm-8 mb-xs resultbusq">

</div>

<div class="col-sm-12 mb-xs ">
<div class="table-responsive">
                                            <table class="table table-striped mb-none">
                                               <caption> Seleccione</caption
                                                <thead>
                                                    <tr>
                                                        <th>Borrar</th>
                                                        <th>Tipo</th>
                                                        <th>Enfermedad</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="detallediagnostico">
                                              
                                                </tbody>
                                            </table>
                                        </div>
</div>

</div>
<div class="row">
 <div class="col-sm-4 mb-xs">
                          <div class="form-group">
             <label class="control-label">Plan<span class="required">*</span></label>
 <input type="text" maxlength="250" name="plan" class="form-control plan"  required >                 
                          </div>
                        </div> 
     <div class="col-sm-4 mb-xs">
                          <div class="form-group">
             <label class="control-label">Riesgos<span class="required">*</span></label>
 <input type="text" maxlength="100" name="riesgos" class="form-control riesgos"  required >                 
                          </div>
                        </div>      
    <div class="col-sm-4 mb-xs"> 
                                       <div class="form-group">
               <label class="control-label">Proxima Cita </label>
                        <div class="input-group">
                            <span class="input-group-addon">
                              <i class="fa fa-calendar"></i>
                            </span>
 <input type="text" data-plugin-datepicker name="proximaCita" placeholder="dd/mm/aaaa" class="form-control proximaCita"  data-date-start-date="'.$fechalimit.'"    >
                          </div>
                      </div>
                            </div>   

</div>

<div class="row">
  <div class="col-sm-12 mb-xs">
                          <div class="form-group">
        <label class="control-label">Tratamiento<span class="required">*</span></label>
 <textarea name="tratamiento" rows="2" class="form-control   tratamiento"  required > </textarea>
                          </div>
                        </div> 
<div class="col-sm-3 mb-xs">  
        <br class="hidden-xs">
 <a id="addToTable2xD"  href="javascript:void(0)" class="btn btn-primary" onclick="adddetailorder(`'.$saveUpdate.'`)">Añadir Receta <i class="fa fa-plus"></i></a>
</div>

<div class="col-sm-12  mb-xs " style=" overflow: auto; max-height:350px;">
<div class="table-responsive">
                      <table class="table table-bordered  mb-none" id="tableD'.$saveUpdate.'">
                        <thead>
                          <tr>
                             <th>Medicamentos</th>
                             <th>Presentacion</th>
                             <th>Dosis</th>
                             <th>Duracion</th>
                             <th>Cantidad</th>
                            <th>Borrar</th>
                          </tr>
                        </thead>
                        <tbody class="detallereceta'.$saveUpdate.'">

                        </tbody>
                      </table>
                    </div>
</div>
</div>
    <script>  $(".busqdiagonistico").selectpicker();

  $("[data-plugin-datepicker]").each(function() {
        var $this = $( this ),
          opts = {};

        var pluginOptions = $this.data("plugin-options");
        if (pluginOptions)
          opts = pluginOptions;

        $this.themePluginDatePicker(opts);
      });
     </script>   ';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Atencionmedica";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">

 <div class="col-sm-5 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Paciente <span class="required">*</span></label>
                        <select class="form-control mb-md idPaciente " data-live-search="true" name="idPaciente" required="">
                            '.mainModel::getListPacientes("SELECT * FROM paciente","idPaciente").'
                     
                          </select>
                      </div>
                    </div>
 <div class="col-sm-5 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicio " name="idServicio" data-live-search="true" required="">
                            '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
                    </div>

     <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Precio</label>
 <input type="number" name="precio" class="form-control precio" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>

     



                     <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Especialista / Profesional <span class="required">*</span></label>
                        <select class="form-control mb-md idProfesional " data-live-search="true" name="idProfesional" required="" >
                            '.mainModel::getListMedicos("SELECT t1.*,t2.nombre as nombreEspecialidad FROM profesional as t1 INNER JOIN especialidad as t2 on t1.idEspecialidad = t2.idEspecialidad where idCargo = 2","idProfesional").'
                     
                          </select>
                      </div>
                    </div>


</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Guardar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">

  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idAtencion"  name="idAtencion" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveAtencionmedicaController(){
     
      
$idAtencion=mainModel::limpiar_cadena($_POST['idAtencion']);
 $idAtencion=mainModel::decryption($idAtencion);
$motivo=mainModel::limpiar_cadena($_POST['motivo']);
$estado=mainModel::limpiar_cadena($_POST['estado']);
$tiempoEnfermedad=mainModel::limpiar_cadena($_POST['tiempoEnfermedad']);
$antecedentesFamiliares=mainModel::limpiar_cadena($_POST['antecedentesFamiliares']);
$examenFisico=mainModel::limpiar_cadena($_POST['examenFisico']);
$plan=mainModel::limpiar_cadena($_POST['plan']);
$riesgos=mainModel::limpiar_cadena($_POST['riesgos']);
$proximaCita=mainModel::limpiar_cadena($_POST['proximaCita']);
$tratamiento=mainModel::limpiar_cadena($_POST['tratamiento']);
if($proximaCita!=""){
    $proximaCita = str_replace('/', '-', $proximaCita);
$proximaCita=strtotime($proximaCita);
$proximaCita=date('Y-m-d',$proximaCita);
}
if($proximaCita==""){ $proximaCita=NULL;
}
     $jsdetallediag=$_POST['jsdetallediag'];
     $jsdetallereceta=$_POST['jsdetallereceta'];

//$idUsuario=mainModel::limpiar_cadena($_POST['idUsuario']);


//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "idAtencion"=>$idAtencion,
         "motivo"=>$motivo,
         "estado"=>$estado,
         "tiempoEnfermedad"=>$tiempoEnfermedad,
         "antecedentesFamiliares"=>$antecedentesFamiliares,
         "examenFisico"=>$examenFisico,
         "plan"=>$plan,
         "riesgos"=>$riesgos,
         "proximaCita"=>$proximaCita,
          "tratamiento"=>$tratamiento

      ];
if (AtencionmedicaModel::saveAtencionmedicaModel($data)!="error") {
    $consulta =mainModel::execute_query("SELECT idResultado   FROM resultado WHERE
   idAtencion='$idAtencion'");
      $req = $consulta->fetch(PDO::FETCH_ASSOC);
$idResultado=$req['idResultado'];
$datadiag = json_decode($jsdetallediag);
$datareceta = json_decode($jsdetallereceta);

$instdiag=AtencionmedicaModel::savedetallediagnosticoModel($datadiag,$idResultado);
$instreceta=AtencionmedicaModel::savedetalleRecetaModel($datareceta,$idAtencion);
$encryp=mainModel::encryption($idResultado);
                $urlrep=SERVERURL."ajax/reporthistoryAjax.php?report=".$encryp;
$urlrep2=SERVERURL."ajax/reportRecetaAjax.php?report=".$encryp;
   $msg=["alert"=>"updatereport","url"=>$urlrep,"url2"=>$urlrep2];
}else{
 $msg=["alert"=>"error"];
}


 return mainModel::mensajeRespuesta($msg);
 }

    public function updateAtencionmedicaController(){
   $idAtencion=mainModel::limpiar_cadena($_POST['idAtencion']);
 $idAtencion=mainModel::decryption($idAtencion);
$precionArterial=mainModel::limpiar_cadena($_POST['precionArterial']);
$temperatura=mainModel::limpiar_cadena($_POST['temperatura']);
$frecuenciaRespiratoria=mainModel::limpiar_cadena($_POST['frecuenciaRespiratoria']);
$frecuenciaCardiaca=mainModel::limpiar_cadena($_POST['frecuenciaCardiaca']);
$saturacion=mainModel::limpiar_cadena($_POST['saturacion']);
$peso=mainModel::limpiar_cadena($_POST['peso']);
$talla=mainModel::limpiar_cadena($_POST['talla']);
//$idUsuario=mainModel::limpiar_cadena($_POST['idUsuario']);


//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "idAtencion"=>$idAtencion,
         "precionArterial"=>$precionArterial,
         "temperatura"=>$temperatura,
         "frecuenciaRespiratoria"=>$frecuenciaRespiratoria,
         "frecuenciaCardiaca"=>$frecuenciaCardiaca,
         "saturacion"=>$saturacion,
         "peso"=>$peso,
         "talla"=>$talla
      ];
if (AtencionmedicaModel::saveAtencionmedicaModel($data)!="error") {
   $msg=["alert"=>"update"];

}else{
 $msg=["alert"=>"error"];
}

      return mainModel::mensajeRespuesta($msg);
    }

}

 