<?php if ($peticionAjax) {
  require_once "../model/ProductModel.php";
}else{
  require_once "./model/ProductModel.php";
}

class ProductController extends ProductModel{

public function listespecialidadReport(){
                  $html=mainModel::getList("SELECT * FROM especialidad","idEspecialidad");
return $html;
}
public function reportProfessionGroup(){
        $extra=" ";
$table="";
$txtst="";
if(isset($_GET['specialidad'])){
if($_GET['specialidad']!="" && $_GET['specialidad']!=NULL){
    $specialidad=mainModel::limpiar_cadena($_GET['specialidad']);
    $txtst=" and t1.idEspecialidad=$specialidad ";
}

}

    $consultareport = mainModel::execute_query("SELECT t1.*,t2.name as nameCargo FROM tprofesional as t1 INNER JOIN tcargo as t2 ON t1.idCargo =t2.idCargo  WHERE t1.status=1 ".$txtst." ORDER BY t1.idProduct    ASC");
   $reqcash = $consultareport->fetchAll(PDO::FETCH_ASSOC);
    $datos='';
    foreach ($reqcash as $key => $row) {
      $ac=$key+1;
$table.=" <tr>
        <td> ".$ac."
        </td>
                     <td>
               ".$row['lastName']. " ".$row['dni']."
                     </td>
                     <td>
                      ".$row['name']."
                     </td>
                      <td>
                      ".$row['nombreCargo']."
                     </td>
                       <td>
                      ".$row['dni']." 
                     </td>
</tr>
 ";

}
return $table;
}

  public function listProductController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idProduct',
    1 =>  'name',
    2=> 'stock',
     3=> 'medida',
    4=>  'nameCategoria',
     5=>  'precio',
    6=> 'dateRegister'
);  
$index=0;
if ($request['order'][0]['column']!=7) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==7) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.name as nameCategoria, t3.name as nameMedida FROM tproduct as t1 INNER JOIN tcategoria as t2 ON t1.idCategoria =t2.idCategoria INNER JOIN tmedida as t3 ON t1.idMedida =t3.idMedida   WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.name Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.nameCategoria Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' )";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idProduct']);
     $row['idProduct']=$encryp;
    $subdata[]=$contador;
    $subdata[]=$row['name']; 
    $subdata[]=$row['stock'];
    $subdata[]=$row['nameMedida'];
    $subdata[]=$row['nameCategoria'];
     $subdata[]=$row['precio'];
    $subdata[]=$row['dateRegister']; 
 


    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'productAjax'."`,`".SERVERURL."`,`".'idProduct'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'productAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }

public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idProduct=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}

    public function activaDeleteProductController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("tproduct",$idElemento,$status,"idProduct")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idProduct  =mainModel::limpiar_cadena($_GET['idProduct']);
      $idProduct   =mainModel::decryption($idProduct);
  $consulta =mainModel::execute_query("SELECT t1.* ,t2.name as nameCategoria FROM tproduct as t1 INNER JOIN tcategoria as t2 ON t1.idCategoria =t2.idCategoria  WHERE t1.idProduct=$idProduct");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);

     $idCategoria =$req['idCategoria'];

       $idMedida =$req['idMedida'];


$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-6 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Product </label>
                      <input type="text" name="name" maxlength="60" class="form-control name" value="'.$req['name'].'"    >
                      </div>
             </div> 

    <div class="col-sm-5 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Stock </label>
                      <input type="text" name="stock" maxlength="50" class="form-control stock"   value="'.$req['stock'].'"  >
                      </div>
             </div> 
             
             

             <div class="col-sm-3 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Medida <span class="required">*</span></label>
                        <select class="form-control mb-md idMedida " name="idMedida" required="">
                           '.mainModel::getListAuto("SELECT * FROM tmedida","idMedida","name",$idMedida,"update").'
                          </select>
                      </div>
                    </div>
            

            <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Area <span class="required">*</span></label>
                        <select class="form-control mb-md idCategoria " name="idCategoria" required="">
                            '.mainModel::getListAuto("SELECT * FROM tcategoria","idCategoria","name",$idCategoria,"update").'
                          </select>
                      </div>
                    </div>

                    <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Precio </label>
                      <input type="text" name="precio" maxlength="50" class="form-control precio"   value="'.$req['precio'].'"  >
                      </div>
             </div> 

     
            

                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
$datoslist="";
$titulo="Registro de Usuario";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">
    <div class="col-sm-6 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Producto </label>
                      <input type="text" name="name" maxlength="80" class="form-control name"     >
                      </div>
             </div>
               <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Stock </label>
                      <input type="number" name="stock" maxlength="50" class="form-control stock"     >
                      </div>
             </div> 
              <div class="col-sm-3 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Medida <span class="required">*</span></label>
                        <select class="form-control mb-md idMedida " name="idMedida" required="">
                        '.mainModel::getList("SELECT * FROM tmedida","idMedida").'
                          </select>
                      </div>
                    </div>

                    <div class="col-sm-6 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Categoria <span class="required">*</span></label>
                        <select class="form-control mb-md idCategoria " name="idCategoria" required="">
                            '.mainModel::getList("SELECT * FROM tcategoria","idCategoria").'
                          </select>
                      </div>
                    </div>


                      <div class="col-sm-3 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Precio </label>
                      <input type="number" name="precio" maxlength="50" class="form-control precio"     >
                      </div>
             </div> 


             
             
      

                     

               

</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idProduct"  name="idProduct" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveProductController(){
      
$name=mainModel::limpiar_cadena($_POST['name']);
$stock=mainModel::limpiar_cadena($_POST['stock']);
$idMedida=mainModel::limpiar_cadena($_POST['idMedida']);
$idCategoria=mainModel::limpiar_cadena($_POST['idCategoria']);
$precio=mainModel::limpiar_cadena($_POST['precio']);
 //$queryArea = mainModel::execute_query("SELECT abreviatura FROM tcategoria where idCategoria =  ".$idCategoria);
 //$nameAreaQ =   $queryArea->fetch(PDO::FETCH_ASSOC);
 //$nameArea = $nameAreaQ["abreviatura"];


 /**$queryUltimoProducto = mainModel::execute_query("SELECT idProduct FROM tproduct ORDER BY idProduct DESC LIMIT 1 ");
$codProductQ = $queryUltimoProducto->fetch(PDO::FETCH_ASSOC);
$codProduct= (int) $codProductQ["idProduct"] ;
$codProduct = $codProduct+1;**/


  //$consultaLoguin = mainModel::execute_query("SELECT * FROM tproduct WHERE name='$name'  ");
  //$vloguin=$consultaLoguin->rowCount();


//if( $vloguin>=1  ){ $msg=["alert"=>"duplicidad","campo"=>"Ya existe un  producto con este nombre "];}
//if ( $vloguin <= 1 ) {
         //"codProduct"=>$nameArea."0".$codProduct,

 $data=[ "name"=>$name,
         "stock"=>stock,
         "idMedida"=>$idMedida,
         "idCategoria"=>$idCategoria,
         "precio"=>$precio
      ];
if (ProductModel::saveProductModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

//}

 return mainModel::mensajeRespuesta($msg);
 }

    public function updateProductController(){

    $idProduct =mainModel::decryption($_POST['idProduct']);
$name=mainModel::limpiar_cadena($_POST['name']);
$stock=mainModel::limpiar_cadena($_POST['stock']);
$idMedida=mainModel::limpiar_cadena($_POST['idMedida']);
$idCategoria=mainModel::limpiar_cadena($_POST['idCategoria']);
$precio=mainModel::limpiar_cadena($_POST['precio']);
/**
 $queryArea = mainModel::execute_query("SELECT abreviatura FROM tcategoria where idCategoria =  ".$idCategoria);
 $nameAreaQ =   $queryArea->fetch(PDO::FETCH_ASSOC);
 $nameArea = $nameAreaQ["abreviatura"];**/




  $data=[
        "idProduct"=>$idProduct,
        "name"=>$name,
         "stock"=>stock,
         "idMedida"=>$idMedida,
         "idCategoria"=>$idCategoria,
         "precio"=>$precio
      ];

      
if (ProductModel::updateProductModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}


   
      return mainModel::mensajeRespuesta($msg);
    }

}

 