 <?php 
if ($peticionAjax) {
  require_once "../model/ServiciosModel.php";
}else{
  require_once "./model/ServiciosModel.php";
}

class ServiciosController extends ServiciosModel{



  public function listServiciosController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idServicio',
    1 =>  'nombre',
    2 =>  'precio'
);  
$index=0;
if ($request['order'][0]['column']!=4) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*  FROM servicio as t1  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.nombre Like '%".$request['search']['value']."%'  )";
     //   $sql.= "OR t1.precio Like '%".$request['search']['value']."%' )";
       // $sql.= "OR t2.nombre Like '%".$request['search']['value']."%' 
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idServicio']);
     $row['idServicio']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombre']; 
     $subdata[]=$row['precio']; 
   
 
   // $subdata[]="   <a href='".$linkfile."' target='_BLANK' class='btn btn-info mr-xs btn-xs ' >         
    //   <i class='text-light fa  fa-download fa-lg'></i> ".$row['document']." </a>"; 
   // $subdata[]=$row['groupdefault']; 
   // $test=SERVERURL."ajax/criterionrepotAjax.php?report=".$row['idServicios'];  <a href='".$test."' target='_BLANK' class='btn btn-warning mr-xs btn-xs ' >   <i class='text-light fa  fa-file-pdf-o fa-lg'></i></a>

    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'serviciosAjax'."`,`".SERVERURL."`,`".'idServicio'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'serviciosAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idServicios=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteServiciosController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("servicio",$idElemento,$status,"idServicio")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idServicios  =mainModel::limpiar_cadena($_GET['idServicio']);
      $idServicios   =mainModel::decryption($idServicios);
  $consulta =mainModel::execute_query("SELECT t1.*   FROM servicio as t1  WHERE t1.idServicio=$idServicios");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
     $idServicio =$req['idServicio'];

 
$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Area de Servicio </label>
                      <input type="text" name="nombre" maxlength="250" class="form-control nombre" value="'.$req['nombre'].'"    >
                      </div>
             </div> 
  <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Precio</label>
 <input type="number" name="precio" class="form-control precio" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['precio'].'" >
                      </div>
          </div>
     


                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Servicios";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Area de Servicio </label>
                      <input type="text" name="nombre" maxlength="70" class="form-control nombre"     >
                      </div>
             </div> 

       <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Precio</label>
 <input type="number" name="precio" class="form-control precio" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>




</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idServicio"  name="idServicio" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveServiciosController(){
      
$nombre=mainModel::limpiar_cadena($_POST['nombre']);

$precio=mainModel::limpiar_cadena($_POST['precio']);

      $consultaName = mainModel::execute_query("SELECT * FROM servicio WHERE nombre='$nombre'  ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe un area de servicio con este nombre"];
}
if ($vnombre<1) {
//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "nombre"=>$nombre,
 "precio"=>$precio
      ];
if (ServiciosModel::saveServiciosModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updateServiciosController(){
    $idServicio =mainModel::limpiar_cadena($_POST['idServicio']);
      $idServicio  =mainModel::decryption($idServicio);
$nombre=mainModel::limpiar_cadena($_POST['nombre']);
$precio=mainModel::limpiar_cadena($_POST['precio']);


      $consultaName = mainModel::execute_query("SELECT * FROM servicio WHERE nombre='$nombre' and idServicio!=$idServicio ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El nombre del area de servicio ya esta registrada anteriormente"];
}
if ($vnombre<1) {

  $data=[
        "idServicio"=>$idServicio,
          "nombre"=>$nombre,
           "precio"=>$precio
      ];

      
if (ServiciosModel::updateServiciosModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 