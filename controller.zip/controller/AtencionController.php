<?php if ($peticionAjax) {
  require_once "../model/AtencionModel.php";
}else{
  require_once "./model/AtencionModel.php";
}

class AtencionController extends AtencionModel{

  public function verifipago($encryp,$msg){
    $descry=mainModel::decryption($encryp);
     $consulta =mainModel::execute_query("SELECT *  FROM boleta  WHERE idAtencion=$descry and status = 1");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
  $result=$consulta->rowCount();
 $html="<a onclick='modalOnPAgar(`".$encryp."`,`".SERVERURL."ajax/atencionAjax.php"."`,`".$msg."`)' class='btn btn-warning btn-xs  mr-xs'>
                  <i class='fa  fa-money' aria-hidden='true'></i>
                </a>
   

 ";
if($result>=1){

$encryp=$req['idBoleta'];

    $encryp=mainModel::encryption($encryp);
$url=SERVERURL."ajax/reportBoletaAjax.php?report=".$encryp;

    $html=" <a onclick='ventanaReport(`".$url."`)' class='btn btn-warning btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i>Boleta
                </a>";

}

         return $html;       
  }



public function reportboleta($encryp){
    $descry=mainModel::decryption($encryp);
     $consulta =mainModel::execute_query("SELECT *  FROM boleta  WHERE idBoleta =$descry");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
  return $req;
}


  public function listAtencionController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idAtencion',
    1 =>  't3.nombres',
    2=> 't2.nombre',
    3 =>  'precio',
    4 =>'t4.nombres',
    5 =>  'status',
        6 =>  'fecha'

);  
$index=0;
if ($request['order'][0]['column']!=5) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==5) {
$index=0;
}
 $sqlfechas="";
    if($_POST['fecha1']!=""){
      $fech1=mainModel::limpiar_cadena($_POST['fecha1']);
    $fech1 = str_replace('/', '-', $fech1);

      $f1 = strtotime($fech1); //Convierte el string a formato de fecha en php
      $fecha1 = date('Y-m-d',$f1);
      $sqlfechas='and CAST(t1.fecha AS DATE ) >= "'.$fecha1.'"';          
    }
    
    if($_POST['fecha2']!=""){
      $fech2=mainModel::limpiar_cadena($_POST['fecha2']);
          $fech2 = str_replace('/', '-', $fech2);

      $f2 = strtotime($fech2); //Convierte el string a formato de fecha en php
      $fecha2 = date('Y-m-d',$f2);
      $sqlfechas='and CAST(t1.fecha AS DATE ) <= "'.$fecha2.'"';    
    }
    
    if ($_POST['fecha1']!="" && $_POST['fecha2']) {
      $fech1=mainModel::limpiar_cadena($_POST['fecha1']);
         $fech1 = str_replace('/', '-', $fech1);

      $f1 = strtotime($fech1); //Convierte el string a formato de fecha en php
      $fecha1 = date('Y-m-d',$f1);
      $fech2=mainModel::limpiar_cadena($_POST['fecha2']);
                $fech2 = str_replace('/', '-', $fech2);
      $f2 = strtotime($fech2); //Convierte el string a formato de fecha en php
      $fecha2 = date('Y-m-d',$f2);   
      $sqlfechas='and CAST(t1.fecha AS DATE ) BETWEEN "'.$fecha1.'" and "'.$fecha2.'"   ';    
    }




$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.nombre as nombreServicio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t3.numeroSis,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional WHERE t1.status=$status   or t1.status=2 or t1.status=3 $sqlfechas";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t3.apellidoPaterno Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.nombres Like '%".$request['search']['value']."%' ";
        $sql.= "OR t3.dni Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
$estado = "";
$tmpaccion="";
       $encryp2=mainModel::encryption($row['idAtencion']);
$htmlhistory='';
switch ($row['status']) {
    case 0:
        $estado = '<span class="badge bg-danger">Cancelado</span>';
        break;
   
    case 1:
        $estado = '<span class="badge bg-primary">Registrado</span>';
        break;
    case 2:
       $estado = '<span class="badge bg-warning text-dark">Triaje</span>';
        break;
    case 3:
          $estado = '<span class="badge bg-info text-dark">Atendido</span>';
        break;
    
    default:
        // code...
        break;
}
       $encryp=mainModel::encryption($row['idAtencion']);
       $nsis="0.00";                 
if($row['numeroSis'] == null || $row['numeroSis'] == ""){
$nsis=$row['precio'];    
}       
     $row['idAtencion']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']; 
    $subdata[]=$row['nombreServicio'];
    $subdata[]=$row['precio']; 
    $subdata[]=$row['nombreProfesional'].' '.$row['apellidoPaternoProfesional']; 
    $subdata[]= $estado; 
    $subdata[]= date("d/m/Y",strtotime($row['fecha']));
    $msg=$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']." Total a pagar:".$nsis;
          
$tmpaccion=self::verifipago($encryp,$msg);
  $urlrep=SERVERURL.'ajax/reporticketAjax.php?report='.$encryp;

    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'atencionAjax'."`,`".SERVERURL."`,`".'idAtencion'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
<a onclick='ventanaReport(`".$urlrep."`)' class='btn btn-warning btn-xs  mr-xs'>
                  #
                </a>


               ".$tmpaccion."   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'atencionAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }



public function saverecivo(){
     $idElemento = mainModel::limpiar_cadena($_GET['id']);
      $idElemento=mainModel::decryption($idElemento);
   $consulta =mainModel::execute_query("SELECT t1.*,t2.nombre as nombreServicio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional,t5.nombre as especialidad FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional INNER JOIN especialidad as t5 ON t4.idEspecialidad  =t5.idEspecialidad  WHERE t1.idAtencion=$idElemento");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
  
  //numeroSis

  
$paciente=$req['nombres']." ".$req['apellidoPaterno']." ".$req['apellidoMaterno'];
$nombreServicio=$req['nombreServicio'];
$precio=$req['precio']; $especialidad=$req['especialidad'];
$data=["idAtencion"=>$idElemento,"especialidad"=>$especialidad,"servicio"=>$nombreServicio,"precio"=>$precio,"paciente"=>$paciente];
$instsave=AtencionModel::saveReciboModel($data);
            $consultab =mainModel::execute_query("SELECT *  FROM boleta  WHERE idAtencion=$idElemento");
  $reqb = $consultab->fetch(PDO::FETCH_ASSOC);
  $idBoleta=$reqb['idBoleta'];
   $encryp=mainModel::encryption($idBoleta);
                $urlrep=SERVERURL."ajax/reportBoletaAjax.php?report=".$encryp;
        $msg=["alert"=>"updatectz","url"=>$urlrep];
      return mainModel::mensajeRespuesta($msg);
}





public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idAtencion=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteAtencionController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("especialidad",$idElemento,$status,"idAtencion")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idAtencion  =mainModel::limpiar_cadena($_GET['idAtencion']);
      $idAtencion   =mainModel::decryption($idAtencion);
  $consulta =mainModel::execute_query("SELECT t1.*  FROM atencion as t1  WHERE t1.idAtencion=$idAtencion");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
     $idServicio =$req['idServicio'];
     $idPaciente =$req['idPaciente'];
$idProfesional =$req['idProfesional'];
 
$saveUpdate='update';
$cuerpo=' <div class="row">
  <div class="col-sm-7 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Paciente <span class="required">*</span></label>
                        <select class="form-control mb-md idPacienteup " name="idPaciente" data-live-search="true" required="">

                         '.mainModel::getListAuto("SELECT * FROM paciente","idPaciente","nombres",$idPaciente,"update").'
                          
                     
                          </select>
                      </div>
                    </div>

                     <div class="col-sm-5 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicioup " name="idServicio"  data-live-search="true" required="">
                     '.mainModel::getListAuto("SELECT * FROM servicio","idServicio","nombre",$idServicio,"update").'
                          </select>
                      </div>
                    </div>

     <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Precio</label>
 <input type="number" name="precio" class="form-control precio" min="0" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['precio'].'" >
                      </div>
          </div>

                     <div class="col-sm-10 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Especialista / Profesional <span class="required">*</span></label>
                        <select class="form-control mb-md idProfesionalup " name="idProfesional"  data-live-search="true" required="">
                                 '.mainModel::getListAuto("SELECT * FROM profesional where idCargo = 2","idProfesional","nombres",$idProfesional,"update").'
                     
                          </select>
                      </div>
                    </div>
                </div> <script>      $(".idPacienteup").selectpicker();
    $(".idServicioup").selectpicker();
    $(".idProfesionalup").selectpicker();
    </script>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Atencion";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">

 <div class="col-sm-7 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Paciente <span class="required">*</span></label>
                        <select class="form-control mb-md idPaciente " data-live-search="true" name="idPaciente" required="" onchange="onSis()">
                            '.mainModel::getListPacientes("SELECT * FROM paciente ","idPaciente").'
                     
                          </select>
                      </div>
                    </div>
 <div class="col-sm-5 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicio " name="idServicio" data-live-search="true"  data-size="5" required="">
                            '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
                    </div>

     <div class="col-sm-2 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Precio</label>
 <input type="number" name="precio" class="form-control precio" min="0" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >
                      </div>
          </div>

     



                     <div class="col-sm-10 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Especialista / Profesional <span class="required">*</span></label>
                        <select class="form-control mb-md idProfesional " data-live-search="true" name="idProfesional" required="">
                            '.mainModel::getListMedicos("SELECT t1.*,t2.nombre as nombreEspecialidad,(SELECT COUNT(idDetalleHorario) from detallehorario WHERE dia =( SELECT CONCAT(ELT(WEEKDAY(CURRENT_DATE()) + 1, 'lunes', 'martes', 'miercoles', 'juevez', 'viernes', 'sabado', 'domingo'))) and idHorario = (SELECT idHorario from horario where idProfesional = t1.idProfesional) ) AS turno , (SELECT horaInicio from detallehorario WHERE dia =( SELECT CONCAT(ELT(WEEKDAY(CURRENT_DATE()) + 1, 'lunes', 'martes', 'miercoles', 'juevez', 'viernes', 'sabado', 'domingo'))) and idHorario = (SELECT idHorario from horario where idProfesional = t1.idProfesional) ) AS horaInicio, (SELECT horaFin from detallehorario WHERE dia =( SELECT CONCAT(ELT(WEEKDAY(CURRENT_DATE()) + 1, 'lunes', 'martes', 'miercoles', 'juevez', 'viernes', 'sabado', 'domingo'))) and idHorario = (SELECT idHorario from horario where idProfesional = t1.idProfesional) ) AS horaFin FROM profesional as t1 INNER JOIN especialidad as t2 on t1.idEspecialidad = t2.idEspecialidad where idCargo = 2","idProfesional").'
                     
                          </select>
                      </div>
                    </div>


</div>    ';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >

    <input type="hidden" class="idAtencion"  name="idAtencion" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                       ';
                            if ($saveUpdate=="save") {
   $html.='  <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>

   <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>

                </footer>
              </section> 
               ';
 return $html;
}
public function reportAtencionGroup(){
        $extra=" ";
$table="";
$sqlfechas=" ";
$txtm="";
$txty="";
$txtst="";
if(isset($_GET['st'])){
if($_GET['st']==0){
    $txtst=" t1.status!=0 ";
}
else{$st=mainModel::limpiar_cadena($_GET['st']);
        $txtst=" t1.status=$st ";
}
}


if($_GET['fecha1']!=""){
      $fech1=mainModel::limpiar_cadena($_GET['fecha1']);
    $fech1 = str_replace('/', '-', $fech1);

      $f1 = strtotime($fech1); //Convierte el string a formato de fecha en php
      $fecha1 = date('Y-m-d',$f1);
      $sqlfechas='and CAST(t1.fecha AS DATE ) >= "'.$fecha1.'"';          
    }
    
    if($_GET['fecha2']!=""){
      $fech2=mainModel::limpiar_cadena($_GET['fecha2']);
          $fech2 = str_replace('/', '-', $fech2);

      $f2 = strtotime($fech2); //Convierte el string a formato de fecha en php
      $fecha2 = date('Y-m-d',$f2);
      $sqlfechas='and CAST(t1.fecha AS DATE ) <= "'.$fecha2.'"';    
    }
    
    if ($_GET['fecha1']!="" && $_GET['fecha2']) {
      $fech1=mainModel::limpiar_cadena($_GET['fecha1']);
         $fech1 = str_replace('/', '-', $fech1);

      $f1 = strtotime($fech1); //Convierte el string a formato de fecha en php
      $fecha1 = date('Y-m-d',$f1);
      $fech2=mainModel::limpiar_cadena($_GET['fecha2']);
                $fech2 = str_replace('/', '-', $fech2);
      $f2 = strtotime($fech2); //Convierte el string a formato de fecha en php
      $fecha2 = date('Y-m-d',$f2);   
      $sqlfechas='and CAST(t1.fecha AS DATE ) BETWEEN "'.$fecha1.'" and "'.$fecha2.'"   ';    
    }

if (isset($_GET['mesAct'])) {
if ($_GET['mesAct']!="" && $_GET['mesAct']!=0) {

  $txtd="";
$mes=$_GET['mesAct'];
$txtm="and YEAR(t1.fecha) = YEAR(CURRENT_DATE()) AND MONTH(t1.fecha) = $mes ";
}

}

if (isset($_GET['yearAct'])) {
  if ($_GET['yearAct']!="" && $_GET['yearAct']!=null) {
  $txtd="";
$txtm="";
$txtrf="";
$año=$_GET['yearAct'];
$txty='and YEAR(t1.fecha) = "'.$año.'"';  }
}

    $consultareport = mainModel::execute_query("SELECT t1.*,t2.nombre as nombreServicio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t3.numeroSis,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional WHERE ".$txtst."  ".$sqlfechas."   ".$txtm." ".$txty." ORDER BY t1.idAtencion   ASC");
   $reqcash = $consultareport->fetchAll(PDO::FETCH_ASSOC);
    $datos='';
    foreach ($reqcash as $key => $row) {
$estado = "";
$tmpaccion="";
$htmlhistory='';
switch ($row['status']) {
    case 0:
        $estado = '<span class="badge bg-danger">Cancelado</span>';
        break;
   
    case 1:
        $estado = '<span class="badge bg-primary">Registrado</span>';
        break;
    case 2:
       $estado = '<span class="badge bg-warning text-dark">Triaje</span>';
        break;
    case 3:
          $estado = '<span class="badge bg-info text-dark">Atendido</span>';
        break;
    
    default:
        // code...
        break;
}
       $nsis="0.00";                 
if($row['numeroSis'] == null || $row['numeroSis'] == ""){
$nsis=$row['precio'];    
}       
        $extrr=$key+1;
$table.=" <tr>
                      <td>
                      ".$extrr."
                     </td>
                     <td>
           ".$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']."
                     </td>
                     <td>
                      ".$row['nombreServicio']."
                     </td>
                      <td>
                      ".$row['precio']."
                     </td>
                       <td>
                      ".$row['nombreProfesional']." ".$row['apellidoPaternoProfesional']."
                     </td>
                     <td>".$estado." </td> 
                     <td>".date("d/m/Y",strtotime($row['fecha']))." </td>
</tr>
 ";

}
return $table;
}



public function reportticket($idAtencion){
    $idAtencion=mainModel::decryption($idAtencion);
   $consultareport = mainModel::execute_query("SELECT t1.*,t2.nombre as nombreServicio,t3.nombres,t3.apellidoPaterno,t3.apellidoMaterno,t3.numeroSis,t4.nombres as nombreProfesional, t4.apellidoPaterno as apellidoPaternoProfesional FROM atencion as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio  INNER JOIN paciente as t3 ON t1.idPaciente =t3.idPaciente INNER JOIN profesional as t4 ON t1.idProfesional =t4.idProfesional WHERE t1.idAtencion=$idAtencion ");
 $reqreport = $consultareport->fetch(PDO::FETCH_ASSOC);

return $reqreport;
}


    public function saveAtencionController(){
      
$idPaciente=mainModel::limpiar_cadena($_POST['idPaciente']);
$precio=mainModel::limpiar_cadena($_POST['precio']);
$idServicio=mainModel::limpiar_cadena($_POST['idServicio']);
$idProfesional=mainModel::limpiar_cadena($_POST['idProfesional']);
//$idUsuario=mainModel::limpiar_cadena($_POST['idUsuario']);
$idUsuario= 1;
  $consultacash = mainModel::execute_query("SELECT COUNT(*) AS nticket FROM atencion WHERE idServicio=$idServicio and CAST(fecha AS DATE ) =CURDATE() ");
 $reqcash = $consultacash->fetch(PDO::FETCH_ASSOC);
$nticket=$reqcash['nticket'];
$nticket++;

//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "idPaciente"=>$idPaciente,
         "precio"=>$precio,
         "idServicio"=>$idServicio,
         "idProfesional"=>$idProfesional,
         "idUsuario"=>$idUsuario,"nticket"=>$nticket
      ];
if (AtencionModel::saveAtencionModel($data)!="error") {
   $consultareport = mainModel::execute_query("SELECT *  FROM atencion WHERE nticket=$nticket and CAST(fecha AS DATE ) =CURDATE() ");
 $reqreport = $consultareport->fetch(PDO::FETCH_ASSOC);
$encry=$reqreport['idAtencion'];
$encry=mainModel::encryption($encry);
$urlrep=SERVERURL.'ajax/reporticketAjax.php?report='.$encry;


   $msg=["alert"=>"savereportAt","url"=>$urlrep];

}else{
 $msg=["alert"=>"error"];
}


 return mainModel::mensajeRespuesta($msg);
 }

   

}

 