 <?php 
if ($peticionAjax) {
  require_once "../model/EspecialidadesModel.php";
}else{
  require_once "./model/EspecialidadesModel.php";
}

class EspecialidadesController extends EspecialidadesModel{



  public function listEspecialidadesController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idEspecialidad',
    1 =>  'nombre'
);  
$index=0;
if ($request['order'][0]['column']!=4) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.* FROM especialidad as t1  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.nombre Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' )";
        //$sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idEspecialidad']);
     $row['idEspecialidad']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombre']; 
  


    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'especialidadesAjax'."`,`".SERVERURL."`,`".'idEspecialidad'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'especialidadesAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idEspecialidades=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteEspecialidadesController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("especialidad",$idElemento,$status,"idEspecialidad")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idEspecialidades  =mainModel::limpiar_cadena($_GET['idEspecialidad']);
      $idEspecialidades   =mainModel::decryption($idEspecialidades);
  $consulta =mainModel::execute_query("SELECT t1.*,t2.idServicio   FROM especialidad as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio WHERE t1.idEspecialidad=$idEspecialidades");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
     $idServicio =$req['idServicio'];

 
$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Especialidad </label>
                      <input type="text" name="nombre" maxlength="250" class="form-control nombre" value="'.$req['nombre'].'"    >
                      </div>
             </div> 

    

 
                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Especialidades";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Especialidad </label>
                      <input type="text" name="nombre" maxlength="250" class="form-control nombre"     >
                      </div>
             </div> 

    




</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >

    <input type="hidden" class="idEspecialidad"  name="idEspecialidad" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveEspecialidadesController(){
      
$nombre=mainModel::limpiar_cadena($_POST['nombre']);




      $consultaName = mainModel::execute_query("SELECT * FROM especialidad WHERE nombre='$nombre'  ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe una especialidad con este nombre"];
}
if ($vnombre<1) {
//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "nombre"=>$nombre
      ];
if (EspecialidadesModel::saveEspecialidadesModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updateEspecialidadesController(){
    $idEspecialidad =mainModel::limpiar_cadena($_POST['idEspecialidad']);
      $idEspecialidad  =mainModel::decryption($idEspecialidad);
$nombre=mainModel::limpiar_cadena($_POST['nombre']);


      $consultaName = mainModel::execute_query("SELECT * FROM especialidad WHERE nombre='$nombre' and idEspecialidad!=$idEspecialidad ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El nombre de la especialidad ya esta registrada anteriormente"];
}
if ($vnombre<1) {

  $data=[
        "idEspecialidad"=>$idEspecialidad,
          "nombre"=>$nombre
      ];

      
if (EspecialidadesModel::updateEspecialidadesModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 