 <?php 
if ($peticionAjax) {
  require_once "../model/PagosModel.php";
}else{
  require_once "./model/PagosModel.php";
}

class PagosController extends PagosModel{

  public function verifipago($encryp,$msg){
    $descry=mainModel::decryption($encryp);
     $consulta =mainModel::execute_query("SELECT *  FROM boleta  WHERE idBoleta=$descry and status = 1");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
  $result=$consulta->rowCount();
 $html="<a onclick='modalOnPAgar(`".$encryp."`,`".SERVERURL."ajax/atencionAjax.php"."`,`".$msg."`)' class='btn btn-warning btn-xs  mr-xs'>
                  <i class='fa  fa-money' aria-hidden='true'></i>
                </a>
   

 ";
if($result>=1){

$encryp=$req['idBoleta'];

    $encryp=mainModel::encryption($encryp);
$url=SERVERURL."ajax/reportBoletaAjax.php?report=".$encryp;

    $html=" <a onclick='ventanaReport(`".$url."`)' class='btn btn-warning btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i>Boleta
                </a>";

}

         return $html;       
  }


  public function listPagosController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idBoleta',
    1 =>  'paciente',
    2 =>  'especialidad',
    3 =>  'precio',
    4 =>  'servicio',
);  
$index=0;
if ($request['order'][0]['column']!=4) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.* FROM boleta as t1  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.paciente Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' )";
        //$sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idBoleta']);

     $row['idBoleta']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['paciente'];
    $subdata[]=$row['especialidad'];
    $subdata[]=$row['precio'];
    $subdata[]=$row['servicio'];
      $msg=$row['paciente']." Total a pagar:".$row['precio'];
    $tmpaccion=self::verifipago($encryp,$msg);
  


    $subdata[]="
     ".$tmpaccion."  
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'pagosAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i> Anular</button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idPagos=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeletePagosController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("boleta",$idElemento,$status,"idBoleta")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idPagos  =mainModel::limpiar_cadena($_GET['idBoleta']);
      $idPagos   =mainModel::decryption($idPagos);
  $consulta =mainModel::execute_query("SELECT t1.*,t2.idServicio   FROM especialidad as t1 INNER JOIN servicio as t2 ON t1.idServicio =t2.idServicio WHERE t1.idBoleta=$idPagos");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
     $idServicio =$req['idServicio'];

 
$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Especialidad </label>
                      <input type="text" name="nombre" maxlength="250" class="form-control nombre" value="'.$req['nombre'].'"    >
                      </div>
             </div> 

    

 
                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Pagos";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Especialidad </label>
                      <input type="text" name="nombre" maxlength="250" class="form-control nombre"     >
                      </div>
             </div> 

    




</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >

    <input type="hidden" class="idBoleta"  name="idBoleta" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function savePagosController(){
      
$nombre=mainModel::limpiar_cadena($_POST['nombre']);




      $consultaName = mainModel::execute_query("SELECT * FROM especialidad WHERE nombre='$nombre'  ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe una especialidad con este nombre"];
}
if ($vnombre<1) {
//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "nombre"=>$nombre
      ];
if (PagosModel::savePagosModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updatePagosController(){
    $idBoleta =mainModel::limpiar_cadena($_POST['idBoleta']);
      $idBoleta  =mainModel::decryption($idBoleta);
$nombre=mainModel::limpiar_cadena($_POST['nombre']);


      $consultaName = mainModel::execute_query("SELECT * FROM especialidad WHERE nombre='$nombre' and idBoleta!=$idBoleta ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El nombre de la especialidad ya esta registrada anteriormente"];
}
if ($vnombre<1) {

  $data=[
        "idBoleta"=>$idBoleta,
          "nombre"=>$nombre
      ];

      
if (PagosModel::updatePagosModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 