<?php 

if ($peticionAjax) {
  require_once "../model/PerfilModel.php";
}else{
  require_once "./model/PerfilModel.php";
}


class PerfilController extends PerfilModel{
  

   public function paintForm($saveUpdate){
   $idProfesional=mainModel::decryption($_SESSION['idAdminClinica']); 
      $cnn = mainModel::conect();

$data = $cnn->query("SELECT * FROM tprofesional WHERE idProfesional = $idProfesional");
$data = $data->fetch(PDO::FETCH_ASSOC); 


  $html = '<h4 class="mb-xlg">Personal Informacion</h4>
                      <fieldset>
                  <div class="row">
                    <div class="col-sm-3  mb-xs">
                      <div class="form-group">
                      <input type="hidden"  name="'.$saveUpdate.'" >
                        <label class="control-label">Nombres  <span class="required">*</span></label>
                        <input type="text" name="name" class="form-control name"  maxlength="80" value="'.$data['name'].'" required="">
                      </div>
                    </div>

                
           <div class="col-sm-3  mb-xs">
                      <div class="form-group">
                        <label class="control-label">Apellidos  <span class="required">*</span></label>
                        <input type="text" name="lastName" class="form-control lastName"  maxlength="80" value="'.$data['lastName'].'" required="">
                      </div>
          </div>
          <div class="col-sm-3  mb-xs">
                      <div class="form-group">
                        <label class="control-label">Apellidos  <span class="required">*</span></label>
                        <input type="text" name="dni" class="form-control dni"  maxlength="80" value="'.$data['dni'].'" required="">
                      </div>
          </div>

         <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Cargo <span class="required">*</span></label>
                        <select class="form-control mb-md idCargo " name="idCargo" required="">
                            '.mainModel::getListAuto("SELECT * FROM tcargo","idCargo","name",$data['idCargo'],"update").'
                     
                          </select>
                      </div>
                    </div>
      <div class="col-sm-3 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Email <span class="required">*</span></label>
<input class="form-control" type="email" name="email"  value="'.$data['email'].'"  maxlength="50" required>
                      </div>
                    </div>

                  </div>
      
             </fieldset>  ';

            return $html;
} 



public function updatePerfilController(){
   $idProfesional=mainModel::decryption($_SESSION['idAdminClinica']);
    $name= mainModel::limpiar_cadena($_POST['name']);
    $lastName= mainModel::limpiar_cadena($_POST['lastName']); 
    $email= mainModel::limpiar_cadena($_POST['email']);
    $idCargo= mainModel::limpiar_cadena($_POST['idCargo']);
    $dni= mainModel::limpiar_cadena($_POST['dni']);
      $data=[
        "idProfesional"=>$idProfesional,
        "name"=>$name,
        "lastName"=>$lastName,
        "email"=>$email,
        "idCargo"=>$idCargo,
        "dni"=>$dni
      ];
    
    if(PerfilModel::updatePerfilModel($data)!= "error"){
    $msg=["alert"=>"updatepersonalizado","campo"=>"Los datos se Actualizaron de manera exitosa" ,"operacion"=>"" ];
      }else{
      $msg=["alert"=>"error"];
      }
  
    return mainModel::mensajeRespuesta($msg);
    }

public function updatePasswordPerfilController(){
   $idProfesional=mainModel::decryption($_SESSION['idAdminClinica']);
    $passwordActual= mainModel::limpiar_cadena($_POST['passwordActual']);
    $password= mainModel::limpiar_cadena($_POST['password']);
  $data=[
      "password"=>$password,
        "idProfesional"=>$idadmin
    ];


  $valider =mainModel::execute_query("SELECT name FROM tprofesional WHERE password='$passwordActual'AND idProfesional=$idProfesional");
    
    if ($valider->rowCount()>=1 ) {
     if(PerfilModel::updateContraseñaPerfilModel($data)){
 $msg=["alert"=>"updatepersonalizado",
 "campo"=>"Los datos se Actualizaron de manera exitosa","operacion"=>"Password" ];

     }
     else{
     $msg=["alert"=>"error"];

     }
    
} else{
     $msg=["alert"=>"contraseñaError"];

     }

  return mainModel::mensajeRespuesta($msg);
  }




}