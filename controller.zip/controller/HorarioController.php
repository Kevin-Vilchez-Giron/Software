<?php if ($peticionAjax) {
  require_once "../model/HorarioModel.php";
}else{
  require_once "./model/HorarioModel.php";
}

class HorarioController extends HorarioModel{



  public function listHorarioController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idHorario',
    1 =>  'nombres',
    2 =>  't3.nombre'
);  
$index=0;
if ($request['order'][0]['column']!=4) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t2.nombres ,t2.apellidoPaterno,t2.apellidoMaterno,t3.nombre as nombreEspecialidad FROM horario  as t1 INNER JOIN profesional as t2 on t1.idProfesional = t2.idProfesional INNER JOIN especialidad as t3 on t2.idEspecialidad = t3.idEspecialidad  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.nombre Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.precio Like '%".$request['search']['value']."%' )";
        //$sql.= "OR t2.nombre Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.nombre Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idHorario']);
     $row['idHorario']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['nombres']." ".$row['apellidoPaterno']." ".$row['apellidoMaterno']; 
  $subdata[]=$row['nombreEspecialidad'];
   $urlh=SERVERURL."ajax/reportHorarioAjax.php?report=".$encryp;
  $htmlhistory="<a onclick='ventanaReport(`".$urlh."`)' class='btn btn-info btn-xs  mr-xs'>
                  <i class='fa fa-file-pdf-o' aria-hidden='true'></i> Horario
               ";

   $subdata[]=$htmlhistory;  


    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'horarioAjax'."`,`".SERVERURL."`,`".'idHorario'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'horarioAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }




public function reporthorario($idResultado){
  $idResultado=mainModel::decryption($idResultado);

    $consulta2 =mainModel::execute_query("SELECT t1.*,t2.* from horario as t1 INNER JOIN profesional as t2 on t1.idProfesional = t2.idProfesional
   where idHorario =  $idResultado");
  $req2 = $consulta2->fetch(PDO::FETCH_ASSOC);
  
    $consulta =mainModel::execute_query("SELECT t1.* ,t3.nombre as servicio from detallehorario as t1 INNER JOIN horario as t2 on t1.idHorario = t2.idHorario    INNER JOIN servicio as t3 on t1.idServicio = t3.idServicio  where t1.idHorario =  $idResultado");
  $req = $consulta->fetchAll(PDO::FETCH_ASSOC);

$extra2html='';
   foreach ($req as $index=>$row) {
   
$extra2html.='   <tr>
                <td  translate="yes">'.$row['dia'].'</td>
                <td  translate="yes">'.$row['horaInicio'].'</td>
                <td  translate="yes">'.$row['horaFin'].'</td>
                <td  translate="yes">'.$row['cantidadPacientes'].'</td>
                <td  translate="yes">'.$row['servicio'].'</td>
            
            </tr>';     
}

$html='<div class="col-md-12"> <table id="customers">
            <tr>
                <td  translate="yes"> '.$req2['nombres'].' '.$req2['apellidoPaterno'].' '.$row['apellidoMaterno'].'</td>
            </tr>

          
               
        </table> </div>
        <div class="col-md-12">
  <h5>Horario </h5>
         <table id="customers">
  <thead>
                          <tr>
                             <th>Dia</th>
                             <th>Hora Inicio</th>
                             <th>Hora Final</th>
                             <th>Cantidad de Pacientes</th>
                              <th>Servicio</th>
                        

                          </tr>
                        </thead>
                        <tbody>
         '.$extra2html.'
                                  </tbody>

        </table>


         </div>
';
return $html;
}





public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idHorario=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteHorarioController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("especialidad",$idElemento,$status,"idHorario")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idHorario  =mainModel::limpiar_cadena($_GET['idHorario']);
      $idHorario   =mainModel::decryption($idHorario);
      $consulta =mainModel::execute_query("SELECT t1.*   FROM horario as t1  WHERE t1.idHorario=$idHorario");
      $req = $consulta->fetch(PDO::FETCH_ASSOC);

$consulta2 =mainModel::execute_query("SELECT t1.*   FROM detallehorario as t1  WHERE t1.idHorario=$idHorario");
$dataDetalle = $consulta2->fetchAll(PDO::FETCH_ASSOC);

     $idProfesional =$req['idProfesional'];

 
$saveUpdate='update';
$cuerpo=' <div class="row">
     <div class="col-sm-4 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Especialista / Profesional <span class="required">*</span></label>
                        <select class="form-control mb-md idProfesionalup " name="idProfesionalup"  data-live-search="true" required="" disabled>
                                 '.mainModel::getListAuto("SELECT * FROM profesional where idCargo = 2","idProfesional","nombres",$idProfesional,"update").'
                     
                          </select>
                      </div>
                    </div>
                    </div>';
   
$semanaCompleta1 = array("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo");
 foreach ($semanaCompleta1 as $key => $semanaCompleta) {
    $time="";
  $bandera=0;
   foreach ($dataDetalle as $key => $row) {
   // echo $semanaCompleta."==".$row["dia"]."/";
if($semanaCompleta == $row["dia"]){
   // echo "entro ".$semanaCompleta."==".$row["dia"]."/";
    $bandera=1;
      $horaInicio=date("h:i A",strtotime($row["horaInicio"]));
       $horaFin=date("h:i A",strtotime($row["horaFin"]));
       $idServicio= $row["idServicio"];
        $cuerpo.=' <div class="col-sm-2 mb-xs"> 
<span class="badge bg-primary">'.$row["dia"].'</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="dia'.$row["dia"].'" maxlength="250" class="form-control dia'.$row["dia"].'" value="'.$row["dia"].'"    >
                      <input type="text" data-plugin-timepicker name="horaInicio'.$row["dia"].'" maxlength="250" class="form-control horaInicio'.$row["dia"].'"    placeholder="Hora Entrada" value="'.$horaInicio.'" >
                    
                    </div>

                       <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFin'.$row["dia"].'" maxlength="250" class="form-control horaFin'.$row["dia"].'"  data-plugin-timepicker  placeholder="Hora Salida" value="'.$horaFin.'">
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicio'.$row["dia"].'" name="idServicio'.$row["dia"].'" data-live-search="true"  data-size="5" >
                            '.mainModel::getListAuto("SELECT * FROM servicio","idServicio","nombre",$idServicio,"update").'
                     
                          </select>
                      </div>
             </div> ';
}

}

if($bandera==1){

   
}else if($bandera==0){
    
      $time.='$(".horaInicio'.$semanaCompleta.'").val("");';
         $time.='$(".horaFin'.$semanaCompleta.'").val("");';
              $cuerpo .=' <div class="col-sm-2 mb-xs"> 
<span class="badge bg-danger">'.$semanaCompleta.'</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="dia'.$semanaCompleta.'"  class="form-control dia'.$semanaCompleta.'" value="'.$semanaCompleta.'"    >
                      <input type="text" data-plugin-timepicker name="horaInicio'.$semanaCompleta.'" maxlength="250" class="form-control horaInicio'.$semanaCompleta.'"  value="" >
                    
                    </div>

                       <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFin'.$semanaCompleta.'"  class="form-control horaFin'.$semanaCompleta.'"  data-plugin-timepicker  value="" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicio'.$semanaCompleta.'" name="idServicio'.$semanaCompleta.'" data-live-search="true"  data-size="5" >
                            '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> ';
              $cuerpo.='</div> <script>$("[data-plugin-timepicker]").each(function() {
        var $this = $( this ),  opts = {};
        var pluginOptions = $this.data("plugin-options");
        if (pluginOptions)
          opts = pluginOptions;
        $this.themePluginTimePicker(opts);
      });
     '.$time.'
</script>';
}
}
              

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Horario";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


     <div class="col-sm-12 mb-xs">
                      <div class="form-group">
                        <label class="control-label">Especialista / Profesional <span class="required">*</span></label>
                        <select class="form-control mb-md idProfesionalupsave " name="idProfesional"  data-live-search="true" required="">
                              '.mainModel::getListMedicosHorarios("SELECT t1.*,t2.nombre as nombreEspecialidad FROM profesional as t1 INNER JOIN especialidad as t2 on t1.idEspecialidad = t2.idEspecialidad where idCargo = 2","idProfesional").'
                     
                          </select>
                      </div>
                    </div>


  <div class="col-sm-2 mb-xs"> 
<span class="badge bg-primary">Lunes</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="dialunes" maxlength="250" class="form-control dialunes" value="lunes"    >
                      <input type="text" data-plugin-timepicker name="horaIniciolunes" maxlength="250" class="form-control horaIniciolunes"    placeholder="Hora Entrada" >
                    
                    </div>

                       <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFinlunes" maxlength="250" class="form-control horaFinlunes"  data-plugin-timepicker  placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServiciolunes" name="idServiciolunes" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> 

              <div class="col-sm-2 mb-xs"> 
               <span class="badge bg-success">Martes</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="diamartes" maxlength="250" class="form-control diamartes" value="martes"    >
                      <input type="text" data-plugin-timepicker name="horaIniciomartes" maxlength="250" class="form-control horaIniciomartes"    placeholder="Hora Entrada" >

                      </div>

                        <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFinmartes" maxlength="250" class="form-control horaFinamartes" data-plugin-timepicker   placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServiciomartes" name="idServiciomartes" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> 

              <div class="col-sm-2 mb-xs"> 
            <span class="badge bg-secondary">Miercoles</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="diamiercoles" maxlength="250" class="form-control diamiercoles" value="miercoles"    >
                      <input type="text" name="horaIniciomiercoles" maxlength="250" class="form-control horaIniciomiercoles" data-plugin-timepicker   placeholder="Hora Entrada" >

                       </div>

                        <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFinmiercoles" maxlength="250" class="form-control horaFinmiercoles"  data-plugin-timepicker  placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServiciomiercoles" name="idServiciomiercoles" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> 

               <div class="col-sm-2 mb-xs"> 
                <span class="badge bg-success">Jueves</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="diajueves" maxlength="250" class="form-control diajueves" value="jueves"    >
                      <input type="text" name="horaIniciojueves" maxlength="250" class="form-control horaIniciojueves"  data-plugin-timepicker  placeholder="Hora Entrada" >

                      </div>

                        <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFinjueves" maxlength="250" class="form-control horaFinjueves"  data-plugin-timepicker  placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServiciojueves" name="idServiciojueves" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div>

                <div class="col-sm-2 mb-xs"> 
            <span class="badge bg-danger">Viernes</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="diaviernes" maxlength="250" class="form-control diaviernes" value="viernes"    >
                      <input type="text" name="horaInicioviernes" maxlength="250" class="form-control horaInicioviernes"  data-plugin-timepicker  placeholder="Hora Entrada" >

                       </div>

                        <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFinviernes" maxlength="250" class="form-control horaFinviernes"  data-plugin-timepicker  placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServicioviernes" name="idServicioviernes" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> 

               <div class="col-sm-2 mb-xs"> 
               <span class="badge bg-warning  ">Sabado</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="diasabado" maxlength="250" class="form-control diasabado"  value="sabado"    >
                      <input type="text" name="horaIniciosabado" maxlength="250" class="form-control horaIniciosabado"   data-plugin-timepicker placeholder="Hora Entrada" >

                       </div>

                        <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFinsabado" maxlength="250" class="form-control horaFinsabado"  data-plugin-timepicker  placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServiciosabado" name="idServiciosabado" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> 

              <div class="col-sm-2 mb-xs"> 
              <span class="badge bg-info">Domingo</span>
              <div class="form-group">
                      <label class="control-label">Hora Ingreso </label>
                       <input type="hidden" name="diadomingo" maxlength="250" class="form-control diadomingo"  value="domingo"    >
                      <input type="text" name="horaIniciodomingo" maxlength="250" class="form-control horaIniciodomingo"   data-plugin-timepicker placeholder="Hora Entrada" >

                       </div>

                        <div class="form-group">
                      <label class="control-label">Hora Salida </label>
                      <input type="text" name="horaFindomingo" maxlength="250" class="form-control horaFindomingo"  data-plugin-timepicker  placeholder="Hora Salida" >
                      </div>
                      <div class="form-group">
                        <label class="control-label">Servicios <span class="required">*</span></label>
                        <select class="form-control mb-md idServiciodomingo" name="idServiciodomingo" data-live-search="true"  data-size="5" >
                           '.mainModel::getListServicios("SELECT * FROM servicio","idServicio").'
                     
                          </select>
                      </div>
             </div> 



</div>

';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idHorario"  name="idHorario" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveHorarioController(){
      
$idProfesional=mainModel::limpiar_cadena($_POST['idProfesional']);

$idUsuario=1;

   $consultaName = mainModel::execute_query("SELECT * FROM horario WHERE idProfesional='$idProfesional' ");
  $vnombre=$consultaName->rowCount();
if($vnombre>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El Profesional ya tiene un horario registrado anteriormente"];
}
if ($vnombre<1) {
  $data=[
        "idProfesional"=>$idProfesional,
        "idUsuario"=>$idUsuario
      ];

if (HorarioModel::saveHorarioModel($data)!="error") {
 
 $semana = array("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo");

foreach ($semana as $key => $item) {
    if($_POST['horaInicio'.$item] !="" || $_POST['horaFin'.$item] != "" ){

    $dia=mainModel::limpiar_cadena($_POST['dia'.$item]);
    $horaInicio=mainModel::limpiar_cadena($_POST['horaInicio'.$item]);
    $horaInicio=strtotime($horaInicio);
$horaInicio=date('H:i:s',$horaInicio);
     $horaFin=mainModel::limpiar_cadena($_POST['horaFin'.$item]);
     $idServicio=mainModel::limpiar_cadena($_POST['idServicio'.$item]);
$horaFin=strtotime($horaFin);
$horaFin=date('H:i:s',$horaFin);
      $dataSemana=[
        "idProfesional"=>$idProfesional,
        "dia"=>$dia,
        "horaInicio"=>$horaInicio,
        "horaFin"=>$horaFin,
        "idServicio"=>$idServicio
      ];
      if (HorarioModel::saveDetalleHorarioModel($dataSemana)!="error") {

      }
}
}
 $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}



 return mainModel::mensajeRespuesta($msg);
 }

    public function updateHorarioController(){
          $idHorario =mainModel::limpiar_cadena($_POST['idHorario']);
      $idHorario  =mainModel::decryption($idHorario);
    
     $it = HorarioModel::deleteHorarioModel($idHorario);
 $semana = array("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo");

foreach ($semana as $key => $item) {
    if($_POST['horaInicio'.$item] !="" || $_POST['horaFin'.$item] != "" ){

    $dia=mainModel::limpiar_cadena($_POST['dia'.$item]);
    $horaInicio=mainModel::limpiar_cadena($_POST['horaInicio'.$item]);
    $horaInicio=strtotime($horaInicio);
$horaInicio=date('H:i:s',$horaInicio);
     $horaFin=mainModel::limpiar_cadena($_POST['horaFin'.$item]);
     $idServicio=mainModel::limpiar_cadena($_POST['idServicio'.$item]);
$horaFin=strtotime($horaFin);
$horaFin=date('H:i:s',$horaFin);
      $dataSemana=[
        "dia"=>$dia,
        "idHorario"=>$idHorario,
        "horaInicio"=>$horaInicio,
        "horaFin"=>$horaFin,
        "idServicio"=>$idServicio
      ];
      if (HorarioModel::save2DetalleHorarioModel($dataSemana)!="error") {

      }
}
}
 $msg=["alert"=>"save"];





   
      return mainModel::mensajeRespuesta($msg);
    }





  /**  public function updateHorarioController(){
          $idHorario =mainModel::limpiar_cadena($_POST['idHorario']);
      $idHorario  =mainModel::decryption($idHorario);
    //$idProfesional=mainModel::limpiar_cadena($_POST['idProfesional']);
 
 $semana = array("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo");
 $consulta2 =mainModel::execute_query("SELECT t1.*   FROM detallehorario as t1  WHERE t1.idHorario=$idHorario");
$dataDetalle = $consulta2->fetchAll(PDO::FETCH_ASSOC);
$arrayDias= array();
foreach ($dataDetalle as $key => $row) {
   
  array_push($arrayDias,$row["dia"]);

}
foreach ($semana as $key => $item) {
 
    if(($_POST['horaInicio'.$item]) != "" && ($_POST['horaFin'.$item]) != ""  ){
    
$ban=0;
       foreach ($arrayDias as $key => $row) {
        if($row==$item){
       
$ban=1;
        }

       }
       //inicio if

 $dia=mainModel::limpiar_cadena($_POST['dia'.$item]);
 
$horaInicio=mainModel::limpiar_cadena($_POST['horaInicio'.$item]);
$horaInicio=strtotime($horaInicio);
$horaInicio=date('H:i:s',$horaInicio);
$idServicio=mainModel::limpiar_cadena($_POST['idServicio'.$item]);
$horaFin=mainModel::limpiar_cadena($_POST['horaFin'.$item]);
$horaFin=strtotime($horaFin);
$horaFin=date('H:i:s',$horaFin);

      $dataSemana=[
        "idHorario"=>$idHorario,
        "dia"=>$dia,
        "horaInicio"=>$horaInicio,
        "horaFin"=>$horaFin,
        "idServicio"=>$idServicio
      ];

       if($ban==1){
              echo "update=".$item;
         $it = HorarioModel::updateDetalleHorarioModel($dataSemana);

       }else{
      
      $it2=HorarioModel::save2DetalleHorarioModel($dataSemana);
       }

//fin if
     







}
}

 $msg=["alert"=>"save"];



   
      return mainModel::mensajeRespuesta($msg);
    }**/
}

 