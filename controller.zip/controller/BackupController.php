
<?php 

if ($peticionAjax) {
	require_once "../model/BackupModel.php";
}else{
	require_once "./model/BackupModel.php";
}

class BackupController extends BackupModel
{
	
	
		public function saveBackupController(){
$output = BackupModel::exportdb();
$dbname = mainModel::nombredb();

 $backup_file_name=$dbname.time().'.sql';
$fileHandler=fopen($backup_file_name,'w+');
$number_of_lines=fwrite($fileHandler,$output);
fclose($fileHandler);

echo '
<script>
window.open("'.SERVERURL.'/ajax/'.$backup_file_name.'","_blank");

setTimeout(() => {
  removerfichero(`'.SERVERURL.'`,`'.$backup_file_name.'`);
}, 1000);
</script>';

	}
	function destroyfichero(){
  $fichero=mainModel::limpiar_cadena($_GET['fichadj']);
	unlink("../ajax/".$fichero);
	return '1';
	}
	
	
}