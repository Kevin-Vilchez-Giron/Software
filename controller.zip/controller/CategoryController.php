 <?php 
if ($peticionAjax) {
  require_once "../model/CategoryModel.php";
}else{
  require_once "./model/CategoryModel.php";
}

class CategoryController extends CategoryModel{



  public function listCategoryController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
  0 =>  'idCategoria',
    1 =>  'name'
);  
$index=0;
if ($request['order'][0]['column']!=4) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.* FROM tcategoria as t1  WHERE t1.status=$status";
    if(!empty($request['search']['value'])){
          $sql.=" AND (t1.name Like '%".$request['search']['value']."%' )";
        //$sql.= "OR t2.name Like '%".$request['search']['value']."%' )";
    //$sql.= "OR t3.name Like '%".$request['search']['value']."%')";
    }
  
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
     $subdata=array();
                $contador = $contador+1;
//$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idCategoria']);
     $row['idCategoria']=$encryp;
    $subdata[]=$contador; 

    $subdata[]=$row['name']; 
  


    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'categoryAjax'."`,`".SERVERURL."`,`".'idCategoria'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
   
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'categoryAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }









public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idCategoria=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteCategoryController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("tcategoria",$idElemento,$status,"idCategoria")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }

public function fomUpdate(){
      $idCategoria  =mainModel::limpiar_cadena($_GET['idCategoria']);
      $idCategoria   =mainModel::decryption($idCategoria);
  $consulta =mainModel::execute_query("SELECT t1.*   FROM tcategoria as t1  WHERE t1.idCategoria=$idCategoria");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
  

 
$saveUpdate='update';
$cuerpo=' <div class="row">

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Categoria </label>
                      <input type="text" name="name" maxlength="250" class="form-control name" value="'.$req['name'].'"    >
                      </div>
             </div> 

            

    

 
                </div>';

return $cuerpo;
}


public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
//$datoslist=self::listSelect($saveUpdate,'','');
$datoslist="";
$titulo="Registro de Categoria";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">


    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Categoria </label>
                      <input type="text" name="name" maxlength="250" class="form-control name"     >
                      </div>
             </div> 

    




</div>';
}
if ($saveUpdate=="update") {
$titulo="Editar ";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >

    <input type="hidden" class="idCategoria"  name="idCategoria" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveCategoryController(){
      
$name=mainModel::limpiar_cadena($_POST['name']);




      $consultaName = mainModel::execute_query("SELECT * FROM tcategoria WHERE name='$name'   ");
  $vname=$consultaName->rowCount();
if($vname>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Ya existe una area con este name"];
}
if ($vname<1) {
//$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ 
    "name"=>$name
      ];
if (CategoryModel::saveCategoryModel($data)!="error") {
   $msg=["alert"=>"save"];

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updateCategoryController(){
    $idCategoria =mainModel::limpiar_cadena($_POST['idCategoria']);
      $idCategoria  =mainModel::decryption($idCategoria);
$name=mainModel::limpiar_cadena($_POST['name']);



      $consultaName = mainModel::execute_query("SELECT * FROM tcategoria WHERE name='$name' and idCategoria!=$idCategoria ");
  $vname=$consultaName->rowCount();
if($vname>=1){
 $msg=["alert"=>"duplicidad","campo"=>"El name de la tcategoria ya esta registrada anteriormente"];
}
if ($vname<1) {

  $data=[
        "idCategoria"=>$idCategoria,
          "name"=>$name
      ];

      
if (CategoryModel::updateCategoryModel($data)!="error") {
     $msg=["alert"=>"update"];
  

}else{
    $msg=["alert"=>"error"];
}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 