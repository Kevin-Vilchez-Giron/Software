<?php 
if ($peticionAjax) {
  require_once "../model/CriterionModel.php";
}else{
  require_once "./model/CriterionModel.php";
}

class CriterionController extends CriterionModel{


  public function listCriterionController($request,$status){
      $cnn = mainModel::conect();
   $btn="";
      $icon="";
      if($status==1){
        $btn="danger";
        $icon="trash-o fa-lg";
      }else{      
        $btn="success";
        $icon="check  fa-lg";
      }
$col =array(
      0 =>  'nCriterio',
    1 =>  'name',
    2 =>  'specification',
    3=> 'tolerance',
    4=>'document',
    5=>'idGroupDefault'
);  
$index=0;
if ($request['order'][0]['column']!=5) {
$index=$request['order'][0]['column'];
}
if ($request['order'][0]['column']==6 ||$request['order'][0]['column']==4) {
$index=0;
}
$sql ="SELECT SQL_CALC_FOUND_ROWS t1.*,t3.name as groupdefault,(SELECT name FROM tdocumentcriterion WHERE idCriterion=t1.idCriterion order by idDocumentCriterion desc limit 1 )as document FROM tcriterion as t1  INNER JOIN tgroupdefault as t3 ON t1.idGroupDefault =t3.idGroupDefault WHERE t1.status=$status";
if(!empty($request['search']['value'])){
    $sql.=" AND (t1.name Like '%".$request['search']['value']."%' ";
        $sql.= "OR t1.specification Like '%".$request['search']['value']."%' ";
        $sql.= "OR t2.name Like '%".$request['search']['value']."%' ";
     //   $sql.= "OR t1.document Like '%".$request['search']['value']."%' ";
    $sql.= "OR t3.name Like '%".$request['search']['value']."%')";
}
$query= $cnn->query($sql);
      $totalData = $cnn->query("SELECT FOUND_ROWS()");
            $totalData = (int) $totalData->fetchColumn();
if(isset ($request['order'])){
$sql.=" ORDER BY   ".$col[$index]."   ".$request['order'][0]['dir']."   LIMIT ".
    $request['start']."  ,".$request['length']."  ";
}
$query= $cnn->query($sql);
$totalFilter=$totalData;
$data=array();
$contador=0;
while($row = $query->fetch(PDO::FETCH_ASSOC)){
    $subdata=array();
                $contador = $contador+1;
$linkfile=SERVERURL.'assets/criterion/'.$row['document'];

       $encryp=mainModel::encryption($row['idCriterion']);
     $row['idCriterion']=$encryp;
    $subdata[]=$row['nCriterio']; 
    $subdata[]=$row['name'];
        $subdata[]=$row['specification']; 
    $subdata[]=$row['tolerance']; 
    $subdata[]="   <a href='".$linkfile."' target='_BLANK' class='btn btn-info mr-xs btn-xs ' >         
       <i class='text-light fa  fa-download fa-lg'></i> ".$row['document']." </a>"; 
    $subdata[]=$row['groupdefault']; 
    $test=SERVERURL."ajax/criterionrepotAjax.php?report=".$row['idCriterion'];

    $subdata[]="<a onclick='rellEdit(`".$encryp."`,`".'criterionAjax'."`,`".SERVERURL."`,`".'idCriterion'."`)' class='btn btn-primary btn-xs  mr-xs'>
                  <i class='text-light fa fa-pencil-square-o fa-lg'></i>
                </a>
     <a href='".$test."' target='_BLANK' class='btn btn-warning mr-xs btn-xs ' >  
     <i class='text-light fa  fa-file-pdf-o fa-lg'></i>
</a>
<button type='submit' onclick='modalOnActivaDeleteDataTable(`".'criterionAjax'."`,`".$encryp."`,".$status.",`".SERVERURL."`)' class='btn btn-".$btn." btn-xs '> <i class='fa fa-".$icon."'></i></button> ";     
    $data[]=$subdata;
}
$json_data=array(
    "draw" => isset ( $request['draw'] ) ?  intval( $request['draw'] ) : 0, 
   "recordsTotal"      =>  intval($totalData),
   "recordsFiltered"   =>  intval($totalFilter),
   "data"              =>  $data
);
return json_encode($json_data);
   }

public function valideractivatedelete($idElemento ,$status){
     $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
      $result=0;
 if($idElemento!=false){
      $status=mainModel::limpiar_cadena($status);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idCriterion=$idElemento and status=$status ");
  $result=$consulta->rowCount();
 }
 return $result;
}



    public function activaDeleteCriterionController($idElemento ,$status){
      $idElemento = mainModel::limpiar_cadena($idElemento);
      $idElemento=mainModel::decryption($idElemento);
 if($idElemento!=false){
 
      $status=mainModel::limpiar_cadena($status);
      if(mainModel::activateDeleteSimple("tcriterion",$idElemento,$status,"idCriterion")){
        if($status==1){
        $msg=["alert"=>"delete"]; 
      }else{
        $msg=["alert"=>"activate"];
      }
        }else{
          $msg=["alert"=>"error"];
        } 
           }else{
            $msg=["alert"=>"error"];
           }
      return mainModel::mensajeRespuesta($msg);
    }





 public function listSelect($saveUpdate,$item1,$item2){
$htmlgrupodefault=mainModel::getListAuto("SELECT * FROM tgroupdefault where status=1", "idGroupDefault","name",$item2,$saveUpdate);
 $data=[ 
          "htmlgrupodefault"=>$htmlgrupodefault
        ];

return $data;
 }   
 
public function fomUpdate(){
       $idCriterion  =mainModel::limpiar_cadena($_GET['idCriterion']);
      $idCriterion   =mainModel::decryption($idCriterion);
  $consulta =mainModel::execute_query("SELECT * FROM tcriterion WHERE idCriterion=$idCriterion");
  $req = $consulta->fetch(PDO::FETCH_ASSOC);
     $idGroupDefault=$req['idGroupDefault'];
  $datoslist=self::listSelect('update',"",$idGroupDefault);

   $consulta2 =mainModel::execute_query("SELECT name FROM tdocumentcriterion WHERE idCriterion=$idCriterion order by idDocumentCriterion desc limit 1");
    $requestcd = $consulta2->fetch(PDO::FETCH_ASSOC);
$saveUpdate='update';
$linkfile=SERVERURL.'assets/criterion/'.$requestcd['name'];
$cuerpo=' <div class="col-sm-4 mb-xs"> 
                                       <div class="form-group">
                      <label class="control-label">Numero</label>
     <input type="number" name="nCriterio" class="form-control nCriterio" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" value="'.$req['nCriterio'].'" >

                      </div>
   </div>

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
          <label class="control-label">Criterio </label>
                       ﻿<value id="vupsc" for="1" style="display:none">'.$req['name'].'</value>

    <input type="text" name="name" maxlength="250" class="form-control nameupdate"  value="'.$req['name'].'"   >
           </div>
             </div> 

      <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
          <label class="control-label">Especificacion</label>
             ﻿<value id="vupespeci" for="1" style="display:none">'.$req['specification'].'</value>

   <textarea  maxlength="250" rows="2" class="form-control specificationupdate" name="specification" >'.$req['specification'].'</textarea>
           </div>
          </div>

 <div class="col-sm-4 mb-xs">  
                <div class="form-group">
                        <label class="control-label">Tolerancia <span class="required">*</span></label>
  <input type="text" name="tolerance" maxlength="250" class="form-control toleranceupdate"  value="'.$req['tolerance'].'"   >
                      </div>     
                      </div>

<div class="col-sm-5 mb-xs">
                        <div class="form-group"> <label class="control-label">Documento</label>
                                                <div class="col-md-12">

                          <div class="fileupload fileupload-new" data-provides="fileupload"><input type="hidden" value="" name="">
                            <div class="input-append">
                              <div class="uneditable-input">
                                <i class="fa fa-file fileupload-exists"></i>
                                <span class="fileupload-preview"></span>
                              </div>
                              <span class="btn btn-default btn-file">
                                <span class="fileupload-exists">Cambiar</span>
                                <span class="fileupload-new">Seleccionar </span>
                                <input type="file"  class="custom-file-input imgClass2" id="image"  name="file" onChange="cargafile(this,`'.$saveUpdate.'`); ">
                                    <input type="hidden" class="cargaIB2" name="cargaI"  value="0" >
                              </span>
                              <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Eliminar</a>                             
                            </div>
                          </div></div></div>
     <a class="btn btn-info btn-xs" href="'.$linkfile.'" target="_BLANK"> <i class="fa fa-download"></i>'.$requestcd['name'].'</a>
                          </div>

<div class="col-sm-3 mb-xs">  
                <div class="form-group">
                        <label class="control-label">Grupo Defectos <span class="required">*</span></label>
<select class="form-control idGroupDefaultupdate" name="idGroupDefault"  data-live-search="true"  required>
 '.$datoslist['htmlgrupodefault'].'
 </select>
                      </div>     
                      </div>  
<script>      $(".idGroupDefaultupdate").selectpicker();
      $(".idToleranceupdate").selectpicker();


 var origValue = document.getElementById("vupespeci").innerHTML;

            document.getElementById("vupespeci").addEventListener("DOMSubtreeModified", translationCallback, false);

            function translationCallback() {
              $(".specificationupdate").val($("#vupespeci").text());

            }


 var origValue2 = document.getElementById("vupsc").innerHTML;

            document.getElementById("vupsc").addEventListener("DOMSubtreeModified", translationCallback2, false);

            function translationCallback2() {
              $(".nameupdate").val($("#vupsc").text());

            }


</script>';

return $cuerpo;
}

public function datareportsingular($id){
$idCriterion=mainModel::decryption($id);
 $consulta =mainModel::execute_query("SELECT t1.*,t3.name as groupdefault,(SELECT name FROM tdocumentcriterion WHERE idCriterion=t1.idCriterion order by idDocumentCriterion desc limit 1 )as document FROM tcriterion as t1  INNER JOIN tgroupdefault as t3 ON t1.idGroupDefault =t3.idGroupDefault WHERE  t1.idCriterion=$idCriterion");
      $req = $consulta->fetch(PDO::FETCH_ASSOC);
return $req;
}

public function paintForm($saveUpdate){
$titulo="";
$subtitulo=""; $txtb=''; $cuerpo=''; $lt=''; $lgr='';
if ($saveUpdate=="save") {
$datoslist=self::listSelect($saveUpdate,'','');
$titulo="Registro de Criterio de Inspeccion";
$txtb='Guardar';
$cuerpo=' <div class="row caja'.$saveUpdate.'">
 <div class="col-sm-4 mb-xs"> 
                                       <div class="form-group">
                      <label class="control-label">Numero</label>
                      <input type="number" name="nCriterio" class="form-control nCriterio" min="1" max="9999999999" data-maxlength="10" oninput="this.value=this.value.slice(0,this.dataset.maxlength)" >

                      </div>
                                 </div>

    <div class="col-sm-4 mb-xs"> 
              <div class="form-group">
                      <label class="control-label">Criterio </label>
                      <input type="text" name="name" maxlength="250" class="form-control name"     >
                      </div>
             </div> 

      <div class="col-sm-4 mb-xs"> 
          <div class="form-group">
                 <label class="control-label">Especificacion</label>
   <textarea  maxlength="250" rows="2" class="form-control specification" name="specification" > </textarea>
                      </div>
          </div>

    <div class="col-sm-4 mb-xs">  
                <div class="form-group">
                        <label class="control-label">Tolerancia <span class="required">*</span></label>
  <input type="text" name="tolerance" maxlength="250" class="form-control tolerance"   >
                      </div>     
                      </div>
         
                        <div class="col-sm-5 mb-xs">
                        <div class="form-group"> <label class="control-label">Documento <span class="required">*</span></label>
                                                <div class="col-md-12">

                          <div class="fileupload fileupload-new" data-provides="fileupload"><input type="hidden" value="" name="">
                            <div class="input-append">
                              <div class="uneditable-input">
                                <i class="fa fa-file fileupload-exists"></i>
                                <span class="fileupload-preview"></span>
                              </div>
                              <span class="btn btn-default btn-file">
                                <span class="fileupload-exists">Cambiar</span>
                                <span class="fileupload-new">Seleccionar </span>
                                <input type="file"  class="custom-file-input imgClass1" id="image"  name="file" onChange="cargafile(this,`'.$saveUpdate.'`); required">
                                    <input type="hidden" class="cargaIB1" name="cargaI"  value="0" required>
                              </span>
                              <a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Eliminar</a>                             
                            </div>
                          </div></div></div></div>

<div class="col-sm-3 mb-xs">  
                <div class="form-group">
                        <label class="control-label">Grupo Defectos <span class="required">*</span></label>
<select class="form-control idGroupDefault'.$saveUpdate.'" name="idGroupDefault"  data-live-search="true"  required>
 '.$datoslist['htmlgrupodefault'].'
                          </select>
                      </div>     
                      </div>
</div>';
}
if ($saveUpdate=="update") {
$titulo="Editor de Criterio de Inspeccion";
$subtitulo=''; $txtb='Modificar'; $cuerpo=' <div class="col-md-12"> <div class="row caja'.$saveUpdate.'" ></div>   <div class="loadGuardadof"></div>
                                   <div class="RespuestaAjaxf"></div> </div>';
}

$html='<section class="panel"> <header class="panel-heading">';
$html.=$subtitulo;  
                 $html = ' <section class="panel">
                <header class="panel-heading">
                  <h2 class="panel-title">'.$titulo.'</h2>
                </header>
                <div class="panel-body">
  <input type="hidden"  name="'.$saveUpdate.'" >
    <input type="hidden" class="idCriterion"  name="idCriterion" >       
'.$cuerpo.'
</div>
                <footer class="panel-footer panf'.$saveUpdate.'">
                   <div class="row">
                      <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit"  class="mb-xs mt-xs mr-xs modal-basic btn btn-primary" >'.$txtb.'</button>';
                            if ($saveUpdate=="save") {
   $html.=' <a type="reset" class="btn btn-default" onclick="resetForm()">Limpiar</a>';      
                    }else {
    $html.=' <button class="btn btn-default modalform-dismiss">Cerrar</button>';
}
                    $html.='  </div>
                    </div>
                </footer>
              </section> ';
 return $html;
}


    public function saveCriterionController(){
      
$nCriterio=mainModel::limpiar_cadena($_POST['nCriterio']);
$name=mainModel::limpiar_cadena($_POST['name']);
$specification=mainModel::limpiar_cadena($_POST['specification']);
$idTolerance=mainModel::limpiar_cadena($_POST['tolerance']);
$idGroupDefault=mainModel::limpiar_cadena($_POST['idGroupDefault']);
$namefile='';
$consultaNumber = mainModel::execute_query("SELECT * FROM tcriterion WHERE nCriterio=$nCriterio  ");
  $vnumber=$consultaNumber->rowCount();
      $consultaName = mainModel::execute_query("SELECT * FROM tcriterion WHERE name='$name'  ");
  $vname=$consultaName->rowCount();
if($vnumber>=1 ||$vname>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Numero de Criterio o el nombre del criterio"];
}
if ($vnumber<1 && $vname<1) {
$archivo=mainModel::uploadFilePrincipal(1,"criterion",'documento');
 $data=[ "name"=>$name,
         "nCriterio"=>$nCriterio,
         "specification"=>$specification,
         "idTolerance"=>$idTolerance,
         "idGroupDefault"=>$idGroupDefault
      ];
if (CriterionModel::saveCriterionModel($data)!="error") {
  $consulta =mainModel::execute_query("SELECT idCriterion FROM tcriterion WHERE nCriterio=$nCriterio");
      $req = $consulta->fetch(PDO::FETCH_ASSOC);
      $id=$req['idCriterion'];
$datadoc=["idCriterion"=>$id,"name"=>$archivo];
if (CriterionModel::saveDocumentCriterionModel($datadoc)!="error") {
     $msg=["alert"=>"save"];
}else{
   $msg=["alert"=>"error"];
}

}else{
 $msg=["alert"=>"error"];
}

}
 return mainModel::mensajeRespuesta($msg);
 }

    public function updateCriterionController(){
    $idCriterion =mainModel::limpiar_cadena($_POST['idCriterion']);
      $idCriterion  =mainModel::decryption($idCriterion);
      $name=mainModel::limpiar_cadena($_POST['name']);
      $cargaI=mainModel::limpiar_cadena($_POST['cargaI']);
$nCriterio=mainModel::limpiar_cadena($_POST['nCriterio']);
$specification=mainModel::limpiar_cadena($_POST['specification']);
$idTolerance=mainModel::limpiar_cadena($_POST['tolerance']);
$idGroupDefault=mainModel::limpiar_cadena($_POST['idGroupDefault']);

 $consulta2 =mainModel::execute_query("SELECT idDocumentCriterion , name FROM tdocumentcriterion WHERE idCriterion=$idCriterion");
    $requestcd = $consulta2->fetch(PDO::FETCH_ASSOC);
  $idDocumentCriterion=$requestcd['idDocumentCriterion'];
    $namefile=$requestcd['name'];



$consultaNumber = mainModel::execute_query("SELECT * FROM tcriterion WHERE nCriterio=$nCriterio and idCriterion!=$idCriterion  ");
  $vnumber=$consultaNumber->rowCount();
      $consultaName = mainModel::execute_query("SELECT * FROM tcriterion WHERE name='$name' and idCriterion!=$idCriterion ");
  $vname=$consultaName->rowCount();
if($vnumber>=1 ||$vname>=1){
 $msg=["alert"=>"duplicidad","campo"=>"Numero de Criterio o el nombre del criterio"];
}
if ($vnumber<1 && $vname<1) {
if ($cargaI==1) {
  $deletefile=mainModel::deleteImgController("criterion",$namefile);
$namefile=mainModel::uploadFilePrincipal(1,"criterion",'documento');
}
  $data=[
        "idCriterion"=>$idCriterion,
          "name"=>$name,
         "nCriterio"=>$nCriterio,
         "specification"=>$specification,
         "tolerance"=>$idTolerance,
         "idGroupDefault"=>$idGroupDefault
      ];

      $datadocument=["idDocumentCriterion"=>$idDocumentCriterion,
        "name"=>$namefile
      ];
if (CriterionModel::updateCriterionModel($data)!="error") {
  if (CriterionModel::updateDocumentCriterionModel($datadocument)!="error") {
     $msg=["alert"=>"update"];
  }

}

}
   
      return mainModel::mensajeRespuesta($msg);
    }

}

 